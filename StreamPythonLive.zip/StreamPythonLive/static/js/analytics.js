/**
 * StreamApp Analytics Module
 * Handles analytics dashboard functionality
 */

// Global variables for charts
let viewsChart = null;
let viewersChart = null;
let watchTimeChart = null;
let peakViewersChart = null;

// Initialize when DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Load summary data
    loadAnalyticsSummary();
    
    // Load detailed analytics
    loadAnalyticsData();
    
    // Set up filter controls
    setupFilterControls();
});

/**
 * Set up filter controls for analytics
 */
function setupFilterControls() {
    const mediaSelect = document.getElementById('media-select');
    const streamSelect = document.getElementById('stream-select');
    const periodSelect = document.getElementById('period-select');
    
    // Handle changes to media selection
    if (mediaSelect) {
        mediaSelect.addEventListener('change', function() {
            // Clear stream selection if media is selected
            if (this.value && streamSelect) {
                streamSelect.value = '';
            }
            
            // Reload analytics data
            loadAnalyticsData();
        });
    }
    
    // Handle changes to stream selection
    if (streamSelect) {
        streamSelect.addEventListener('change', function() {
            // Clear media selection if stream is selected
            if (this.value && mediaSelect) {
                mediaSelect.value = '';
            }
            
            // Reload analytics data
            loadAnalyticsData();
        });
    }
    
    // Handle changes to period selection
    if (periodSelect) {
        periodSelect.addEventListener('change', function() {
            // Reload analytics data
            loadAnalyticsData();
        });
    }
}

/**
 * Load analytics summary data
 */
function loadAnalyticsSummary() {
    fetch('/analytics/summary', {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Update total stats
        document.getElementById('total-media-views').textContent = data.total_media_views.toLocaleString();
        document.getElementById('total-media-count').textContent = data.total_media_count.toLocaleString();
        document.getElementById('total-stream-count').textContent = data.total_stream_count.toLocaleString();
        
        // Update most viewed media
        const mostViewedMediaElement = document.getElementById('most-viewed-media');
        if (data.most_viewed_media) {
            mostViewedMediaElement.textContent = `${data.most_viewed_media.title} (${data.most_viewed_media.views} views)`;
            
            // Add link to the media
            const link = document.createElement('a');
            link.href = `/media/${data.most_viewed_media.id}`;
            link.className = 'ms-2 btn btn-sm btn-outline-primary';
            link.innerHTML = '<i class="fas fa-external-link-alt"></i>';
            mostViewedMediaElement.appendChild(link);
        } else {
            mostViewedMediaElement.textContent = 'No media uploaded yet';
        }
        
        // Update most viewed stream
        const mostViewedStreamElement = document.getElementById('most-viewed-stream');
        if (data.most_viewed_stream) {
            mostViewedStreamElement.textContent = `${data.most_viewed_stream.title} (${data.most_viewed_stream.viewers} viewers)`;
            
            // Add link to the stream
            const link = document.createElement('a');
            link.href = `/livestream/${data.most_viewed_stream.id}`;
            link.className = 'ms-2 btn btn-sm btn-outline-primary';
            link.innerHTML = '<i class="fas fa-external-link-alt"></i>';
            mostViewedStreamElement.appendChild(link);
        } else {
            mostViewedStreamElement.textContent = 'No streams created yet';
        }
    })
    .catch(error => {
        console.error('Error loading analytics summary:', error);
        showAlert('Failed to load analytics summary data', 'danger');
    });
}

/**
 * Load detailed analytics data
 */
function loadAnalyticsData() {
    // Get filter values
    const mediaId = document.getElementById('media-select')?.value || '';
    const streamId = document.getElementById('stream-select')?.value || '';
    const period = document.getElementById('period-select')?.value || 'week';
    
    // Show loading state
    document.getElementById('analytics-loading').classList.remove('d-none');
    document.getElementById('analytics-charts').classList.add('d-none');
    
    // Build query params
    const params = new URLSearchParams();
    if (mediaId) params.append('media_id', mediaId);
    if (streamId) params.append('stream_id', streamId);
    params.append('period', period);
    
    // Fetch analytics data
    fetch(`/analytics/data?${params.toString()}`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Hide loading state
        document.getElementById('analytics-loading').classList.add('d-none');
        document.getElementById('analytics-charts').classList.remove('d-none');
        
        // Update total stats
        document.getElementById('total-views').textContent = data.total_stats.total_views.toLocaleString();
        document.getElementById('total-unique-viewers').textContent = data.total_stats.total_unique_viewers.toLocaleString();
        document.getElementById('total-watch-time').textContent = formatWatchTime(data.total_stats.total_watch_time);
        document.getElementById('max-peak-viewers').textContent = data.total_stats.max_peak_viewers.toLocaleString();
        
        // Render charts
        renderCharts(data);
    })
    .catch(error => {
        console.error('Error loading analytics data:', error);
        document.getElementById('analytics-loading').classList.add('d-none');
        showAlert('Failed to load analytics data', 'danger');
    });
}

/**
 * Render analytics charts
 * @param {Object} data - Analytics data
 */
function renderCharts(data) {
    // Common chart options
    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: {
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                    color: 'rgba(255, 255, 255, 0.7)'
                }
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                    color: 'rgba(255, 255, 255, 0.7)'
                }
            }
        },
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                mode: 'index',
                intersect: false
            }
        }
    };
    
    // Views chart
    renderViewsChart(data.dates, data.views, chartOptions);
    
    // Unique viewers chart
    renderViewersChart(data.dates, data.unique_viewers, chartOptions);
    
    // Watch time chart
    renderWatchTimeChart(data.dates, data.watch_time, chartOptions);
    
    // Peak viewers chart
    renderPeakViewersChart(data.dates, data.peak_viewers, chartOptions);
}

/**
 * Render views chart
 * @param {Array} dates - Date labels
 * @param {Array} views - Views data
 * @param {Object} options - Chart options
 */
function renderViewsChart(dates, views, options) {
    const ctx = document.getElementById('views-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (viewsChart) {
        viewsChart.destroy();
    }
    
    // Create new chart
    viewsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Views',
                data: views,
                backgroundColor: 'rgba(13, 110, 253, 0.2)',
                borderColor: 'rgba(13, 110, 253, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(13, 110, 253, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3,
                fill: true
            }]
        },
        options: options
    });
}

/**
 * Render unique viewers chart
 * @param {Array} dates - Date labels
 * @param {Array} viewers - Viewers data
 * @param {Object} options - Chart options
 */
function renderViewersChart(dates, viewers, options) {
    const ctx = document.getElementById('viewers-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (viewersChart) {
        viewersChart.destroy();
    }
    
    // Create new chart
    viewersChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Unique Viewers',
                data: viewers,
                backgroundColor: 'rgba(25, 135, 84, 0.2)',
                borderColor: 'rgba(25, 135, 84, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(25, 135, 84, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3,
                fill: true
            }]
        },
        options: options
    });
}

/**
 * Render watch time chart
 * @param {Array} dates - Date labels
 * @param {Array} watchTime - Watch time data
 * @param {Object} options - Chart options
 */
function renderWatchTimeChart(dates, watchTime, options) {
    const ctx = document.getElementById('watch-time-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (watchTimeChart) {
        watchTimeChart.destroy();
    }
    
    // Create new chart
    watchTimeChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Watch Time (minutes)',
                data: watchTime,
                backgroundColor: 'rgba(255, 193, 7, 0.2)',
                borderColor: 'rgba(255, 193, 7, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(255, 193, 7, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3,
                fill: true
            }]
        },
        options: options
    });
}

/**
 * Render peak viewers chart
 * @param {Array} dates - Date labels
 * @param {Array} peakViewers - Peak viewers data
 * @param {Object} options - Chart options
 */
function renderPeakViewersChart(dates, peakViewers, options) {
    const ctx = document.getElementById('peak-viewers-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (peakViewersChart) {
        peakViewersChart.destroy();
    }
    
    // Create new chart
    peakViewersChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Peak Viewers',
                data: peakViewers,
                backgroundColor: 'rgba(220, 53, 69, 0.2)',
                borderColor: 'rgba(220, 53, 69, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(220, 53, 69, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3,
                fill: true
            }]
        },
        options: options
    });
}

/**
 * Format watch time for display
 * @param {number} minutes - Watch time in minutes
 * @returns {string} Formatted watch time
 */
function formatWatchTime(minutes) {
    if (minutes < 60) {
        return `${Math.round(minutes)} minutes`;
    } else {
        const hours = Math.floor(minutes / 60);
        const mins = Math.round(minutes % 60);
        return `${hours} hour${hours !== 1 ? 's' : ''} ${mins} minute${mins !== 1 ? 's' : ''}`;
    }
}

/**
 * Show alert message
 * @param {string} message - Alert message
 * @param {string} type - Alert type (success, danger, warning, info)
 */
function showAlert(message, type = 'info') {
    const alertPlaceholder = document.querySelector('.alert-placeholder');
    if (!alertPlaceholder) return;
    
    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    
    alertPlaceholder.append(wrapper);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alert = wrapper.querySelector('.alert');
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}
