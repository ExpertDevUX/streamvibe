/**
 * StreamVibe Analytics Tracker Module
 * 
 * This module handles client-side analytics tracking for media views, 
 * stream views, and user interactions. It automatically collects data
 * like device type, browser, OS, and referrer information, and sends
 * events to the server for processing.
 */

// Initialize session storage for the viewer session
const SESSION_ID_KEY = 'streamvibe_session_id';
let sessionId = sessionStorage.getItem(SESSION_ID_KEY);

// Generate a new session ID if none exists
if (!sessionId) {
    sessionId = generateSessionId();
    sessionStorage.setItem(SESSION_ID_KEY, sessionId);
}

/**
 * Initialize analytics tracking
 * @param {Object} options - Configuration options
 */
function initAnalytics(options = {}) {
    // Default options
    const defaultOptions = {
        userId: null,
        mediaId: null,
        streamId: null,
        trackPageView: true,
        trackEvents: true,
        trackEngagement: true,
        heartbeatInterval: 30,  // seconds
    };
    
    // Merge options
    const config = { ...defaultOptions, ...options };
    
    // Store config for later use
    window.streamvibeAnalytics = {
        config,
        engagementTimer: 0,
        watchTimer: 0,
        isWatching: false,
        heartbeatInterval: null,
        lastPosition: 0,
        events: {
            interactions: 0
        }
    };
    
    // Add event listeners
    if (config.trackEvents) {
        setupEventListeners();
    }
    
    // Track page view
    if (config.trackPageView) {
        trackPageView();
    }
    
    // Setup heartbeat for streams
    if (config.streamId && config.heartbeatInterval > 0) {
        startHeartbeat(config.heartbeatInterval);
    }
    
    // Setup engagement tracking
    if (config.trackEngagement) {
        setupEngagementTracking();
    }
    
    // Log initialization
    console.log('StreamVibe Analytics initialized:', config);
}

/**
 * Setup event listeners for tracking user interactions
 */
function setupEventListeners() {
    const analytics = window.streamvibeAnalytics;
    
    // Play/pause events for video and audio elements
    document.querySelectorAll('video, audio').forEach(media => {
        media.addEventListener('play', () => {
            analytics.isWatching = true;
            analytics.watchTimer = Date.now();
            analytics.lastPosition = media.currentTime;
            
            // Track play event
            trackEvent('play', {
                position: media.currentTime
            });
        });
        
        media.addEventListener('pause', () => {
            if (analytics.isWatching && analytics.watchTimer > 0) {
                const watchTime = (Date.now() - analytics.watchTimer) / 1000;
                analytics.isWatching = false;
                
                // Track pause event with watch time
                trackEvent('pause', {
                    position: media.currentTime,
                    watchTime
                });
                
                // Record total watch time
                trackWatchTime(watchTime);
            }
        });
        
        media.addEventListener('ended', () => {
            if (analytics.isWatching && analytics.watchTimer > 0) {
                const watchTime = (Date.now() - analytics.watchTimer) / 1000;
                analytics.isWatching = false;
                
                // Track end event with watch time
                trackEvent('end', {
                    watchTime
                });
                
                // Record total watch time
                trackWatchTime(watchTime);
            }
        });
        
        media.addEventListener('seeking', () => {
            // Track seek event
            trackEvent('seek', {
                from: analytics.lastPosition,
                to: media.currentTime
            });
            
            analytics.lastPosition = media.currentTime;
        });
    });
    
    // Track likes, comments, shares
    document.querySelectorAll('.like-button, .comment-button, .share-button').forEach(button => {
        button.addEventListener('click', () => {
            const action = button.classList.contains('like-button') ? 'like' : 
                           button.classList.contains('comment-button') ? 'comment' : 'share';
            
            // Track interaction event
            trackEvent('interaction', {
                action,
                contentId: button.dataset.id,
                contentType: button.dataset.type
            });
            
            // Update engagement count
            analytics.events.interactions++;
        });
    });
    
    // Video quality changes
    document.querySelectorAll('.quality-selector').forEach(selector => {
        selector.addEventListener('change', (e) => {
            trackEvent('quality_change', {
                oldQuality: selector.dataset.currentQuality,
                newQuality: e.target.value
            });
            
            selector.dataset.currentQuality = e.target.value;
        });
    });
}

/**
 * Setup engagement tracking
 */
function setupEngagementTracking() {
    const analytics = window.streamvibeAnalytics;
    
    // Start engagement timer
    analytics.engagementTimer = Date.now();
    
    // Detect bounce
    window.addEventListener('beforeunload', () => {
        const timeOnPage = (Date.now() - analytics.engagementTimer) / 1000;
        
        // Consider bounce if time on page is less than 30 seconds and no interactions
        if (timeOnPage < 30 && analytics.events.interactions === 0) {
            trackEvent('bounce', {
                timeOnPage
            });
        }
        
        // Calculate engagement rate
        if (analytics.config.mediaId || analytics.config.streamId) {
            const engagementRate = calculateEngagementRate();
            
            // Track final engagement
            trackEvent('engagement', {
                rate: engagementRate
            });
        }
    });
}

/**
 * Calculate engagement rate based on interactions and time spent
 * @returns {number} Engagement rate (0-1)
 */
function calculateEngagementRate() {
    const analytics = window.streamvibeAnalytics;
    
    // Time in seconds
    const timeSpent = (Date.now() - analytics.engagementTimer) / 1000;
    
    // Base engagement factors
    const timeWeight = 0.5;
    const interactionWeight = 0.5;
    
    // Calculate time score (0-1) - max value at 5 minutes
    const timeScore = Math.min(timeSpent / 300, 1);
    
    // Calculate interaction score (0-1) - max value at 5 interactions
    const interactionScore = Math.min(analytics.events.interactions / 5, 1);
    
    // Calculate weighted engagement rate
    return (timeScore * timeWeight) + (interactionScore * interactionWeight);
}

/**
 * Start heartbeat for live streams
 * @param {number} interval - Heartbeat interval in seconds
 */
function startHeartbeat(interval) {
    const analytics = window.streamvibeAnalytics;
    
    // Clear existing interval
    if (analytics.heartbeatInterval) {
        clearInterval(analytics.heartbeatInterval);
    }
    
    // Set new interval
    analytics.heartbeatInterval = setInterval(() => {
        // Send heartbeat event
        trackEvent('heartbeat', {
            timestamp: Date.now()
        });
    }, interval * 1000);
}

/**
 * Stop heartbeat
 */
function stopHeartbeat() {
    const analytics = window.streamvibeAnalytics;
    
    // Clear interval
    if (analytics.heartbeatInterval) {
        clearInterval(analytics.heartbeatInterval);
        analytics.heartbeatInterval = null;
    }
}

/**
 * Track page view
 */
function trackPageView() {
    const analytics = window.streamvibeAnalytics;
    
    // Track view event
    trackEvent('view', {
        url: window.location.href,
        title: document.title,
        referrer: document.referrer
    });
}

/**
 * Track watch time
 * @param {number} seconds - Watch time in seconds
 */
function trackWatchTime(seconds) {
    // Only track if seconds is valid
    if (typeof seconds !== 'number' || seconds <= 0) return;
    
    trackEvent('watch', {
        value: seconds
    });
}

/**
 * Track analytics event
 * @param {string} eventType - Type of event
 * @param {Object} eventData - Event data
 */
function trackEvent(eventType, eventData = {}) {
    const analytics = window.streamvibeAnalytics;
    
    // Skip if user ID is not available
    if (!analytics.config.userId) {
        console.warn('StreamVibe Analytics: User ID not set, skipping event tracking');
        return;
    }
    
    // Build event data
    const event = {
        user_id: analytics.config.userId,
        session_id: sessionId,
        event_type: eventType,
        media_id: analytics.config.mediaId,
        stream_id: analytics.config.streamId,
        device_type: getDeviceType(),
        browser: getBrowser(),
        os: getOS(),
        referrer: document.referrer,
        country_code: null,  // Will be set by server-side
        value: null
    };
    
    // Add value if exists in eventData
    if (eventData.hasOwnProperty('value')) {
        event.value = eventData.value;
    } else if (eventData.hasOwnProperty('watchTime')) {
        event.value = eventData.watchTime;
    } else if (eventType === 'engagement' && eventData.hasOwnProperty('rate')) {
        event.value = eventData.rate;
    }
    
    // Send event to server
    sendEvent(event);
    
    // Log event (if not heartbeat to reduce noise)
    if (eventType !== 'heartbeat') {
        console.log('StreamVibe Analytics Event:', event);
    }
}

/**
 * Send event to server
 * @param {Object} event - Event data
 */
function sendEvent(event) {
    fetch('/analytics/events', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(event)
    })
    .catch(error => {
        console.error('Error sending analytics event:', error);
    });
}

/**
 * Generate a unique session ID
 * @returns {string} Session ID
 */
function generateSessionId() {
    return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

/**
 * Get device type
 * @returns {string} Device type (mobile, desktop, tablet, or other)
 */
function getDeviceType() {
    const userAgent = navigator.userAgent;
    
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)) {
        if (/iPad|Android 3|Android 4.[3-9].*Tablet|Opera.*Tablet|Nexus.*Tablet|Kindle.*Tablet/i.test(userAgent)) {
            return 'tablet';
        }
        return 'mobile';
    }
    
    return 'desktop';
}

/**
 * Get browser information
 * @returns {string} Browser name
 */
function getBrowser() {
    const userAgent = navigator.userAgent;
    
    if (userAgent.indexOf('Chrome') > -1) return 'Chrome';
    if (userAgent.indexOf('Safari') > -1) return 'Safari';
    if (userAgent.indexOf('Firefox') > -1) return 'Firefox';
    if (userAgent.indexOf('Edge') > -1) return 'Edge';
    if (userAgent.indexOf('MSIE') > -1 || userAgent.indexOf('Trident/') > -1) return 'Internet Explorer';
    
    return 'Unknown';
}

/**
 * Get operating system information
 * @returns {string} OS name
 */
function getOS() {
    const userAgent = navigator.userAgent;
    
    if (userAgent.indexOf('Windows') > -1) return 'Windows';
    if (userAgent.indexOf('Mac OS') > -1) return 'macOS';
    if (userAgent.indexOf('Linux') > -1) return 'Linux';
    if (userAgent.indexOf('Android') > -1) return 'Android';
    if (userAgent.indexOf('iOS') > -1) return 'iOS';
    
    return 'Unknown';
}

// Export functions for browser and module use
if (typeof window !== 'undefined') {
    // Browser environment
    window.StreamVibeAnalytics = {
        init: initAnalytics,
        trackEvent,
        trackPageView,
        trackWatchTime
    };
} else if (typeof module !== 'undefined' && module.exports) {
    // Node.js environment (for testing)
    module.exports = {
        initAnalytics,
        trackEvent,
        trackPageView,
        trackWatchTime
    };
}