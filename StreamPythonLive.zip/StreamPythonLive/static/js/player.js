/**
 * StreamApp Player Module
 * Handles video and audio playback functionality
 */

// Initialize when DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize video.js player
    const videoElement = document.getElementById('media-player');
    
    if (videoElement) {
        const player = videojs('media-player', {
            fluid: true,
            controls: true,
            autoplay: false,
            preload: 'auto',
            playbackRates: [0.5, 1, 1.25, 1.5, 2],
            responsive: true,
            html5: {
                hls: {
                    overrideNative: true
                }
            }
        });
        
        // Add quality selector if HLS stream with multiple qualities
        setupQualitySelector(player);
        
        // Setup view tracking
        setupViewTracking(player);
        
        // Setup keyboard shortcuts
        setupKeyboardShortcuts(player);
        
        // Clean up on page unload
        window.addEventListener('beforeunload', function() {
            if (player) {
                player.dispose();
            }
        });
    }
    
    // Initialize comments functionality
    setupComments();
});

/**
 * Set up quality selector for player
 * @param {Object} player - VideoJS player instance
 */
function setupQualitySelector(player) {
    const qualityLevels = document.getElementById('quality-levels');
    
    if (!qualityLevels || !player) return;
    
    // Add quality selector button to control bar
    const qualitySelector = player.controlBar.addChild('Button', {
        text: 'Quality',
        className: 'vjs-quality-button vjs-menu-button',
    });
    
    // Add click event to quality selector
    qualitySelector.on('click', function() {
        const qualityMenu = document.getElementById('quality-menu');
        if (qualityMenu) {
            qualityMenu.classList.toggle('d-none');
            
            // Position menu
            const rect = qualitySelector.el().getBoundingClientRect();
            qualityMenu.style.bottom = window.innerHeight - rect.top + 'px';
            qualityMenu.style.left = rect.left + 'px';
        }
    });
    
    // Hide menu when clicking elsewhere
    document.addEventListener('click', function(e) {
        const qualityMenu = document.getElementById('quality-menu');
        const qualitySelectorEl = qualitySelector.el();
        
        if (qualityMenu && !qualityMenu.contains(e.target) && !qualitySelectorEl.contains(e.target)) {
            qualityMenu.classList.add('d-none');
        }
    });
    
    // Handle quality selection
    const qualityLinks = document.querySelectorAll('.quality-option');
    qualityLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const quality = this.getAttribute('data-src');
            const isPaused = player.paused();
            const currentTime = player.currentTime();
            
            // Save player state and switch source
            player.src({
                src: quality,
                type: player.currentType()
            });
            
            player.ready(function() {
                // Restore player state
                player.currentTime(currentTime);
                if (!isPaused) {
                    player.play();
                }
                
                // Update active quality in menu
                qualityLinks.forEach(l => l.classList.remove('active'));
                e.target.classList.add('active');
                
                // Hide menu
                document.getElementById('quality-menu').classList.add('d-none');
            });
        });
    });
}

/**
 * Set up view tracking
 * @param {Object} player - VideoJS player instance
 */
function setupViewTracking(player) {
    if (!player) return;
    
    const mediaId = document.getElementById('media-id')?.value;
    const streamId = document.getElementById('stream-id')?.value;
    
    if (!mediaId && !streamId) return;
    
    let viewRegistered = false;
    let watchTime = 0;
    let lastUpdateTime = 0;
    
    // Register view after 5 seconds of playback
    player.on('timeupdate', function() {
        if (viewRegistered) return;
        
        if (player.currentTime() >= 5) {
            viewRegistered = true;
            
            // Record view via AJAX
            const formData = new FormData();
            if (mediaId) formData.append('media_id', mediaId);
            if (streamId) formData.append('stream_id', streamId);
            
            fetch('/analytics/record-view', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }).catch(error => console.error('Error recording view:', error));
        }
    });
    
    // Track watch time at intervals
    player.on('timeupdate', function() {
        if (!viewRegistered) return;
        
        const currentTime = Math.floor(player.currentTime());
        if (currentTime > lastUpdateTime) {
            watchTime += (currentTime - lastUpdateTime);
            lastUpdateTime = currentTime;
            
            // Update watch time every 30 seconds
            if (watchTime % 30 === 0) {
                const formData = new FormData();
                if (mediaId) formData.append('media_id', mediaId);
                if (streamId) formData.append('stream_id', streamId);
                formData.append('seconds', watchTime);
                
                fetch('/analytics/record-watch-time', {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                }).catch(error => console.error('Error recording watch time:', error));
            }
        }
    });
}

/**
 * Set up keyboard shortcuts for player
 * @param {Object} player - VideoJS player instance
 */
function setupKeyboardShortcuts(player) {
    if (!player) return;
    
    document.addEventListener('keydown', function(e) {
        // Only if player is in focus (user has clicked on it)
        if (!player.isInFocus_) return;
        
        switch(e.key) {
            case ' ':
            case 'k':
                // Play/pause
                if (player.paused()) {
                    player.play();
                } else {
                    player.pause();
                }
                e.preventDefault();
                break;
                
            case 'f':
                // Toggle fullscreen
                if (player.isFullscreen()) {
                    player.exitFullscreen();
                } else {
                    player.requestFullscreen();
                }
                e.preventDefault();
                break;
                
            case 'm':
                // Toggle mute
                player.muted(!player.muted());
                e.preventDefault();
                break;
                
            case 'ArrowRight':
                // Forward 10 seconds
                player.currentTime(player.currentTime() + 10);
                e.preventDefault();
                break;
                
            case 'ArrowLeft':
                // Rewind 10 seconds
                player.currentTime(player.currentTime() - 10);
                e.preventDefault();
                break;
                
            case 'ArrowUp':
                // Volume up
                player.volume(Math.min(player.volume() + 0.1, 1));
                e.preventDefault();
                break;
                
            case 'ArrowDown':
                // Volume down
                player.volume(Math.max(player.volume() - 0.1, 0));
                e.preventDefault();
                break;
        }
    });
}

/**
 * Set up comments functionality
 */
function setupComments() {
    const commentForm = document.getElementById('comment-form');
    const commentsContainer = document.getElementById('comments-container');
    
    if (commentForm) {
        commentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const commentContent = document.getElementById('comment-content').value.trim();
            if (!commentContent) return;
            
            const formData = new FormData(commentForm);
            
            // Submit comment via AJAX
            fetch(commentForm.action, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Add new comment to DOM
                    addCommentToDOM(data.comment);
                    
                    // Clear comment form
                    document.getElementById('comment-content').value = '';
                } else {
                    alert('Error posting comment: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error posting comment:', error);
            });
        });
    }
    
    // For live streams, periodically fetch new comments
    const streamId = document.getElementById('stream-id')?.value;
    if (streamId && commentsContainer) {
        let lastCommentId = 0;
        
        // Get initial last comment ID
        const commentItems = document.querySelectorAll('.comment-item');
        if (commentItems.length > 0) {
            const lastComment = commentItems[commentItems.length - 1];
            lastCommentId = parseInt(lastComment.dataset.commentId) || 0;
        }
        
        // Poll for new comments every 5 seconds
        setInterval(() => {
            fetch(`/livestream/${streamId}/get-comments?last_id=${lastCommentId}`, {
                headers: {
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.comments && data.comments.length > 0) {
                    // Add new comments to DOM
                    data.comments.forEach(comment => {
                        addCommentToDOM(comment);
                        if (comment.id > lastCommentId) {
                            lastCommentId = comment.id;
                        }
                    });
                    
                    // Scroll to bottom if container was already at bottom
                    const isAtBottom = commentsContainer.scrollHeight - commentsContainer.clientHeight <= commentsContainer.scrollTop + 50;
                    if (isAtBottom) {
                        commentsContainer.scrollTop = commentsContainer.scrollHeight;
                    }
                }
            })
            .catch(error => {
                console.error('Error fetching comments:', error);
            });
        }, 5000);
    }
}

/**
 * Add comment to DOM
 * @param {Object} comment - Comment data
 */
function addCommentToDOM(comment) {
    const commentsContainer = document.getElementById('comments-container');
    if (!commentsContainer) return;
    
    const commentHtml = `
        <div class="comment-item p-3 mb-2" data-comment-id="${comment.id || 0}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="d-flex align-items-center">
                    <i class="fas fa-user-circle fa-2x me-2 text-secondary"></i>
                    <strong>${comment.user}</strong>
                </div>
                <small class="text-muted">${comment.timestamp}</small>
            </div>
            <p class="mt-2 mb-0">${comment.content}</p>
        </div>
    `;
    
    commentsContainer.insertAdjacentHTML('beforeend', commentHtml);
    commentsContainer.scrollTop = commentsContainer.scrollHeight;
}
