/**
 * StreamApp Search Module
 * Handles search functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    initializeSearch();
});

/**
 * Initialize search functionality
 */
function initializeSearch() {
    // Initialize filters
    const mediaTypeFilter = document.getElementById('media-type-filter');
    const sortByFilter = document.getElementById('sort-by-filter');
    const dateFilter = document.getElementById('date-filter');
    const durationFilter = document.getElementById('duration-filter');
    
    // Apply filters when they change
    [mediaTypeFilter, sortByFilter, dateFilter, durationFilter].forEach(filter => {
        if (filter) {
            filter.addEventListener('change', applyFilters);
        }
    });
    
    // Reset filters button
    const resetFiltersBtn = document.getElementById('reset-filters');
    if (resetFiltersBtn) {
        resetFiltersBtn.addEventListener('click', resetFilters);
    }
    
    // Initialize search input with immediate search
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
        // Search after user stops typing for a short time
        let searchTimeout;
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(function() {
                applyFilters();
            }, 500);
        });
        
        // Also search when Enter key is pressed
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                applyFilters();
            }
        });
    }
    
    // Initialize search form submission
    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            applyFilters();
        });
    }
}

/**
 * Apply search filters
 */
function applyFilters() {
    // Get filter values
    const query = document.getElementById('search-input')?.value || '';
    const mediaType = document.getElementById('media-type-filter')?.value || 'all';
    const sortBy = document.getElementById('sort-by-filter')?.value || 'date';
    const dateFilter = document.getElementById('date-filter')?.value || 'any';
    const durationFilter = document.getElementById('duration-filter')?.value || 'any';
    
    // Build query string
    const queryParams = new URLSearchParams(window.location.search);
    queryParams.set('q', query);
    queryParams.set('type', mediaType);
    queryParams.set('sort', sortBy);
    queryParams.set('date', dateFilter);
    queryParams.set('duration', durationFilter);
    
    // Update URL and reload page
    window.location.href = `${window.location.pathname}?${queryParams.toString()}`;
}

/**
 * Reset all filters
 */
function resetFilters() {
    // Reset filter form controls
    if (document.getElementById('search-input')) {
        document.getElementById('search-input').value = '';
    }
    
    if (document.getElementById('media-type-filter')) {
        document.getElementById('media-type-filter').value = 'all';
    }
    
    if (document.getElementById('sort-by-filter')) {
        document.getElementById('sort-by-filter').value = 'date';
    }
    
    if (document.getElementById('date-filter')) {
        document.getElementById('date-filter').value = 'any';
    }
    
    if (document.getElementById('duration-filter')) {
        document.getElementById('duration-filter').value = 'any';
    }
    
    // Apply the reset filters
    window.location.href = window.location.pathname;
}

/**
 * Format time duration
 * @param {number} seconds - Duration in seconds
 * @returns {string} Formatted duration string
 */
function formatDuration(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
        return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    } else {
        return `${minutes}:${secs.toString().padStart(2, '0')}`;
    }
}

/**
 * Calculate relative time
 * @param {string} dateString - ISO date string
 * @returns {string} Relative time string
 */
function getRelativeTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    const diffMonth = Math.floor(diffDay / 30);
    const diffYear = Math.floor(diffMonth / 12);
    
    if (diffYear > 0) {
        return diffYear === 1 ? '1 year ago' : `${diffYear} years ago`;
    } else if (diffMonth > 0) {
        return diffMonth === 1 ? '1 month ago' : `${diffMonth} months ago`;
    } else if (diffDay > 0) {
        return diffDay === 1 ? '1 day ago' : `${diffDay} days ago`;
    } else if (diffHour > 0) {
        return diffHour === 1 ? '1 hour ago' : `${diffHour} hours ago`;
    } else if (diffMin > 0) {
        return diffMin === 1 ? '1 minute ago' : `${diffMin} minutes ago`;
    } else {
        return 'Just now';
    }
}
