/**
 * StreamApp Uploader Module
 * Handles file upload functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    initializeFileUploader();
});

/**
 * Initialize file uploader
 */
function initializeFileUploader() {
    const uploadForm = document.getElementById('upload-form');
    if (!uploadForm) return;
    
    const fileInput = document.getElementById('media_file');
    const dragArea = document.getElementById('drag-area');
    const browseBtn = document.getElementById('browse-btn');
    const uploadBtn = document.getElementById('upload-btn');
    const videoPreview = document.getElementById('upload-preview');
    const audioPreview = document.getElementById('audio-preview');
    const progressBar = document.querySelector('.progress');
    const progressBarInner = document.querySelector('.progress-bar');
    
    // File selection via browse button
    if (browseBtn && fileInput) {
        browseBtn.addEventListener('click', () => {
            fileInput.click();
        });
    }
    
    // Handle file selection
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelection);
    }
    
    // Drag and drop events
    if (dragArea) {
        dragArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            dragArea.classList.add('active');
        });
        
        dragArea.addEventListener('dragleave', () => {
            dragArea.classList.remove('active');
        });
        
        dragArea.addEventListener('drop', (e) => {
            e.preventDefault();
            dragArea.classList.remove('active');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                handleFileSelection();
            }
        });
    }
    
    // Handle form submission
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const file = fileInput.files[0];
            if (!file) {
                showAlert('Please select a file to upload.', 'danger');
                return;
            }
            
            const formData = new FormData(uploadForm);
            
            // Show progress bar
            progressBar.style.display = 'flex';
            uploadBtn.disabled = true;
            uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Uploading...';
            
            // Use AJAX for upload with progress tracking
            const xhr = new XMLHttpRequest();
            xhr.open('POST', uploadForm.getAttribute('action'), true);
            
            // Upload progress event
            xhr.upload.addEventListener('progress', function(e) {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    progressBarInner.style.width = percent + '%';
                    progressBarInner.textContent = percent + '%';
                }
            });
            
            // Handle response
            xhr.onload = function() {
                if (xhr.status === 200) {
                    // Redirect to the page returned by the server
                    window.location.href = xhr.responseURL;
                } else {
                    showAlert('Upload failed. Please try again.', 'danger');
                    uploadBtn.disabled = false;
                    uploadBtn.innerHTML = '<i class="fas fa-upload me-1"></i>Upload Media';
                }
            };
            
            // Handle errors
            xhr.onerror = function() {
                showAlert('An error occurred during the upload. Please try again.', 'danger');
                uploadBtn.disabled = false;
                uploadBtn.innerHTML = '<i class="fas fa-upload me-1"></i>Upload Media';
            };
            
            // Send form data
            xhr.send(formData);
        });
    }
    
    /**
     * Handle file selection
     */
    function handleFileSelection() {
        if (!fileInput || !fileInput.files || fileInput.files.length === 0) {
            resetPreview();
            return;
        }
        
        const file = fileInput.files[0];
        const fileType = file.type.split('/')[0];
        const fileExt = file.name.split('.').pop().toLowerCase();
        
        // Check if file is supported
        const supportedExts = ['mp4', 'webm', 'avi', 'mov', 'mp3', 'wav', 'ogg'];
        if (!supportedExts.includes(fileExt)) {
            showAlert('Please upload a supported file format (MP4, WEBM, AVI, MOV, MP3, WAV, OGG)', 'danger');
            fileInput.value = '';
            resetPreview();
            return;
        }
        
        // Update UI with file info
        updateFileInfo(file, fileType);
        
        // Create preview
        createPreview(file, fileType);
        
        // Enable upload button
        if (uploadBtn) {
            uploadBtn.disabled = false;
        }
    }
    
    /**
     * Update file info in UI
     * @param {File} file - Selected file
     * @param {string} fileType - Type of file (video/audio)
     */
    function updateFileInfo(file, fileType) {
        // Display file type
        const mediaTypeDisplay = document.getElementById('media-type-display');
        if (mediaTypeDisplay) {
            mediaTypeDisplay.innerHTML = `<i class="fas fa-${fileType === 'video' ? 'video' : 'music'} me-1"></i> ${fileType.toUpperCase()}`;
        }
        
        // Display file size
        const fileSizeDisplay = document.getElementById('file-size-display');
        if (fileSizeDisplay) {
            const fileSizeMB = (file.size / (1024 * 1024)).toFixed(2);
            fileSizeDisplay.innerHTML = `<i class="fas fa-weight me-1"></i> ${fileSizeMB} MB`;
        }
        
        // Get duration for audio/video
        const durationDisplay = document.getElementById('duration-display');
        const mediaElement = fileType === 'video' ? videoPreview : audioPreview;
        
        if (mediaElement && durationDisplay) {
            const objUrl = URL.createObjectURL(file);
            
            mediaElement.addEventListener('loadedmetadata', function() {
                const duration = mediaElement.duration;
                const minutes = Math.floor(duration / 60);
                const seconds = Math.floor(duration % 60);
                durationDisplay.innerHTML = `<i class="fas fa-clock me-1"></i> ${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }, { once: true });
            
            mediaElement.src = objUrl;
        }
    }
    
    /**
     * Create preview for selected file
     * @param {File} file - Selected file
     * @param {string} fileType - Type of file (video/audio)
     */
    function createPreview(file, fileType) {
        const objUrl = URL.createObjectURL(file);
        const previewContainer = document.getElementById('preview-container');
        
        if (previewContainer) {
            // Hide placeholder
            const placeholder = previewContainer.querySelector('div');
            if (placeholder) {
                placeholder.classList.add('d-none');
            }
            
            if (fileType === 'video' && videoPreview) {
                videoPreview.classList.remove('d-none');
                if (audioPreview) audioPreview.classList.add('d-none');
                videoPreview.src = objUrl;
            } else if (fileType === 'audio' && audioPreview) {
                if (videoPreview) videoPreview.classList.add('d-none');
                audioPreview.classList.remove('d-none');
                audioPreview.src = objUrl;
            }
        }
    }
    
    /**
     * Reset preview and info
     */
    function resetPreview() {
        if (uploadBtn) {
            uploadBtn.disabled = true;
        }
        
        if (videoPreview) {
            videoPreview.classList.add('d-none');
            videoPreview.src = '';
        }
        
        if (audioPreview) {
            audioPreview.classList.add('d-none');
            audioPreview.src = '';
        }
        
        const previewContainer = document.getElementById('preview-container');
        if (previewContainer) {
            const placeholder = previewContainer.querySelector('div');
            if (placeholder) {
                placeholder.classList.remove('d-none');
            }
        }
        
        const mediaTypeDisplay = document.getElementById('media-type-display');
        if (mediaTypeDisplay) {
            mediaTypeDisplay.innerHTML = `<i class="fas fa-question-circle me-1"></i> No file selected`;
        }
        
        const fileSizeDisplay = document.getElementById('file-size-display');
        if (fileSizeDisplay) {
            fileSizeDisplay.innerHTML = `<i class="fas fa-weight me-1"></i> 0 MB`;
        }
        
        const durationDisplay = document.getElementById('duration-display');
        if (durationDisplay) {
            durationDisplay.innerHTML = `<i class="fas fa-clock me-1"></i> 00:00`;
        }
    }
}

/**
 * Show alert message
 * @param {string} message - Alert message
 * @param {string} type - Alert type (success, danger, warning, info)
 */
function showAlert(message, type = 'info') {
    const alertPlaceholder = document.querySelector('.alert-placeholder');
    if (!alertPlaceholder) return;
    
    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    
    alertPlaceholder.append(wrapper);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alert = wrapper.querySelector('.alert');
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}
