/**
 * StreamApp Livestream Module
 * Handles WebRTC streaming functionality
 */

// Global variables
let localStream = null;
let peerConnection = null;
let roomId = null;
let streamKey = null;
let isLive = false;
let viewerCount = 0;
let turnConfig = {};

// Initialize when DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're in broadcaster or viewer mode
    const mode = document.getElementById('stream-mode')?.value;
    const streamIdInput = document.getElementById('stream-id');
    
    if (streamIdInput) {
        const streamId = streamIdInput.value;
        streamKey = document.getElementById('stream-key')?.value;
        
        // Load TURN configuration if available
        const turnConfigElement = document.getElementById('turn-config');
        if (turnConfigElement) {
            try {
                turnConfig = JSON.parse(turnConfigElement.textContent);
            } catch (e) {
                console.error('Error parsing TURN config', e);
            }
        }
        
        if (mode === 'broadcast' && streamId && streamKey) {
            initializeBroadcaster(streamId);
        } else if (mode === 'view' && streamId) {
            initializeViewer(streamId);
        }
    }
    
    // Set up stream control buttons
    setupStreamControls();
});

/**
 * Initialize broadcaster mode
 * @param {string} streamId - Stream ID
 */
function initializeBroadcaster(streamId) {
    const startBtn = document.getElementById('start-stream-btn');
    const stopBtn = document.getElementById('stop-stream-btn');
    const videoPreview = document.getElementById('local-video-preview');
    const streamStatus = document.getElementById('stream-status');
    
    if (startBtn) {
        startBtn.addEventListener('click', async function() {
            try {
                // Request camera and microphone access
                localStream = await navigator.mediaDevices.getUserMedia({
                    video: {
                        width: { ideal: 1280 },
                        height: { ideal: 720 },
                        frameRate: { ideal: 30 }
                    },
                    audio: true
                });
                
                // Show preview of camera
                if (videoPreview) {
                    videoPreview.srcObject = localStream;
                    videoPreview.play();
                }
                
                // Enable stop button
                startBtn.classList.add('d-none');
                stopBtn.classList.remove('d-none');
                
                // Start the stream on server
                startStream(streamId);
                
            } catch (error) {
                console.error('Error accessing media devices:', error);
                showAlert('Could not access camera or microphone. Please check your permissions.', 'danger');
            }
        });
    }
    
    if (stopBtn) {
        stopBtn.addEventListener('click', function() {
            // Stop local stream
            if (localStream) {
                localStream.getTracks().forEach(track => track.stop());
                localStream = null;
            }
            
            // Close peer connections
            if (peerConnection) {
                peerConnection.close();
                peerConnection = null;
            }
            
            // Reset video preview
            if (videoPreview) {
                videoPreview.srcObject = null;
            }
            
            // End stream on server
            endStream(streamId);
            
            // Update UI
            startBtn.classList.remove('d-none');
            stopBtn.classList.add('d-none');
            if (streamStatus) {
                streamStatus.textContent = 'Offline';
                streamStatus.className = 'badge bg-secondary';
            }
            
            isLive = false;
        });
    }
    
    // Auto-start if remember state is enabled
    const rememberState = localStorage.getItem(`stream_${streamId}_autostart`);
    if (rememberState === 'true' && startBtn) {
        startBtn.click();
    }
}

/**
 * Initialize viewer mode
 * @param {string} streamId - Stream ID
 */
function initializeViewer(streamId) {
    const videoElement = document.getElementById('stream-player');
    const streamStatus = document.getElementById('stream-status');
    
    // Check if stream is active
    checkStreamStatus(streamId);
    
    // Periodically check stream status and update view count
    setInterval(() => {
        checkStreamStatus(streamId);
    }, 10000);
}

/**
 * Start streaming to server
 * @param {string} streamId - Stream ID
 */
function startStream(streamId) {
    const streamStatus = document.getElementById('stream-status');
    const viewerCountElement = document.getElementById('viewer-count');
    
    // Start stream on server
    fetch(`/livestream/${streamId}/start`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update UI
            if (streamStatus) {
                streamStatus.textContent = 'Live';
                streamStatus.className = 'badge bg-danger';
            }
            
            isLive = true;
            roomId = data.session_info.session_id;
            
            // Set up WebRTC
            setupWebRTC(data.session_info);
            
            // Remember state for auto-restart if page reloads
            localStorage.setItem(`stream_${streamId}_autostart`, 'true');
            
            // Start periodic viewer count updates
            updateViewerCount(streamId);
            setInterval(() => updateViewerCount(streamId), 10000);
            
            showAlert('You are now live!', 'success');
        } else {
            showAlert(`Failed to start stream: ${data.message}`, 'danger');
        }
    })
    .catch(error => {
        console.error('Error starting stream:', error);
        showAlert('An error occurred while starting the stream', 'danger');
    });
}

/**
 * End streaming session
 * @param {string} streamId - Stream ID
 */
function endStream(streamId) {
    fetch(`/livestream/${streamId}/end`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Clean up local storage
            localStorage.removeItem(`stream_${streamId}_autostart`);
            showAlert('Stream ended successfully', 'info');
        } else {
            showAlert(`Failed to end stream: ${data.message}`, 'danger');
        }
    })
    .catch(error => {
        console.error('Error ending stream:', error);
        showAlert('An error occurred while ending the stream', 'danger');
    });
}

/**
 * Set up WebRTC connection
 * @param {Object} sessionInfo - WebRTC session information
 */
function setupWebRTC(sessionInfo) {
    const configuration = {
        iceServers: sessionInfo.ice_servers || [
            { urls: 'stun:stun.l.google.com:19302' }
        ]
    };
    
    // Create peer connection
    peerConnection = new RTCPeerConnection(configuration);
    
    // Add local stream tracks to peer connection
    if (localStream) {
        localStream.getTracks().forEach(track => {
            peerConnection.addTrack(track, localStream);
        });
    }
    
    // ICE candidate events
    peerConnection.onicecandidate = event => {
        if (event.candidate) {
            // Send ICE candidate to signaling server
            // (This would be implemented with WebSockets in production)
            console.log('ICE candidate', event.candidate);
        }
    };
    
    // ICE connection state change events
    peerConnection.oniceconnectionstatechange = event => {
        console.log('ICE connection state change:', peerConnection.iceConnectionState);
        
        if (peerConnection.iceConnectionState === 'disconnected' || 
            peerConnection.iceConnectionState === 'failed') {
            // Attempt to reconnect
            console.log('ICE disconnected, attempting to reconnect...');
        }
    };
    
    // Create and send offer
    peerConnection.createOffer()
        .then(offer => peerConnection.setLocalDescription(offer))
        .then(() => {
            // Send offer to signaling server
            // (This would be implemented with WebSockets in production)
            console.log('Created and set local offer', peerConnection.localDescription);
        })
        .catch(error => {
            console.error('Error creating offer:', error);
        });
}

/**
 * Check stream status
 * @param {string} streamId - Stream ID
 */
function checkStreamStatus(streamId) {
    fetch(`/livestream/${streamId}/status`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        const streamStatus = document.getElementById('stream-status');
        const viewerCountElement = document.getElementById('viewer-count');
        const videoContainer = document.getElementById('video-container');
        const offlineMessage = document.getElementById('offline-message');
        
        // Update stream status
        if (streamStatus) {
            if (data.active) {
                streamStatus.textContent = 'Live';
                streamStatus.className = 'badge bg-danger';
                
                if (offlineMessage) offlineMessage.classList.add('d-none');
                if (videoContainer) videoContainer.classList.remove('d-none');
            } else {
                streamStatus.textContent = 'Offline';
                streamStatus.className = 'badge bg-secondary';
                
                if (offlineMessage) offlineMessage.classList.remove('d-none');
                if (videoContainer) videoContainer.classList.add('d-none');
            }
        }
        
        // Update viewer count
        if (viewerCountElement) {
            viewerCountElement.textContent = data.viewer_count;
        }
    })
    .catch(error => {
        console.error('Error checking stream status:', error);
    });
}

/**
 * Update viewer count
 * @param {string} streamId - Stream ID
 */
function updateViewerCount(streamId) {
    fetch(`/livestream/${streamId}/viewers`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        const viewerCountElement = document.getElementById('viewer-count');
        if (viewerCountElement) {
            viewerCountElement.textContent = data.count;
            viewerCount = data.count;
        }
    })
    .catch(error => {
        console.error('Error updating viewer count:', error);
    });
}

/**
 * Set up stream control buttons
 */
function setupStreamControls() {
    // Mute/unmute button
    const muteBtn = document.getElementById('mute-btn');
    if (muteBtn) {
        muteBtn.addEventListener('click', function() {
            if (!localStream) return;
            
            const audioTracks = localStream.getAudioTracks();
            if (audioTracks.length === 0) return;
            
            const isEnabled = audioTracks[0].enabled;
            audioTracks[0].enabled = !isEnabled;
            
            // Update button icon
            if (isEnabled) {
                muteBtn.innerHTML = '<i class="fas fa-microphone-slash"></i>';
                muteBtn.classList.replace('btn-outline-primary', 'btn-outline-danger');
            } else {
                muteBtn.innerHTML = '<i class="fas fa-microphone"></i>';
                muteBtn.classList.replace('btn-outline-danger', 'btn-outline-primary');
            }
        });
    }
    
    // Video on/off button
    const videoBtn = document.getElementById('video-btn');
    if (videoBtn) {
        videoBtn.addEventListener('click', function() {
            if (!localStream) return;
            
            const videoTracks = localStream.getVideoTracks();
            if (videoTracks.length === 0) return;
            
            const isEnabled = videoTracks[0].enabled;
            videoTracks[0].enabled = !isEnabled;
            
            // Update button icon
            if (isEnabled) {
                videoBtn.innerHTML = '<i class="fas fa-video-slash"></i>';
                videoBtn.classList.replace('btn-outline-primary', 'btn-outline-danger');
            } else {
                videoBtn.innerHTML = '<i class="fas fa-video"></i>';
                videoBtn.classList.replace('btn-outline-danger', 'btn-outline-primary');
            }
        });
    }
    
    // Settings button
    const settingsBtn = document.getElementById('settings-btn');
    const settingsModal = document.getElementById('settings-modal');
    
    if (settingsBtn && settingsModal) {
        const settingsModalObj = new bootstrap.Modal(settingsModal);
        
        settingsBtn.addEventListener('click', function() {
            settingsModalObj.show();
        });
        
        // Apply settings button
        const applySettingsBtn = document.getElementById('apply-settings-btn');
        if (applySettingsBtn) {
            applySettingsBtn.addEventListener('click', function() {
                const videoQuality = document.getElementById('video-quality').value;
                const audioQuality = document.getElementById('audio-quality').value;
                
                // Apply settings
                if (localStream) {
                    const videoTracks = localStream.getVideoTracks();
                    if (videoTracks.length > 0) {
                        // Apply video constraints based on quality
                        const constraints = {};
                        
                        switch (videoQuality) {
                            case 'high':
                                constraints.width = 1920;
                                constraints.height = 1080;
                                constraints.frameRate = 30;
                                break;
                            case 'medium':
                                constraints.width = 1280;
                                constraints.height = 720;
                                constraints.frameRate = 30;
                                break;
                            case 'low':
                                constraints.width = 854;
                                constraints.height = 480;
                                constraints.frameRate = 25;
                                break;
                            case 'mobile':
                                constraints.width = 640;
                                constraints.height = 360;
                                constraints.frameRate = 20;
                                break;
                        }
                        
                        videoTracks[0].applyConstraints(constraints)
                            .then(() => {
                                console.log('Applied video constraints:', constraints);
                            })
                            .catch(error => {
                                console.error('Error applying video constraints:', error);
                            });
                    }
                    
                    // Apply audio constraints based on quality
                    // (In a real implementation, we would use different audio bitrates here)
                }
                
                // Close modal
                settingsModalObj.hide();
            });
        }
    }
    
    // Share button
    const shareBtn = document.getElementById('share-btn');
    if (shareBtn) {
        shareBtn.addEventListener('click', function() {
            const shareUrl = window.location.origin + `/livestream/${document.getElementById('stream-id').value}`;
            
            if (navigator.share) {
                navigator.share({
                    title: document.getElementById('stream-title').textContent,
                    text: 'Check out my live stream!',
                    url: shareUrl
                }).catch(error => {
                    console.error('Error sharing:', error);
                    copyToClipboard(shareUrl);
                });
            } else {
                copyToClipboard(shareUrl);
            }
        });
    }
}

/**
 * Copy text to clipboard
 * @param {string} text - Text to copy
 */
function copyToClipboard(text) {
    // Create temporary input element
    const input = document.createElement('input');
    input.style.position = 'fixed';
    input.style.opacity = 0;
    input.value = text;
    document.body.appendChild(input);
    
    // Select and copy
    input.select();
    document.execCommand('copy');
    
    // Clean up
    document.body.removeChild(input);
    
    showAlert('Stream link copied to clipboard!', 'success');
}

/**
 * Show alert message
 * @param {string} message - Alert message
 * @param {string} type - Alert type (success, danger, warning, info)
 */
function showAlert(message, type = 'info') {
    const alertPlaceholder = document.querySelector('.alert-placeholder');
    if (!alertPlaceholder) return;
    
    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    
    alertPlaceholder.append(wrapper);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alert = wrapper.querySelector('.alert');
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}
