/**
 * StreamVibe Advanced Analytics Module
 * Handles enhanced analytics dashboard functionality
 */

// Global variables for charts
let viewsChart = null;
let viewersChart = null;
let watchTimeChart = null;
let peakViewersChart = null;
let deviceChart = null;
let countryChart = null;
let engagementChart = null;
let referrerChart = null;
let growthChart = null;

// Initialize when DOM is fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Load summary data
    loadAnalyticsSummary();
    
    // Load detailed analytics
    loadAnalyticsData();
    
    // Load audience data
    loadAudienceData();
    
    // Set up filter controls
    setupFilterControls();
    
    // Set up tab navigation
    setupTabNavigation();
});

/**
 * Set up tab navigation for analytics sections
 */
function setupTabNavigation() {
    const tabLinks = document.querySelectorAll('.nav-link[data-bs-toggle="tab"]');
    
    tabLinks.forEach(link => {
        link.addEventListener('shown.bs.tab', event => {
            // Resize charts when tab becomes visible
            window.dispatchEvent(new Event('resize'));
        });
    });
}

/**
 * Set up filter controls for analytics
 */
function setupFilterControls() {
    const mediaSelect = document.getElementById('media-select');
    const streamSelect = document.getElementById('stream-select');
    const periodSelect = document.getElementById('period-select');
    const audiencePeriodSelect = document.getElementById('audience-period-select');
    
    // Handle changes to media selection
    if (mediaSelect) {
        mediaSelect.addEventListener('change', function() {
            // Clear stream selection if media is selected
            if (this.value && streamSelect) {
                streamSelect.value = '';
            }
            
            // Reload analytics data
            loadAnalyticsData();
        });
    }
    
    // Handle changes to stream selection
    if (streamSelect) {
        streamSelect.addEventListener('change', function() {
            // Clear media selection if stream is selected
            if (this.value && mediaSelect) {
                mediaSelect.value = '';
            }
            
            // Reload analytics data
            loadAnalyticsData();
        });
    }
    
    // Handle changes to period selection
    if (periodSelect) {
        periodSelect.addEventListener('change', function() {
            // Reload analytics data
            loadAnalyticsData();
        });
    }
    
    // Handle changes to audience period selection
    if (audiencePeriodSelect) {
        audiencePeriodSelect.addEventListener('change', function() {
            // Reload audience data
            loadAudienceData();
        });
    }
}

/**
 * Load analytics summary data
 */
function loadAnalyticsSummary() {
    fetch('/analytics/summary', {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Update total stats
        document.getElementById('total-media-views').textContent = data.total_media_views.toLocaleString();
        document.getElementById('total-media-count').textContent = data.total_media_count.toLocaleString();
        document.getElementById('total-stream-count').textContent = data.total_stream_count.toLocaleString();
        
        // Update watch time if available
        if (data.total_watch_time_minutes !== undefined) {
            const watchTimeElement = document.getElementById('total-watch-time');
            if (watchTimeElement) {
                watchTimeElement.textContent = formatWatchTime(data.total_watch_time_minutes);
            }
        }
        
        // Update engagement rate if available
        if (data.avg_engagement_rate !== undefined) {
            const engagementElement = document.getElementById('avg-engagement-rate');
            if (engagementElement) {
                engagementElement.textContent = `${data.avg_engagement_rate}%`;
            }
        }
        
        // Update growth data if available
        if (data.growth) {
            const growthElement = document.getElementById('views-growth');
            if (growthElement) {
                const growthValue = data.growth.views_percent;
                const growthClass = growthValue >= 0 ? 'text-success' : 'text-danger';
                const growthIcon = growthValue >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
                growthElement.innerHTML = `<span class="${growthClass}"><i class="fas ${growthIcon} me-1"></i>${Math.abs(growthValue)}%</span>`;
            }
            
            // Render growth chart if element exists
            const growthChartElement = document.getElementById('growth-chart');
            if (growthChartElement) {
                renderGrowthChart(data.growth);
            }
        }
        
        // Update most viewed media
        const mostViewedMediaElement = document.getElementById('most-viewed-media');
        if (mostViewedMediaElement && data.most_viewed_media) {
            mostViewedMediaElement.textContent = `${data.most_viewed_media.title}`;
            
            const viewCountElement = document.getElementById('most-viewed-media-count');
            if (viewCountElement) {
                viewCountElement.textContent = `${data.most_viewed_media.views.toLocaleString()} views`;
            }
            
            // Add link to the media
            const linkElement = document.getElementById('most-viewed-media-link');
            if (linkElement) {
                linkElement.href = `/media/${data.most_viewed_media.id}`;
            }
        }
        
        // Update most viewed stream
        const mostViewedStreamElement = document.getElementById('most-viewed-stream');
        if (mostViewedStreamElement && data.most_viewed_stream) {
            mostViewedStreamElement.textContent = `${data.most_viewed_stream.title}`;
            
            const viewerCountElement = document.getElementById('most-viewed-stream-count');
            if (viewerCountElement) {
                viewerCountElement.textContent = `${data.most_viewed_stream.viewers.toLocaleString()} viewers`;
            }
            
            // Add link to the stream
            const linkElement = document.getElementById('most-viewed-stream-link');
            if (linkElement) {
                linkElement.href = `/livestream/${data.most_viewed_stream.id}`;
            }
        }
        
        // Update trending content
        if (data.trending_media) {
            const trendingMediaElement = document.getElementById('trending-media');
            if (trendingMediaElement) {
                trendingMediaElement.textContent = data.trending_media.title;
                
                const linkElement = document.getElementById('trending-media-link');
                if (linkElement) {
                    linkElement.href = `/media/${data.trending_media.id}`;
                }
            }
        }
        
        if (data.trending_stream) {
            const trendingStreamElement = document.getElementById('trending-stream');
            if (trendingStreamElement) {
                trendingStreamElement.textContent = data.trending_stream.title;
                
                const linkElement = document.getElementById('trending-stream-link');
                if (linkElement) {
                    linkElement.href = `/livestream/${data.trending_stream.id}`;
                }
            }
        }
        
        // Update device breakdown if available
        if (data.devices) {
            // Create a simple device donut chart if element exists
            const deviceBreakdownElement = document.getElementById('device-breakdown-chart');
            if (deviceBreakdownElement) {
                renderDeviceBreakdownChart(data.devices);
            }
        }
    })
    .catch(error => {
        console.error('Error loading analytics summary:', error);
        showAlert('Failed to load analytics summary data', 'danger');
    });
}

/**
 * Load detailed analytics data
 */
function loadAnalyticsData() {
    // Get filter values
    const mediaId = document.getElementById('media-select')?.value || '';
    const streamId = document.getElementById('stream-select')?.value || '';
    const period = document.getElementById('period-select')?.value || 'week';
    
    // Show loading state
    document.getElementById('analytics-loading').classList.remove('d-none');
    document.getElementById('analytics-charts').classList.add('d-none');
    
    // Build query params
    const params = new URLSearchParams();
    if (mediaId) params.append('media_id', mediaId);
    if (streamId) params.append('stream_id', streamId);
    params.append('period', period);
    
    // Fetch analytics data
    fetch(`/analytics/data?${params.toString()}`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Hide loading state
        document.getElementById('analytics-loading').classList.add('d-none');
        document.getElementById('analytics-charts').classList.remove('d-none');
        
        // Update total stats
        document.getElementById('total-views').textContent = data.total_stats.total_views.toLocaleString();
        document.getElementById('total-unique-viewers').textContent = data.total_stats.total_unique_viewers.toLocaleString();
        document.getElementById('total-watch-time').textContent = formatWatchTime(data.total_stats.total_watch_time);
        document.getElementById('max-peak-viewers').textContent = data.total_stats.max_peak_viewers.toLocaleString();
        
        // Update advanced stats if elements exist
        if (document.getElementById('avg-session-duration')) {
            document.getElementById('avg-session-duration').textContent = formatWatchTime(data.total_stats.avg_session_duration);
        }
        
        if (document.getElementById('avg-engagement-rate')) {
            document.getElementById('avg-engagement-rate').textContent = `${(data.total_stats.avg_engagement_rate * 100).toFixed(1)}%`;
        }
        
        if (document.getElementById('avg-bounce-rate')) {
            document.getElementById('avg-bounce-rate').textContent = `${(data.total_stats.avg_bounce_rate * 100).toFixed(1)}%`;
        }
        
        // Render charts
        renderDetailedCharts(data);
    })
    .catch(error => {
        console.error('Error loading analytics data:', error);
        document.getElementById('analytics-loading').classList.add('d-none');
        showAlert('Failed to load analytics data', 'danger');
    });
}

/**
 * Load audience analytics data
 */
function loadAudienceData() {
    // Get filter values
    const period = document.getElementById('audience-period-select')?.value || 'month';
    
    // Show loading state
    const loadingElement = document.getElementById('audience-loading');
    const chartsElement = document.getElementById('audience-charts');
    
    if (loadingElement) loadingElement.classList.remove('d-none');
    if (chartsElement) chartsElement.classList.add('d-none');
    
    // Build query params
    const params = new URLSearchParams();
    params.append('period', period);
    
    // Fetch audience data
    fetch(`/analytics/audience?${params.toString()}`, {
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(response => response.json())
    .then(data => {
        // Hide loading state
        if (loadingElement) loadingElement.classList.add('d-none');
        if (chartsElement) chartsElement.classList.remove('d-none');
        
        // Render audience charts
        renderAudienceCharts(data);
    })
    .catch(error => {
        console.error('Error loading audience data:', error);
        if (loadingElement) loadingElement.classList.add('d-none');
        showAlert('Failed to load audience data', 'danger');
    });
}

/**
 * Render detailed analytics charts
 * @param {Object} data - Analytics data
 */
function renderDetailedCharts(data) {
    // Common chart options
    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            x: {
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                    color: 'rgba(255, 255, 255, 0.7)'
                }
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: 'rgba(255, 255, 255, 0.1)'
                },
                ticks: {
                    color: 'rgba(255, 255, 255, 0.7)'
                }
            }
        },
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                mode: 'index',
                intersect: false
            }
        }
    };
    
    // Views chart
    renderViewsChart(data.dates, data.views, chartOptions);
    
    // Unique viewers chart
    renderViewersChart(data.dates, data.unique_viewers, chartOptions);
    
    // Watch time chart
    renderWatchTimeChart(data.dates, data.watch_time, chartOptions);
    
    // Peak viewers chart
    renderPeakViewersChart(data.dates, data.peak_viewers, chartOptions);
    
    // Render device chart if element exists
    const deviceChartElement = document.getElementById('device-chart');
    if (deviceChartElement) {
        renderDeviceChart(data.dates, data.device_mobile, data.device_desktop, 
                         data.device_tablet, data.device_other, chartOptions);
    }
    
    // Render engagement chart if element exists
    const engagementChartElement = document.getElementById('engagement-chart');
    if (engagementChartElement) {
        renderEngagementChart(data.dates, data.engagement_rate, data.bounce_rate, chartOptions);
    }
    
    // Render country distribution chart if element exists
    const countryChartElement = document.getElementById('country-chart');
    if (countryChartElement && data.country_data) {
        renderCountryChart(data.country_data);
    }
    
    // Render referrer chart if element exists
    const referrerChartElement = document.getElementById('referrer-chart');
    if (referrerChartElement && data.referrer_data) {
        renderReferrerChart(data.referrer_data);
    }
}

/**
 * Render audience charts
 * @param {Object} data - Audience data
 */
function renderAudienceCharts(data) {
    // Render device breakdown chart
    if (data.devices) {
        const deviceChartElement = document.getElementById('audience-device-chart');
        if (deviceChartElement) {
            renderDeviceBreakdownChart(data.devices, 'audience-device-chart');
        }
    }
    
    // Render country map chart
    if (data.countries) {
        const countryChartElement = document.getElementById('audience-country-chart');
        if (countryChartElement) {
            renderCountryChart(data.countries, 'audience-country-chart');
        }
    }
    
    // Render referrer chart
    if (data.referrers) {
        const referrerChartElement = document.getElementById('audience-referrer-chart');
        if (referrerChartElement) {
            renderReferrerChart(data.referrers, 'audience-referrer-chart');
        }
    }
}

/**
 * Render views chart
 * @param {Array} dates - Date labels
 * @param {Array} views - Views data
 * @param {Object} options - Chart options
 */
function renderViewsChart(dates, views, options) {
    const ctx = document.getElementById('views-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (viewsChart) {
        viewsChart.destroy();
    }
    
    // Create new chart
    viewsChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Views',
                data: views,
                backgroundColor: 'rgba(13, 110, 253, 0.2)',
                borderColor: 'rgba(13, 110, 253, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(13, 110, 253, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3,
                fill: true
            }]
        },
        options: options
    });
}

/**
 * Render unique viewers chart
 * @param {Array} dates - Date labels
 * @param {Array} viewers - Viewers data
 * @param {Object} options - Chart options
 */
function renderViewersChart(dates, viewers, options) {
    const ctx = document.getElementById('viewers-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (viewersChart) {
        viewersChart.destroy();
    }
    
    // Create new chart
    viewersChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Unique Viewers',
                data: viewers,
                backgroundColor: 'rgba(25, 135, 84, 0.2)',
                borderColor: 'rgba(25, 135, 84, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(25, 135, 84, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3,
                fill: true
            }]
        },
        options: options
    });
}

/**
 * Render watch time chart
 * @param {Array} dates - Date labels
 * @param {Array} watchTime - Watch time data
 * @param {Object} options - Chart options
 */
function renderWatchTimeChart(dates, watchTime, options) {
    const ctx = document.getElementById('watch-time-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (watchTimeChart) {
        watchTimeChart.destroy();
    }
    
    // Create new chart
    watchTimeChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Watch Time (minutes)',
                data: watchTime,
                backgroundColor: 'rgba(255, 193, 7, 0.2)',
                borderColor: 'rgba(255, 193, 7, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(255, 193, 7, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3,
                fill: true
            }]
        },
        options: options
    });
}

/**
 * Render peak viewers chart
 * @param {Array} dates - Date labels
 * @param {Array} peakViewers - Peak viewers data
 * @param {Object} options - Chart options
 */
function renderPeakViewersChart(dates, peakViewers, options) {
    const ctx = document.getElementById('peak-viewers-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (peakViewersChart) {
        peakViewersChart.destroy();
    }
    
    // Create new chart
    peakViewersChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [{
                label: 'Peak Viewers',
                data: peakViewers,
                backgroundColor: 'rgba(220, 53, 69, 0.2)',
                borderColor: 'rgba(220, 53, 69, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(220, 53, 69, 1)',
                pointBorderColor: '#fff',
                pointRadius: 4,
                tension: 0.3,
                fill: true
            }]
        },
        options: options
    });
}

/**
 * Render device breakdown chart
 * @param {Object} deviceData - Device breakdown data
 * @param {string} elementId - Chart element ID (optional)
 */
function renderDeviceBreakdownChart(deviceData, elementId = 'device-breakdown-chart') {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Dispose previous chart if it exists
    if (deviceChart) {
        deviceChart.destroy();
    }
    
    // Create new chart
    deviceChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Mobile', 'Desktop', 'Tablet', 'Other'],
            datasets: [{
                data: [
                    deviceData.mobile || 0,
                    deviceData.desktop || 0,
                    deviceData.tablet || 0,
                    deviceData.other || 0
                ],
                backgroundColor: [
                    'rgba(13, 110, 253, 0.8)',    // Blue
                    'rgba(25, 135, 84, 0.8)',     // Green
                    'rgba(255, 193, 7, 0.8)',     // Yellow
                    'rgba(108, 117, 125, 0.8)'    // Gray
                ],
                borderColor: 'rgba(255, 255, 255, 0.1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        font: {
                            size: 12
                        },
                        generateLabels: function(chart) {
                            const data = chart.data;
                            if (data.labels.length && data.datasets.length) {
                                return data.labels.map(function(label, i) {
                                    const value = data.datasets[0].data[i];
                                    return {
                                        text: `${label}: ${value}%`,
                                        fillStyle: data.datasets[0].backgroundColor[i],
                                        strokeStyle: data.datasets[0].borderColor,
                                        lineWidth: data.datasets[0].borderWidth,
                                        hidden: isNaN(data.datasets[0].data[i]) || chart.getDatasetMeta(0).data[i].hidden,
                                        index: i
                                    };
                                });
                            }
                            return [];
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.raw || 0;
                            return `${label}: ${value}%`;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Render device chart
 * @param {Array} dates - Date labels
 * @param {Array} mobile - Mobile device data
 * @param {Array} desktop - Desktop device data
 * @param {Array} tablet - Tablet device data
 * @param {Array} other - Other device data
 * @param {Object} options - Chart options
 */
function renderDeviceChart(dates, mobile, desktop, tablet, other, options) {
    const ctx = document.getElementById('device-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (deviceChart) {
        deviceChart.destroy();
    }
    
    // Create new chart
    deviceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dates,
            datasets: [
                {
                    label: 'Mobile',
                    data: mobile,
                    backgroundColor: 'rgba(13, 110, 253, 0.8)',
                    borderColor: 'rgba(13, 110, 253, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Desktop',
                    data: desktop,
                    backgroundColor: 'rgba(25, 135, 84, 0.8)',
                    borderColor: 'rgba(25, 135, 84, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Tablet',
                    data: tablet,
                    backgroundColor: 'rgba(255, 193, 7, 0.8)',
                    borderColor: 'rgba(255, 193, 7, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Other',
                    data: other,
                    backgroundColor: 'rgba(108, 117, 125, 0.8)',
                    borderColor: 'rgba(108, 117, 125, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            ...options,
            plugins: {
                ...options.plugins,
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                }
            },
            scales: {
                ...options.scales,
                y: {
                    ...options.scales.y,
                    stacked: true
                },
                x: {
                    ...options.scales.x,
                    stacked: true
                }
            }
        }
    });
}

/**
 * Render engagement chart
 * @param {Array} dates - Date labels
 * @param {Array} engagement - Engagement rate data
 * @param {Array} bounce - Bounce rate data
 * @param {Object} options - Chart options
 */
function renderEngagementChart(dates, engagement, bounce, options) {
    const ctx = document.getElementById('engagement-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (engagementChart) {
        engagementChart.destroy();
    }
    
    // Create new chart
    engagementChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [
                {
                    label: 'Engagement Rate',
                    data: engagement.map(rate => rate * 100),  // Convert to percentage
                    backgroundColor: 'rgba(13, 202, 240, 0.2)',
                    borderColor: 'rgba(13, 202, 240, 1)',
                    borderWidth: 2,
                    pointBackgroundColor: 'rgba(13, 202, 240, 1)',
                    pointBorderColor: '#fff',
                    pointRadius: 4,
                    tension: 0.3,
                    yAxisID: 'y'
                },
                {
                    label: 'Bounce Rate',
                    data: bounce.map(rate => rate * 100),  // Convert to percentage
                    backgroundColor: 'rgba(253, 126, 20, 0.2)',
                    borderColor: 'rgba(253, 126, 20, 1)',
                    borderWidth: 2,
                    pointBackgroundColor: 'rgba(253, 126, 20, 1)',
                    pointBorderColor: '#fff',
                    pointRadius: 4,
                    tension: 0.3,
                    yAxisID: 'y'
                }
            ]
        },
        options: {
            ...options,
            plugins: {
                ...options.plugins,
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.dataset.label}: ${context.raw.toFixed(1)}%`;
                        }
                    }
                }
            },
            scales: {
                ...options.scales,
                y: {
                    ...options.scales.y,
                    title: {
                        display: true,
                        text: 'Percentage (%)',
                        color: 'rgba(255, 255, 255, 0.7)'
                    },
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

/**
 * Render country distribution chart
 * @param {Object} countryData - Country distribution data
 * @param {string} elementId - Chart element ID (optional)
 */
function renderCountryChart(countryData, elementId = 'country-chart') {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Extract labels and data
    const labels = Object.keys(countryData);
    const data = Object.values(countryData);
    
    // Dispose previous chart if it exists
    if (countryChart) {
        countryChart.destroy();
    }
    
    // Create new chart
    countryChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Viewers by Country',
                data: data,
                backgroundColor: 'rgba(13, 110, 253, 0.8)',
                borderColor: 'rgba(13, 110, 253, 1)',
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            }
        }
    });
}

/**
 * Render referrer distribution chart
 * @param {Object} referrerData - Referrer distribution data
 * @param {string} elementId - Chart element ID (optional)
 */
function renderReferrerChart(referrerData, elementId = 'referrer-chart') {
    const ctx = document.getElementById(elementId).getContext('2d');
    
    // Extract labels and data
    const labels = Object.keys(referrerData);
    const data = Object.values(referrerData);
    
    // Generate colors
    const colors = [
        'rgba(13, 110, 253, 0.8)',   // Blue
        'rgba(25, 135, 84, 0.8)',    // Green
        'rgba(255, 193, 7, 0.8)',    // Yellow
        'rgba(220, 53, 69, 0.8)',    // Red
        'rgba(13, 202, 240, 0.8)'    // Cyan
    ];
    
    // Dispose previous chart if it exists
    if (referrerChart) {
        referrerChart.destroy();
    }
    
    // Create new chart
    referrerChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: colors,
                borderColor: 'rgba(255, 255, 255, 0.1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        color: 'rgba(255, 255, 255, 0.7)',
                        font: {
                            size: 12
                        }
                    }
                }
            }
        }
    });
}

/**
 * Render growth chart
 * @param {Object} growthData - Growth data
 */
function renderGrowthChart(growthData) {
    const ctx = document.getElementById('growth-chart').getContext('2d');
    
    // Dispose previous chart if it exists
    if (growthChart) {
        growthChart.destroy();
    }
    
    // Create new chart
    growthChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Previous Month', 'Current Month'],
            datasets: [{
                label: 'Views',
                data: [growthData.previous_month_views, growthData.current_month_views],
                backgroundColor: [
                    'rgba(108, 117, 125, 0.8)',  // Gray for previous
                    'rgba(13, 110, 253, 0.8)'    // Blue for current
                ],
                borderColor: [
                    'rgba(108, 117, 125, 1)',
                    'rgba(13, 110, 253, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.7)'
                    }
                }
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Views: ${context.raw.toLocaleString()}`;
                        },
                        afterBody: function(items) {
                            if (items.length > 1) return null;
                            
                            // Only show growth percentage for current month
                            if (items[0].dataIndex === 1) {
                                const growth = growthData.views_percent;
                                const prefix = growth >= 0 ? '+' : '';
                                return `Growth: ${prefix}${growth}%`;
                            }
                            return null;
                        }
                    }
                }
            }
        }
    });
}

/**
 * Format watch time for display
 * @param {number} minutes - Watch time in minutes
 * @returns {string} Formatted watch time
 */
function formatWatchTime(minutes) {
    if (typeof minutes !== 'number') return '0 minutes';
    
    if (minutes < 60) {
        return `${Math.round(minutes)} minute${minutes !== 1 ? 's' : ''}`;
    } else {
        const hours = Math.floor(minutes / 60);
        const mins = Math.round(minutes % 60);
        return `${hours} hour${hours !== 1 ? 's' : ''}${mins > 0 ? ` ${mins} minute${mins !== 1 ? 's' : ''}` : ''}`;
    }
}

/**
 * Record analytics event
 * @param {Object} eventData - Event data
 */
function recordAnalyticsEvent(eventData) {
    fetch('/analytics/events', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify(eventData)
    })
    .then(response => response.json())
    .then(data => {
        if (!data.success) {
            console.error('Error recording analytics event:', data.error);
        }
    })
    .catch(error => {
        console.error('Error recording analytics event:', error);
    });
}

/**
 * Generate a unique session ID for analytics
 * @returns {string} Session ID
 */
function generateSessionId() {
    return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

/**
 * Get device type
 * @returns {string} Device type (mobile, desktop, tablet, or other)
 */
function getDeviceType() {
    const userAgent = navigator.userAgent;
    
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent)) {
        if (/iPad|Android 3|Android 4.[3-9].*Tablet|Opera.*Tablet|Nexus.*Tablet|Kindle.*Tablet/i.test(userAgent)) {
            return 'tablet';
        }
        return 'mobile';
    }
    
    return 'desktop';
}

/**
 * Get browser information
 * @returns {string} Browser name
 */
function getBrowser() {
    const userAgent = navigator.userAgent;
    
    if (userAgent.indexOf('Chrome') > -1) return 'Chrome';
    if (userAgent.indexOf('Safari') > -1) return 'Safari';
    if (userAgent.indexOf('Firefox') > -1) return 'Firefox';
    if (userAgent.indexOf('Edge') > -1) return 'Edge';
    if (userAgent.indexOf('MSIE') > -1 || userAgent.indexOf('Trident/') > -1) return 'Internet Explorer';
    
    return 'Unknown';
}

/**
 * Get operating system information
 * @returns {string} OS name
 */
function getOS() {
    const userAgent = navigator.userAgent;
    
    if (userAgent.indexOf('Windows') > -1) return 'Windows';
    if (userAgent.indexOf('Mac OS') > -1) return 'macOS';
    if (userAgent.indexOf('Linux') > -1) return 'Linux';
    if (userAgent.indexOf('Android') > -1) return 'Android';
    if (userAgent.indexOf('iOS') > -1) return 'iOS';
    
    return 'Unknown';
}

/**
 * Show alert message
 * @param {string} message - Alert message
 * @param {string} type - Alert type (success, danger, warning, info)
 */
function showAlert(message, type = 'info') {
    const alertPlaceholder = document.querySelector('.alert-placeholder');
    if (!alertPlaceholder) return;
    
    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    
    alertPlaceholder.append(wrapper);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alert = wrapper.querySelector('.alert');
        if (alert) {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }
    }, 5000);
}