#!/bin/bash
# StreamVibe Project Packaging Script
# This script packages your existing StreamVibe project into a single folder for easy deployment

# Set output directory and file
OUTPUT_DIR="streamvibe-package"
OUTPUT_FILE="streamvibe.zip"

# Colors for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print status
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Function to print success
print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Function to print error
print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Create the output directory
print_status "Creating package directory..."
mkdir -p $OUTPUT_DIR

# Package essential files
print_status "Copying essential files..."

# Copy main application files
cp app.py $OUTPUT_DIR/
cp main.py $OUTPUT_DIR/
cp models.py $OUTPUT_DIR/
cp config.py $OUTPUT_DIR/

# Create simplified structure
print_status "Creating simplified directory structure..."
mkdir -p $OUTPUT_DIR/static
mkdir -p $OUTPUT_DIR/templates
mkdir -p $OUTPUT_DIR/uploads

# Create routes directory and merge routes into one file
print_status "Merging routes into a single file..."
cat > $OUTPUT_DIR/routes.py << 'EOF'
# Combined routes file for StreamVibe
# This file contains all the route handlers from individual route files

from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify, abort, send_from_directory
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import os
import uuid
import datetime
from app import app, db
from models import User, Media, Stream, Comment, Analytics, AnalyticsEvent

# Function for requiring admin access
def admin_required(f):
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You need admin privileges to access this page', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

# Auth routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Please enter both username and password', 'danger')
            return render_template('login.html')
            
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('register.html')
            
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create new user
        user = User(
            username=username,
            email=email,
            created_at=datetime.datetime.utcnow()
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

# Main routes
@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

# Media routes
@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        file = request.files.get('media_file')
        
        if not title or not file:
            flash('Title and file are required', 'danger')
            return render_template('upload.html')
            
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(uuid.uuid4()) + '_' + filename)
        
        # Determine media type from file extension
        media_type = 'video' if filename.lower().endswith(('.mp4', '.mov', '.avi', '.mkv')) else 'audio'
        
        # Save the file
        file.save(file_path)
        
        # Create media record
        media = Media(
            title=title,
            description=description,
            file_path=file_path,
            media_type=media_type,
            user_id=current_user.id
        )
        
        db.session.add(media)
        db.session.commit()
        
        flash('Media uploaded successfully!', 'success')
        return redirect(url_for('dashboard'))
        
    return render_template('upload.html')

@app.route('/media/<int:media_id>')
def view_media(media_id):
    media = Media.query.get_or_404(media_id)
    return render_template('view_media.html', media=media)

# Stream routes
@app.route('/streams')
def list_streams():
    streams = Stream.query.filter_by(is_live=True).all()
    return render_template('streams.html', streams=streams)

@app.route('/stream/create', methods=['GET', 'POST'])
@login_required
def create_stream():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        
        if not title:
            flash('Title is required', 'danger')
            return render_template('create_stream.html')
            
        # Generate a unique stream key
        stream_key = str(uuid.uuid4())
        
        # Create stream record
        stream = Stream(
            title=title,
            description=description,
            stream_key=stream_key,
            user_id=current_user.id
        )
        
        db.session.add(stream)
        db.session.commit()
        
        flash('Stream created successfully!', 'success')
        return redirect(url_for('view_stream', stream_id=stream.id))
        
    return render_template('create_stream.html')

@app.route('/stream/<int:stream_id>')
def view_stream(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    return render_template('view_stream.html', stream=stream)

@app.route('/stream/auth')
def auth_stream():
    # RTMP authentication endpoint
    stream_key = request.args.get('name')
    if not stream_key:
        return '', 403
        
    stream = Stream.query.filter_by(stream_key=stream_key).first()
    if not stream:
        return '', 403
        
    # Mark stream as live
    stream.is_live = True
    stream.started_at = datetime.datetime.utcnow()
    db.session.commit()
    
    return '', 200

@app.route('/stream/done')
def done_stream():
    # RTMP done callback
    stream_key = request.args.get('name')
    if not stream_key:
        return '', 200
        
    stream = Stream.query.filter_by(stream_key=stream_key).first()
    if stream:
        stream.is_live = False
        stream.ended_at = datetime.datetime.utcnow()
        db.session.commit()
    
    return '', 200

# Admin routes
@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    return render_template('admin/dashboard.html')

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    users = User.query.all()
    return render_template('admin/users.html', users=users)

@app.route('/admin/media')
@login_required
@admin_required
def admin_media():
    media = Media.query.all()
    return render_template('admin/media.html', media=media)

@app.route('/admin/streams')
@login_required
@admin_required
def admin_streams():
    streams = Stream.query.all()
    return render_template('admin/streams.html', streams=streams)

# Static file routes
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
EOF

# Create simplified main file
print_status "Creating simplified main application file..."
cat > $OUTPUT_DIR/app.py << 'EOF'
import os
import logging
import datetime
import uuid
from flask import Flask, render_template, redirect, url_for, flash, request, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Base class for SQLAlchemy models
class Base(DeclarativeBase):
    pass

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "development-secret-key")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///streamvibe.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")
app.config["DEBUG"] = True

# Make sure upload folder exists
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Create database tables
with app.app_context():
    try:
        # Import models
        from models import User, Media, Stream, Comment, Analytics, AnalyticsEvent
        
        # Create tables
        db.create_all()
        
        # Check if admin user exists
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            # Create admin user
            admin = User(
                username='admin',
                email='admin@streamvibe.biz',
                is_admin=True
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            logger.info("Admin user created")
        
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Error initializing database: {e}")

# Import routes
from routes import *

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
EOF

# Create simplified models file
print_status "Creating simplified models file..."
cat > $OUTPUT_DIR/models.py << 'EOF'
import datetime
import uuid
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    profile_description = db.Column(db.Text, nullable=True)
    avatar_path = db.Column(db.String(255), nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    media_items = db.relationship('Media', backref='owner', lazy='dynamic')
    streams = db.relationship('Stream', backref='owner', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Media(db.Model):
    __tablename__ = 'media'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=False)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    media_type = db.Column(db.String(20), nullable=False)  # video, audio
    duration = db.Column(db.Integer, nullable=True)  # Duration in seconds
    views = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Additional fields
    quality_options = db.Column(db.String(255), nullable=True)  # JSON string of available quality options
    tags = db.Column(db.String(255), nullable=True)  # Comma-separated tags
    
    comments = db.relationship('Comment', backref='media', lazy='dynamic')
    
    def __repr__(self):
        return f'<Media {self.title}>'

class Stream(db.Model):
    __tablename__ = 'streams'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    stream_key = db.Column(db.String(64), unique=True, nullable=False)
    is_live = db.Column(db.Boolean, default=False)
    viewers = db.Column(db.Integer, default=0)
    started_at = db.Column(db.DateTime, nullable=True)
    ended_at = db.Column(db.DateTime, nullable=True)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Additional fields
    is_public = db.Column(db.Boolean, default=True)
    tags = db.Column(db.String(255), nullable=True)  # Comma-separated tags
    
    comments = db.relationship('Comment', backref='stream', lazy='dynamic')
    
    def __repr__(self):
        return f'<Stream {self.title}>'

class Comment(db.Model):
    __tablename__ = 'comments'
    
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    
    user = db.relationship('User', backref='comments')
    
    def __repr__(self):
        return f'<Comment {self.id}>'

class Analytics(db.Model):
    __tablename__ = 'analytics'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    views = db.Column(db.Integer, default=0)
    unique_viewers = db.Column(db.Integer, default=0)
    watch_time = db.Column(db.Integer, default=0)  # In seconds
    peak_viewers = db.Column(db.Integer, default=0)
    device_mobile = db.Column(db.Integer, default=0)  # Mobile viewers count
    device_desktop = db.Column(db.Integer, default=0)  # Desktop viewers count
    device_tablet = db.Column(db.Integer, default=0)  # Tablet viewers count
    device_other = db.Column(db.Integer, default=0)  # Other device viewers count
    avg_watch_duration = db.Column(db.Float, default=0.0)  # Average watch duration in seconds
    engagement_rate = db.Column(db.Float, default=0.0)  # Percentage of engagement (interactions/views)
    bounce_rate = db.Column(db.Float, default=0.0)  # Percentage of viewers who leave quickly
    country_data = db.Column(db.Text, nullable=True)  # JSON string of country distribution
    referrer_data = db.Column(db.Text, nullable=True)  # JSON string of traffic sources
    
    user = db.relationship('User', backref='analytics')
    media = db.relationship('Media', backref='analytics_data')
    stream = db.relationship('Stream', backref='analytics_data')
    
    def __repr__(self):
        return f'<Analytics {self.id}>'

class AnalyticsEvent(db.Model):
    """Detailed analytics events for user interactions"""
    __tablename__ = 'analytics_events'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    event_type = db.Column(db.String(50), nullable=False)  # view, play, pause, seek, end, etc.
    value = db.Column(db.Float, nullable=True)  # Custom value for event (e.g. seek position)
    session_id = db.Column(db.String(64), nullable=False)  # Unique viewer session
    device_type = db.Column(db.String(20), nullable=True)  # mobile, desktop, tablet, etc.
    browser = db.Column(db.String(50), nullable=True)  # Browser information
    os = db.Column(db.String(50), nullable=True)  # Operating system
    country_code = db.Column(db.String(2), nullable=True)  # ISO country code
    referrer = db.Column(db.String(255), nullable=True)  # Where the viewer came from
    
    user = db.relationship('User', backref='analytics_events')
    
    def __repr__(self):
        return f'<AnalyticsEvent {self.id}>'
EOF

# Create simplified main.py
print_status "Creating simplified main.py..."
cat > $OUTPUT_DIR/main.py << 'EOF'
from app import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
EOF

# Copy essential templates
print_status "Copying templates..."
cp -r templates/* $OUTPUT_DIR/templates/

# Copy static assets
print_status "Copying static assets..."
cp -r static/* $OUTPUT_DIR/static/

# Create installation script
print_status "Creating installation script..."
cat > $OUTPUT_DIR/install.sh << 'EOF'
#!/bin/bash
# Simple installation script for StreamVibe

DOMAIN_NAME="streamvibe.biz"
DB_NAME="streamvibe"
DB_USER="streamvibe_user"
DB_PASS=$(openssl rand -base64 12 | tr -d "=+/" | cut -c1-16)
ADMIN_USER="admin"
ADMIN_EMAIL="admin@streamvibe.biz"
ADMIN_PASS="admin123"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root"
    exit 1
fi

# Install dependencies
apt update
apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib \
    ffmpeg build-essential libssl-dev libpcre3-dev zlib1g-dev \
    curl wget git unzip libnginx-mod-rtmp

# Setup database
systemctl start postgresql
systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

# Setup virtual environment
python3 -m venv venv
source venv/bin/activate
pip install Flask flask-login flask-sqlalchemy flask-wtf
pip install werkzeug gunicorn psycopg2-binary email-validator

# Create environment file
cat > .env << ENVEOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
SESSION_SECRET=$(openssl rand -base64 32)
STREAM_SERVER=$DOMAIN_NAME
DOMAIN_NAME=$DOMAIN_NAME
RTMP_SERVER=rtmp://$DOMAIN_NAME/live
ENVEOF

# Create systemd service
cat > /etc/systemd/system/streamvibe.service << SVCEOF
[Unit]
Description=StreamVibe Gunicorn Service
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=$(pwd)
Environment="PATH=$(pwd)/venv/bin"
EnvironmentFile=$(pwd)/.env
ExecStart=$(pwd)/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
Restart=always

[Install]
WantedBy=multi-user.target
SVCEOF

# Set permissions
chown -R www-data:www-data .
mkdir -p uploads hls dash
chmod -R 755 .

# Configure nginx
cat > /etc/nginx/nginx.conf << NGINXEOF
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

# RTMP Configuration
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path $(pwd)/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path $(pwd)/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;
    
    # Logging settings
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;
    
    # Gzip settings
    gzip on;
    gzip_disable "msie6";
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # Virtual Host Configs
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
NGINXEOF

# Create site config
cat > /etc/nginx/sites-available/streamvibe << SITEEOF
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /static {
        alias $(pwd)/static;
        expires 30d;
    }

    location /uploads {
        alias $(pwd)/uploads;
        expires 30d;
    }
    
    location /hls {
        alias $(pwd)/hls;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
    }
    
    location /dash {
        alias $(pwd)/dash;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/dash+xml mpd;
        }
    }
}
SITEEOF

# Enable site configuration
ln -sf /etc/nginx/sites-available/streamvibe /etc/nginx/sites-enabled/
if [ -f /etc/nginx/sites-enabled/default ]; then
    rm /etc/nginx/sites-enabled/default
fi

# Start services
systemctl daemon-reload
systemctl restart nginx
systemctl enable streamvibe
systemctl start streamvibe

echo "StreamVibe installation complete!"
echo "Visit http://$DOMAIN_NAME"
echo "Login with admin/$ADMIN_PASS"
EOF

# Create requirements.txt
print_status "Creating requirements.txt..."
cat > $OUTPUT_DIR/requirements.txt << 'EOF'
Flask==2.3.3
flask-login==0.6.2
flask-sqlalchemy==3.1.1
flask-wtf==1.2.1
werkzeug==2.3.7
gunicorn==23.0.0
psycopg2-binary==2.9.9
email-validator==2.1.0
python-dotenv==1.0.0
requests==2.31.0
EOF

# Create README
print_status "Creating README..."
cat > $OUTPUT_DIR/README.md << 'EOF'
# StreamVibe

StreamVibe is a Python-based media streaming platform leveraging Flask and WebRTC for high-performance live content delivery and interactive broadcasting experiences.

## Features

- User authentication and account management
- Video upload and playback
- Live streaming with RTMP
- HLS and DASH adaptive streaming
- Advanced analytics
- Admin dashboard

## Quick Install

Run the included installation script:

```bash
chmod +x install.sh
sudo ./install.sh
```

## Manual Installation

1. Install dependencies:
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip python3-venv nginx postgresql ffmpeg
   ```

2. Set up a Python virtual environment:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. Configure PostgreSQL:
   ```bash
   sudo -u postgres psql -c "CREATE USER streamvibe_user WITH PASSWORD 'choose_password';"
   sudo -u postgres psql -c "CREATE DATABASE streamvibe;"
   sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE streamvibe TO streamvibe_user;"
   ```

4. Configure environment variables:
   ```bash
   echo "DATABASE_URL=postgresql://streamvibe_user:choose_password@localhost:5432/streamvibe" > .env
   echo "SESSION_SECRET=$(openssl rand -base64 32)" >> .env
   ```

5. Run the application:
   ```bash
   gunicorn --bind 0.0.0.0:5000 main:app
   ```

## Access

After installation, access your StreamVibe instance at:

- Web interface: http://your_domain
- Admin login: admin/admin123 (change this immediately)
- RTMP streaming URL: rtmp://your_domain/live
EOF

# Create nginx.conf
print_status "Creating nginx.conf..."
cat > $OUTPUT_DIR/nginx.conf << 'EOF'
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

# RTMP Configuration
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path /var/www/html/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path /var/www/html/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;
    
    # Logging settings
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;
    
    # Gzip settings
    gzip on;
    gzip_disable "msie6";
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # Virtual Host Configs
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
EOF

# Create nginx site configuration
print_status "Creating nginx site configuration..."
cat > $OUTPUT_DIR/streamvibe.conf << 'EOF'
server {
    listen 80;
    server_name streamvibe.biz www.streamvibe.biz;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /var/www/html/static;
        expires 30d;
    }

    location /uploads {
        alias /var/www/html/uploads;
        expires 30d;
    }
    
    location /hls {
        alias /var/www/html/hls;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
    }
    
    location /dash {
        alias /var/www/html/dash;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/dash+xml mpd;
        }
    }
}
EOF

# Make install.sh executable
chmod +x $OUTPUT_DIR/install.sh

# Create a zip archive of the package
print_status "Creating ZIP archive..."
zip -r $OUTPUT_FILE $OUTPUT_DIR

# Success message
print_success "StreamVibe package created successfully!"
print_status "Package directory: $OUTPUT_DIR"
print_status "ZIP archive: $OUTPUT_FILE"
print_status ""
print_status "To deploy, extract the ZIP file and run the install.sh script as root."