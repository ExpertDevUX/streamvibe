# StreamVibe Installation Guide

This guide provides step-by-step instructions for installing and configuring StreamVibe on aaPanel or any Linux VPS.

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Installation on aaPanel](#installation-on-aapanel)
3. [Manual VPS Installation](#manual-vps-installation)
4. [Configuration](#configuration)
5. [Database Setup](#database-setup)
6. [NGINX Configuration](#nginx-configuration)
7. [Starting the Application](#starting-the-application)
8. [Troubleshooting](#troubleshooting)

## System Requirements

- Ubuntu 20.04 LTS or CentOS 8 (recommended)
- Minimum 2GB RAM (4GB recommended)
- 20GB+ storage space
- Python 3.8+ with pip
- PostgreSQL 12+
- NGINX with RTMP module
- FFmpeg for streaming functionality

## Installation on aaPanel

### 1. Install aaPanel

**For Ubuntu/Debian:**
```bash
wget -O install.sh http://www.aapanel.com/script/install-ubuntu_6.0_en.sh && bash install.sh aapanel
```

**For CentOS:**
```bash
yum install -y wget && wget -O install.sh http://www.aapanel.com/script/install_6.0_en.sh && bash install.sh aapanel
```

Access aaPanel at `http://YOUR_SERVER_IP:7800` and complete the initial setup.

### 2. Install Required Software via aaPanel

1. Log in to aaPanel
2. Go to **App Store**
3. Install the following:
   - NGINX (1.20+)
   - Python Project Manager
   - PostgreSQL
   - PM2 Process Manager

### 3. Configure NGINX with RTMP

1. In aaPanel, go to **Software Store** > **NGINX** > **Setting**
2. Add RTMP module configuration:
   - Click **Configuration Files** or **NGINX Settings**
   - Choose the main NGINX configuration file
   - Add our RTMP configuration (or upload our custom `nginx.conf`)

### 4. Set Up StreamVibe Project

1. In aaPanel, go to **Python Project** > **Add Project**
2. Fill out the form:
   - Project Name: `streamvibe`
   - Description: `StreamVibe Media Platform`
   - Project Path: `/www/wwwroot/streamvibe.biz` (or your domain path)
   - Python Version: Select 3.8+ 
   - Start Command: `gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app`
   - Framework: `Flask`

### 5. Upload Project Files

Use aaPanel's file manager to upload StreamVibe files to the project directory.

Alternatively, use git:
```bash
cd /www/wwwroot/streamvibe.biz
git clone https://your-repository-url.git .
```

### 6. Configure Environment

1. Go to **Python Project** > **streamvibe** > **Configure Environment**
2. Add the following packages via **Install Modules**:
   ```
   flask
   flask-login
   flask-migrate
   flask-sqlalchemy
   flask-wtf
   gunicorn
   psycopg2-binary
   python-dotenv
   requests
   sqlalchemy
   werkzeug
   email-validator
   ```

### 7. Set Up Database

1. Go to **Database** > **PostgreSQL** > **Add Database**
2. Create a database for StreamVibe:
   - Database Name: `streamvibe`
   - Username: `streamvibe_user`
   - Password: Generate a secure password
   - Click **Submit**

3. Add the database details to your environment variables in aaPanel:
   - Go to **Python Project** > **streamvibe** > **Environment Variables**
   - Add the following:
     ```
     DATABASE_URL=postgresql://streamvibe_user:your_password@localhost:5432/streamvibe
     SESSION_SECRET=your_secure_session_key
     STREAM_SERVER=streamvibe.biz
     DOMAIN_NAME=streamvibe.biz
     RTMP_SERVER=rtmp://streamvibe.biz/live
     HLS_SERVER=https://streamvibe.biz/hls
     DASH_SERVER=https://streamvibe.biz/dash
     ```

### 8. Configure Website in aaPanel

1. Go to **Website** > **Add Site**
2. Configure your domain:
   - Domain: `streamvibe.biz` (and www variant)
   - Document Root: `/www/wwwroot/streamvibe.biz`
   - Configure SSL if needed
   
3. Set up NGINX reverse proxy to gunicorn:
   - Go to **Website** > **streamvibe.biz** > **Proxy**
   - Add a new proxy rule:
     - Name: `streamvibe`
     - Target URL: `http://127.0.0.1:5000`
     - Click **Submit**

### 9. Initialize Application

1. Go to **Terminal** or connect via SSH
2. Change to the project directory:
   ```bash
   cd /www/wwwroot/streamvibe.biz
   ```

3. Initialize the database:
   ```bash
   source venv/bin/activate
   python -c "from app import db; db.create_all()"
   python run_analytics_migration.py
   ```

4. Create an admin user:
   ```bash
   python create_admin.py
   ```

### 10. Start the Application

1. In aaPanel, go to **Python Project** > **streamvibe** > **Operate** > **Start**
2. Check status and logs to ensure it's running correctly

## Manual VPS Installation

If you're not using aaPanel, follow these steps for a manual installation.

### 1. Update System and Install Dependencies

```bash
sudo apt update
sudo apt upgrade -y
sudo apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib ffmpeg build-essential libssl-dev libffi-dev python3-dev
```

### 2. Install NGINX with RTMP Module

```bash
# Install NGINX with RTMP module
sudo apt install -y libnginx-mod-rtmp

# If the module is not available via apt, compile from source:
cd /tmp
sudo apt install -y build-essential libpcre3-dev libssl-dev zlib1g-dev
wget https://nginx.org/download/nginx-1.20.1.tar.gz
wget https://github.com/arut/nginx-rtmp-module/archive/master.zip
unzip master.zip
tar -zxvf nginx-1.20.1.tar.gz
cd nginx-1.20.1
./configure --with-http_ssl_module --add-module=../nginx-rtmp-module-master
make
sudo make install
```

### 3. Create PostgreSQL Database

```bash
sudo -u postgres psql -c "CREATE USER streamvibe_user WITH PASSWORD 'your_secure_password';"
sudo -u postgres psql -c "CREATE DATABASE streamvibe;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE streamvibe TO streamvibe_user;"
```

### 4. Set Up Project Directory

```bash
sudo mkdir -p /var/www/streamvibe
sudo chown $USER:$USER /var/www/streamvibe
cd /var/www/streamvibe
```

### 5. Clone Repository or Upload Files

```bash
# Using git:
git clone https://your-repository-url.git .

# Or manually upload files to /var/www/streamvibe
```

### 6. Set Up Python Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

If requirements.txt is missing, install the following packages:
```bash
pip install flask flask-login flask-migrate flask-sqlalchemy flask-wtf gunicorn psycopg2-binary python-dotenv requests sqlalchemy werkzeug email-validator
```

### 7. Create Environment Variables File

Create a `.env` file in the project directory:
```bash
cat > .env << EOF
DATABASE_URL=postgresql://streamvibe_user:your_secure_password@localhost:5432/streamvibe
SESSION_SECRET=your_secure_session_key
STREAM_SERVER=streamvibe.biz
DOMAIN_NAME=streamvibe.biz
RTMP_SERVER=rtmp://streamvibe.biz/live
HLS_SERVER=https://streamvibe.biz/hls
DASH_SERVER=https://streamvibe.biz/dash
EOF
```

### 8. Initialize Database

```bash
source venv/bin/activate
python -c "from app import db; db.create_all()"
python run_analytics_migration.py
python create_admin.py
```

### 9. Configure NGINX

Create NGINX server block:
```bash
sudo nano /etc/nginx/sites-available/streamvibe
```

Add the following configuration:
```nginx
server {
    listen 80;
    server_name streamvibe.biz www.streamvibe.biz;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /var/www/streamvibe/static;
        expires 30d;
    }

    location /uploads {
        alias /var/www/streamvibe/uploads;
        expires 30d;
    }
}
```

Enable the site:
```bash
sudo ln -s /etc/nginx/sites-available/streamvibe /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 10. Set Up RTMP Configuration

Add RTMP configuration to NGINX:
```bash
sudo nano /etc/nginx/nginx.conf
```

Add the RTMP section (you can use our existing nginx.conf as a reference):
```nginx
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path /var/www/streamvibe/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path /var/www/streamvibe/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}
```

Create HLS and DASH directories:
```bash
mkdir -p /var/www/streamvibe/hls /var/www/streamvibe/dash
sudo chown -R www-data:www-data /var/www/streamvibe/hls
sudo chown -R www-data:www-data /var/www/streamvibe/dash
sudo chmod -R 755 /var/www/streamvibe/hls
sudo chmod -R 755 /var/www/streamvibe/dash
```

### 11. Set Up Systemd Service

Create a systemd service file:
```bash
sudo nano /etc/systemd/system/streamvibe.service
```

Add the following content:
```
[Unit]
Description=StreamVibe Gunicorn Service
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=/var/www/streamvibe
Environment="PATH=/var/www/streamvibe/venv/bin"
EnvironmentFile=/var/www/streamvibe/.env
ExecStart=/var/www/streamvibe/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
Restart=always

[Install]
WantedBy=multi-user.target
```

Enable and start the service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable streamvibe
sudo systemctl start streamvibe
```

### 12. Set Up SSL with Let's Encrypt (Optional but Recommended)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d streamvibe.biz -d www.streamvibe.biz
```

## Configuration

### Important Configuration Files

1. **Environment Variables** (`.env`):
   - `DATABASE_URL`: PostgreSQL connection string
   - `SESSION_SECRET`: Secret key for session
   - `STREAM_SERVER`: Primary domain name
   - `DOMAIN_NAME`: Domain name for links
   - `RTMP_SERVER`: RTMP server URL
   - `HLS_SERVER`: HLS server URL
   - `DASH_SERVER`: DASH server URL

2. **NGINX Configuration**:
   - Main NGINX configuration: `/etc/nginx/nginx.conf`
   - StreamVibe site configuration: `/etc/nginx/sites-available/streamvibe`

3. **Systemd Service**:
   - Service file: `/etc/systemd/system/streamvibe.service`

### Customizing Domain Information

Ensure all domain references in the application are set to your actual domain:

1. Update environment variables with your domain
2. Check configuration files for hardcoded domains
3. Ensure RTMP, HLS, and DASH URLs are correctly configured

## Troubleshooting

### Common Issues and Solutions

1. **Application doesn't start**:
   - Check logs: `sudo journalctl -u streamvibe.service`
   - Verify environment variables are set correctly
   - Ensure database connection is working

2. **NGINX errors**:
   - Check NGINX logs: `sudo tail -f /var/log/nginx/error.log`
   - Validate configuration: `sudo nginx -t`
   - Restart NGINX: `sudo systemctl restart nginx`

3. **Streaming issues**:
   - Verify RTMP module is correctly installed
   - Check file permissions for HLS and DASH directories
   - Ensure stream authentication endpoints are working

4. **Database connection issues**:
   - Verify PostgreSQL is running: `sudo systemctl status postgresql`
   - Check database credentials
   - Validate database connectivity: `psql -U streamvibe_user -h localhost -d streamvibe`

### Checking Logs

- **Application logs**: 
  ```bash
  sudo journalctl -u streamvibe.service
  ```

- **NGINX logs**:
  ```bash
  sudo tail -f /var/log/nginx/access.log
  sudo tail -f /var/log/nginx/error.log
  ```

- **PostgreSQL logs**:
  ```bash
  sudo tail -f /var/log/postgresql/postgresql-12-main.log
  ```

## Maintenance

### Updating the Application

1. Navigate to the project directory:
   ```bash
   cd /var/www/streamvibe
   ```

2. Pull the latest code:
   ```bash
   git pull
   ```

3. Update dependencies:
   ```bash
   source venv/bin/activate
   pip install -r requirements.txt
   ```

4. Run database migrations if any:
   ```bash
   python run_analytics_migration.py
   ```

5. Restart the application:
   ```bash
   sudo systemctl restart streamvibe
   ```

### Backup and Restore

1. **Backup Database**:
   ```bash
   pg_dump -U streamvibe_user streamvibe > streamvibe_backup.sql
   ```

2. **Restore Database**:
   ```bash
   psql -U streamvibe_user -d streamvibe < streamvibe_backup.sql
   ```

3. **Backup Application Files**:
   ```bash
   tar -czvf streamvibe_files.tar.gz /var/www/streamvibe
   ```

4. **Backup Uploaded Media**:
   ```bash
   tar -czvf streamvibe_uploads.tar.gz /var/www/streamvibe/uploads
   ```

## Security Recommendations

1. Always use SSL/TLS for your domain
2. Set strong passwords for database and admin users
3. Keep the system and all packages updated
4. Configure a firewall (UFW or firewalld)
5. Enable fail2ban for SSH protection
6. Use restrictive file permissions

## Additional Resources

- [aaPanel Documentation](https://www.aapanel.com/new/documentation.html)
- [NGINX Documentation](https://nginx.org/en/docs/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [Gunicorn Documentation](https://docs.gunicorn.org/en/stable/)
- [Flask Documentation](https://flask.palletsprojects.com/)