# StreamVibe Deployment Checklist

This checklist provides a quick reference for deploying StreamVibe to production environments, ensuring all necessary components are properly configured.

## Required Dependencies

Make sure these packages are installed on your server:

- Python 3.8 or higher
- Required Python packages:
  ```
  flask==2.3.3
  flask-login==0.6.2
  flask-migrate==4.0.5
  flask-sqlalchemy==3.1.1
  flask-wtf==1.2.1
  gunicorn==23.0.0
  psycopg2-binary==2.9.9
  python-dotenv==1.0.0
  requests==2.31.0
  sqlalchemy==2.0.23
  werkzeug==2.3.7
  email-validator==2.1.0
  ```
- NGINX with RTMP module
- PostgreSQL 12 or higher
- FFmpeg (for thumbnail generation and stream processing)

## Pre-Deployment Checklist

### 1. Configuration

- [ ] Update all domain references to your production domain
- [ ] Set strong, unique passwords for database and admin users
- [ ] Configure secure session key
- [ ] Set appropriate file permissions
- [ ] Configure database connection string
- [ ] Set up streaming URLs (RTMP, HLS, DASH)

### 2. Environment Variables

Ensure these environment variables are properly set:

- [ ] `DATABASE_URL`: PostgreSQL connection string
- [ ] `SESSION_SECRET`: Secret key for sessions
- [ ] `STREAM_SERVER`: Primary domain name for streaming
- [ ] `DOMAIN_NAME`: Domain name for links and references
- [ ] `RTMP_SERVER`: RTMP endpoint (e.g., rtmp://your-domain.com/live)
- [ ] `HLS_SERVER`: HLS endpoint (e.g., https://your-domain.com/hls)
- [ ] `DASH_SERVER`: DASH endpoint (e.g., https://your-domain.com/dash)

### 3. Database

- [ ] PostgreSQL database is created and accessible
- [ ] Database user has appropriate permissions
- [ ] All database migrations are applied
- [ ] Admin user is created

### 4. NGINX

- [ ] NGINX is installed with RTMP module
- [ ] Site configuration is set up for HTTP/HTTPS
- [ ] SSL certificate is installed (recommended)
- [ ] RTMP configuration is properly set up
- [ ] HLS and DASH directories are created with correct permissions
- [ ] Static file serving is configured

### 5. Security

- [ ] SSL/TLS is configured (Let's Encrypt or commercial certificate)
- [ ] Firewall is configured to allow necessary ports:
  - [ ] 80/443 for HTTP/HTTPS
  - [ ] 1935 for RTMP
  - [ ] 5000 if accessing Gunicorn directly (not recommended)
- [ ] PostgreSQL is configured for local access only
- [ ] File permissions are restricted appropriately
- [ ] Sensitive files (.env, etc.) are protected

### 6. Directories

- [ ] `/uploads` directory exists with correct permissions
- [ ] `/hls` directory exists with correct permissions
- [ ] `/dash` directory exists with correct permissions
- [ ] `/static` directory exists with correct permissions

## Deployment Steps

1. **Prepare the Server**
   - [ ] Update system packages
   - [ ] Install required dependencies
   - [ ] Configure firewall

2. **Install StreamVibe**
   - [ ] Set up project directory
   - [ ] Upload application files
   - [ ] Install Python dependencies
   - [ ] Configure environment variables

3. **Set Up Database**
   - [ ] Create PostgreSQL database
   - [ ] Run database migrations
   - [ ] Create admin user

4. **Configure NGINX**
   - [ ] Set up NGINX with RTMP module
   - [ ] Configure site and streaming endpoints
   - [ ] Set up SSL/TLS
   - [ ] Test NGINX configuration

5. **Start Services**
   - [ ] Start Gunicorn application server
   - [ ] Start NGINX
   - [ ] Verify services are running

6. **Verify Deployment**
   - [ ] Access website in browser
   - [ ] Test user registration and login
   - [ ] Test media upload
   - [ ] Test streaming with OBS or similar software

## Post-Deployment Tasks

- [ ] Set up automated backups
- [ ] Configure monitoring
- [ ] Set up log rotation
- [ ] Document the deployment
- [ ] Provide admin credentials to authorized personnel

## Useful Commands

### Checking Services

```bash
# Check Gunicorn service
sudo systemctl status streamvibe

# Check NGINX service
sudo systemctl status nginx

# Check PostgreSQL service
sudo systemctl status postgresql
```

### Viewing Logs

```bash
# Application logs (if using systemd)
sudo journalctl -u streamvibe.service

# NGINX logs
sudo tail -f /var/log/nginx/error.log
sudo tail -f /var/log/nginx/access.log

# PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-12-main.log
```

### Restarting Services

```bash
# Restart application
sudo systemctl restart streamvibe

# Restart NGINX
sudo systemctl restart nginx

# Restart PostgreSQL
sudo systemctl restart postgresql
```

## Troubleshooting Tips

1. **Application won't start**:
   - Check application logs for errors
   - Verify environment variables
   - Check database connection

2. **Streaming issues**:
   - Verify RTMP module is installed
   - Check NGINX configuration
   - Verify port 1935 is open

3. **Database connection errors**:
   - Check database credentials
   - Verify PostgreSQL is running
   - Check network/firewall settings

4. **File permission issues**:
   - Verify ownership of directories
   - Check permissions on upload/stream directories
   - Ensure the service user can access necessary files

## Additional Resources

For detailed setup instructions, refer to:

- [StreamVibe Installation Guide](installation_guide.md)
- [RTMP Setup Guide](rtmp_setup_guide.md)