# RTMP Module Setup Guide for StreamVibe

This guide provides detailed instructions for setting up the NGINX RTMP module, which is required for StreamVibe's live streaming functionality. The RTMP module enables real-time streaming using OBS Studio or similar broadcasting software.

## Table of Contents
1. [Overview](#overview)
2. [aaPanel Installation](#aapanel-installation)
3. [Manual Installation](#manual-installation)
4. [Verifying the Installation](#verifying-the-installation)
5. [Configuring StreamVibe for RTMP](#configuring-streamvibe-for-rtmp)
6. [Testing with OBS Studio](#testing-with-obs-studio)
7. [Troubleshooting](#troubleshooting)

## Overview

The NGINX RTMP module adds RTMP, HLS, and DASH streaming capabilities to the NGINX web server. These protocols are essential for:

- **RTMP**: Low-latency ingest from broadcasting software (like OBS)
- **HLS**: HTTP Live Streaming for playback on various devices
- **DASH**: Dynamic Adaptive Streaming over HTTP for adaptive bitrate streaming

## aaPanel Installation

### 1. Install NGINX via aaPanel

1. Log in to aaPanel
2. Go to **App Store**
3. Install NGINX (version 1.20+ recommended)

### 2. Install Required Packages

Connect to your server via SSH and install required dependencies:

```bash
sudo apt update
sudo apt install -y build-essential libpcre3-dev libssl-dev zlib1g-dev libxml2-dev libxslt1-dev
```

### 3. Add RTMP Module to NGINX in aaPanel

1. Stop NGINX in aaPanel:
   - Go to **Software Store** > **NGINX** > **Service**
   - Click **Stop**

2. Connect to your server via SSH and navigate to the source directory:
   ```bash
   cd /www/server/nginx/src
   ```

3. Download and extract the RTMP module:
   ```bash
   wget https://github.com/arut/nginx-rtmp-module/archive/master.zip
   unzip master.zip
   ```

4. Find the current NGINX version:
   ```bash
   /www/server/nginx/sbin/nginx -v
   ```

5. Download the matching NGINX source (replace 1.20.1 with your version):
   ```bash
   wget https://nginx.org/download/nginx-1.20.1.tar.gz
   tar -zxvf nginx-1.20.1.tar.gz
   cd nginx-1.20.1
   ```

6. Get the current configure arguments:
   ```bash
   cat /www/server/nginx/conf/nginx.conf | grep "configure arguments"
   ```

7. Add the RTMP module to the configure arguments and compile:
   ```bash
   # Add the RTMP module to your existing configure arguments
   ./configure [your_existing_args] --add-module=../nginx-rtmp-module-master
   make
   ```

8. Replace the NGINX binary:
   ```bash
   cp objs/nginx /www/server/nginx/sbin/nginx
   ```

9. Start NGINX in aaPanel:
   - Go to **Software Store** > **NGINX** > **Service**
   - Click **Start**

### 4. Configure RTMP Module in aaPanel

1. In aaPanel, go to **Software Store** > **NGINX** > **Settings**
2. Click on **Configuration Files**
3. Choose the main NGINX configuration file
4. Add this RTMP configuration before the `http` block:

```nginx
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path /www/wwwroot/streamvibe.biz/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path /www/wwwroot/streamvibe.biz/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}
```

5. Save the configuration

6. Create the HLS and DASH directories:
   ```bash
   mkdir -p /www/wwwroot/streamvibe.biz/hls /www/wwwroot/streamvibe.biz/dash
   chown -R www:www /www/wwwroot/streamvibe.biz/hls
   chown -R www:www /www/wwwroot/streamvibe.biz/dash
   chmod -R 755 /www/wwwroot/streamvibe.biz/hls
   chmod -R 755 /www/wwwroot/streamvibe.biz/dash
   ```

7. Restart NGINX:
   - Go to **Software Store** > **NGINX** > **Service**
   - Click **Restart**

### 5. Configure NGINX Site in aaPanel

1. In aaPanel, go to **Website** > **streamvibe.biz** > **Settings**
2. Click on **Site Configuration**
3. Add the following locations for HLS and DASH streaming:

```nginx
location /hls {
    alias /www/wwwroot/streamvibe.biz/hls;
    add_header Cache-Control no-cache;
    add_header 'Access-Control-Allow-Origin' '*' always;
    add_header 'Access-Control-Allow-Methods' 'GET, OPTIONS';
    add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
    
    types {
        application/vnd.apple.mpegurl m3u8;
        video/mp2t ts;
    }
}

location /dash {
    alias /www/wwwroot/streamvibe.biz/dash;
    add_header Cache-Control no-cache;
    add_header 'Access-Control-Allow-Origin' '*' always;
    add_header 'Access-Control-Allow-Methods' 'GET, OPTIONS';
    add_header 'Access-Control-Allow-Headers' 'DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range';
    
    types {
        application/dash+xml mpd;
    }
}
```

4. Save the configuration and restart NGINX

## Manual Installation

If you're not using aaPanel, follow these steps for a manual installation.

### 1. Install Prerequisites

```bash
sudo apt update
sudo apt install -y build-essential libpcre3-dev libssl-dev zlib1g-dev libxml2-dev libxslt1-dev unzip wget
```

### 2. Download and Compile NGINX with RTMP Module

```bash
# Create a temporary build directory
mkdir -p ~/nginx-build
cd ~/nginx-build

# Download RTMP module
wget https://github.com/arut/nginx-rtmp-module/archive/master.zip
unzip master.zip

# Download NGINX (replace with your preferred version)
wget https://nginx.org/download/nginx-1.20.1.tar.gz
tar -zxvf nginx-1.20.1.tar.gz
cd nginx-1.20.1

# Configure with RTMP module
./configure --prefix=/usr/local/nginx \
            --with-http_ssl_module \
            --with-http_v2_module \
            --with-http_realip_module \
            --add-module=../nginx-rtmp-module-master

# Compile and install
make
sudo make install
```

### 3. Create a Systemd Service

```bash
sudo nano /etc/systemd/system/nginx.service
```

Add the following content:

```
[Unit]
Description=NGINX with RTMP module
After=network.target

[Service]
Type=forking
PIDFile=/usr/local/nginx/logs/nginx.pid
ExecStartPre=/usr/local/nginx/sbin/nginx -t
ExecStart=/usr/local/nginx/sbin/nginx
ExecReload=/usr/local/nginx/sbin/nginx -s reload
ExecStop=/usr/local/nginx/sbin/nginx -s stop
PrivateTmp=true

[Install]
WantedBy=multi-user.target
```

Enable and start the service:

```bash
sudo systemctl daemon-reload
sudo systemctl enable nginx
sudo systemctl start nginx
```

### 4. Configure NGINX with RTMP

```bash
sudo nano /usr/local/nginx/conf/nginx.conf
```

Replace with the following content (adapt as needed):

```nginx
worker_processes auto;
events {
    worker_connections 1024;
}

# RTMP Configuration
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path /var/www/streamvibe/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path /var/www/streamvibe/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}

# HTTP Configuration
http {
    include mime.types;
    default_type application/octet-stream;
    sendfile on;
    keepalive_timeout 65;
    
    server {
        listen 80;
        server_name streamvibe.biz www.streamvibe.biz;
        
        # Proxy to Gunicorn
        location / {
            proxy_pass http://127.0.0.1:5000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
        
        # Static files
        location /static {
            alias /var/www/streamvibe/static;
            expires 30d;
        }
        
        location /uploads {
            alias /var/www/streamvibe/uploads;
            expires 30d;
        }
        
        # HLS streaming
        location /hls {
            alias /var/www/streamvibe/hls;
            add_header Cache-Control no-cache;
            add_header 'Access-Control-Allow-Origin' '*' always;
            
            types {
                application/vnd.apple.mpegurl m3u8;
                video/mp2t ts;
            }
        }
        
        # DASH streaming
        location /dash {
            alias /var/www/streamvibe/dash;
            add_header Cache-Control no-cache;
            add_header 'Access-Control-Allow-Origin' '*' always;
            
            types {
                application/dash+xml mpd;
            }
        }
    }
}
```

Create HLS and DASH directories:

```bash
sudo mkdir -p /var/www/streamvibe/hls /var/www/streamvibe/dash
sudo chown -R www-data:www-data /var/www/streamvibe/hls
sudo chown -R www-data:www-data /var/www/streamvibe/dash
sudo chmod -R 755 /var/www/streamvibe/hls
sudo chmod -R 755 /var/www/streamvibe/dash
```

Restart NGINX:

```bash
sudo systemctl restart nginx
```

## Verifying the Installation

### 1. Check NGINX Status

```bash
# For aaPanel
aaPanel - NGINX service should be running

# For manual installation
sudo systemctl status nginx
```

### 2. Verify RTMP Module

```bash
# For aaPanel
/www/server/nginx/sbin/nginx -V 2>&1 | grep rtmp

# For manual installation
/usr/local/nginx/sbin/nginx -V 2>&1 | grep rtmp
```

You should see `--add-module=../nginx-rtmp-module-master` in the output.

### 3. Test RTMP Port

Check if the RTMP port (1935) is open:

```bash
sudo netstat -tulnp | grep 1935
```

You should see NGINX listening on port 1935.

## Configuring StreamVibe for RTMP

### 1. Update Environment Variables

Update your `.env` file or environment variables with the correct streaming URLs:

```
STREAM_SERVER=streamvibe.biz
RTMP_SERVER=rtmp://streamvibe.biz/live
HLS_SERVER=https://streamvibe.biz/hls
DASH_SERVER=https://streamvibe.biz/dash
```

### 2. Verify StreamVibe Stream Authentication

Make sure the StreamVibe application has the correct routes for stream authentication:

- `/stream/auth`: Endpoint for authenticating stream keys
- `/stream/done`: Endpoint for handling stream end events

## Testing with OBS Studio

### 1. Set Up OBS Studio

1. Download and install [OBS Studio](https://obsproject.com/)
2. In OBS, go to **Settings** > **Stream**
3. Select **Custom** as the service
4. In the **Server** field, enter: `rtmp://streamvibe.biz/live`
5. In the **Stream Key** field, enter the stream key from your StreamVibe account

### 2. Start a Test Stream

1. Configure your scene with a video source
2. Click **Start Streaming**
3. Check the StreamVibe website to see if your stream is live
4. If the stream doesn't appear, check the NGINX error logs

## Troubleshooting

### Common Issues

#### 1. NGINX Won't Start After Adding RTMP Module

**Solution**:
- Check NGINX error logs
- Verify that the configure arguments are correct
- Ensure all dependencies are installed

```bash
# aaPanel NGINX error log
cat /www/server/nginx/logs/error.log

# Manual installation error log
cat /usr/local/nginx/logs/error.log
```

#### 2. Permission Issues with HLS/DASH Directories

**Solution**:
- Check and correct permissions

```bash
# For aaPanel
chown -R www:www /www/wwwroot/streamvibe.biz/hls
chown -R www:www /www/wwwroot/streamvibe.biz/dash
chmod -R 755 /www/wwwroot/streamvibe.biz/hls
chmod -R 755 /www/wwwroot/streamvibe.biz/dash

# For manual installation
sudo chown -R www-data:www-data /var/www/streamvibe/hls
sudo chown -R www-data:www-data /var/www/streamvibe/dash
sudo chmod -R 755 /var/www/streamvibe/hls
sudo chmod -R 755 /var/www/streamvibe/dash
```

#### 3. RTMP Stream Not Authenticating

**Solution**:
- Check that the `on_publish` and `on_publish_done` URLs are correct
- Verify that the StreamVibe application is running
- Check the StreamVibe logs for authentication issues

#### 4. HLS/DASH Streams Not Working

**Solution**:
- Check the NGINX configuration for the HLS/DASH locations
- Verify that the MIME types are correctly defined
- Check CORS headers if accessing from different domains

#### 5. Port 1935 Blocked

**Solution**:
- Check firewall rules:
  ```bash
  # For UFW
  sudo ufw status
  sudo ufw allow 1935
  
  # For firewalld
  sudo firewall-cmd --list-all
  sudo firewall-cmd --permanent --add-port=1935/tcp
  sudo firewall-cmd --reload
  ```

#### 6. Stream Quality Issues

**Solution**:
- Check OBS output settings
- Verify server resources are not overloaded
- Consider adjusting the RTMP module buffer settings

## Additional Resources

- [NGINX RTMP Module GitHub Repository](https://github.com/arut/nginx-rtmp-module)
- [OBS Studio Documentation](https://obsproject.com/wiki/)
- [HLS Specification](https://developer.apple.com/streaming/)
- [DASH Specification](https://dashif.org/)
- [StreamVibe Documentation](docs/installation_guide.md)