"""
Advanced Analytics Migration Script
This script creates the analytics_events table, relying on the model definitions in models.py.
We'll use the SQLAlchemy ORM's create_all() to create the new table.
"""

from app import app, db
import json
import sys
import logging
from models import AnalyticsEvent

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def run_migration():
    """Execute migration using SQLAlchemy ORM"""
    try:
        # Use SQLAlchemy's create_all to create the AnalyticsEvent table
        # This is a safe operation - if the table already exists, it won't be modified
        db.create_all()
        logger.info("Database schema updated successfully")
        
        # Check if the table was created/exists
        try:
            # Try to query the table
            result = db.session.execute(db.select(AnalyticsEvent).limit(1)).fetchall()
            logger.info("AnalyticsEvent table exists and is accessible")
        except Exception as e:
            logger.warning(f"Unable to query AnalyticsEvent table: {str(e)}")
        
        return True
        
    except Exception as e:
        logger.error(f"Unexpected error during migration: {str(e)}")
        return False

if __name__ == "__main__":
    with app.app_context():
        success = run_migration()
        sys.exit(0 if success else 1)