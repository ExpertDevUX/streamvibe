"""Advanced Analytics Migration Script

This script adds new columns to the analytics table and creates a new analytics_events table.
"""

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, DateTime, Text, Float, ForeignKey, create_engine, MetaData, Table
from sqlalchemy.ext.declarative import declarative_base
import os
import json
from datetime import datetime

# Create a minimal Flask app
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

def run_migration():
    """Run the migration to add new analytics columns and table"""
    
    # Get database connection
    engine = create_engine(os.environ.get('DATABASE_URL'))
    meta = MetaData()
    meta.reflect(bind=engine)
    
    # Load existing analytics table
    analytics = Table('analytics', meta, autoload_with=engine)
    
    # Add new columns to analytics table if they don't exist
    new_columns = [
        ('device_mobile', Integer),
        ('device_desktop', Integer),
        ('device_tablet', Integer),
        ('device_other', Integer),
        ('avg_watch_duration', Float),
        ('engagement_rate', Float),
        ('bounce_rate', Float),
        ('country_data', Text),
        ('referrer_data', Text)
    ]
    
    conn = engine.connect()
    
    try:
        # Begin transaction
        trans = conn.begin()
        
        # Add columns to analytics table
        for col_name, col_type in new_columns:
            try:
                # Check if column exists first to avoid errors
                conn.execute(db.text(f"SELECT {col_name} FROM analytics LIMIT 1")).fetchone()
                print(f"Column {col_name} already exists in analytics table.")
            except:
                # Column doesn't exist, create it
                sql = ""
                if col_type == Integer:
                    sql = f"ALTER TABLE analytics ADD COLUMN {col_name} INTEGER DEFAULT 0"
                elif col_type == Float:
                    sql = f"ALTER TABLE analytics ADD COLUMN {col_name} FLOAT DEFAULT 0.0"
                elif col_type == Text:
                    sql = f"ALTER TABLE analytics ADD COLUMN {col_name} TEXT"
                
                if sql:
                    conn.execute(db.text(sql))
                    print(f"Added column {col_name} to analytics table.")
        
        # Create analytics_events table if it doesn't exist
        try:
            conn.execute(db.text("SELECT 1 FROM analytics_events LIMIT 1")).fetchone()
            print("Table analytics_events already exists.")
        except:
            # Table doesn't exist, create it
            conn.execute(db.text("""
            CREATE TABLE analytics_events (
                id SERIAL PRIMARY KEY,
                timestamp TIMESTAMP WITHOUT TIME ZONE DEFAULT now(),
                user_id INTEGER REFERENCES users(id) NOT NULL,
                media_id INTEGER REFERENCES media(id),
                stream_id INTEGER REFERENCES streams(id),
                event_type VARCHAR(50) NOT NULL,
                value FLOAT,
                session_id VARCHAR(64) NOT NULL,
                device_type VARCHAR(20),
                browser VARCHAR(50),
                os VARCHAR(50),
                country_code VARCHAR(2),
                referrer VARCHAR(255)
            )
            """))
            print("Created analytics_events table.")
            
            # Create index on timestamp for faster queries
            conn.execute(db.text("CREATE INDEX idx_analytics_events_timestamp ON analytics_events(timestamp)"))
            print("Created index on analytics_events timestamp.")
            
            # Create index on user_id for faster user-specific queries
            conn.execute(db.text("CREATE INDEX idx_analytics_events_user_id ON analytics_events(user_id)"))
            print("Created index on analytics_events user_id.")
            
            # Create composite indexes for faster media/stream specific queries
            conn.execute(db.text("CREATE INDEX idx_analytics_events_media ON analytics_events(media_id, timestamp)"))
            conn.execute(db.text("CREATE INDEX idx_analytics_events_stream ON analytics_events(stream_id, timestamp)"))
            print("Created composite indexes for media and stream queries.")
        
        # Add relationship to Media and Stream tables in Analytics
        try:
            # Check if the relationship columns exist with correct foreign keys
            # This is a simplified check, proper check would need to verify constraint existence
            conn.execute(db.text("SELECT media.id FROM analytics JOIN media ON analytics.media_id = media.id LIMIT 1")).fetchone()
            conn.execute(db.text("SELECT stream.id FROM analytics JOIN streams stream ON analytics.stream_id = stream.id LIMIT 1")).fetchone()
            print("Media and Stream relationships already exist on Analytics table.")
        except Exception as rel_error:
            # The error could be due to no matching data or missing relationship, so this is approximate
            print(f"Skipping relationship verification: {str(rel_error)}")
        
        # Commit all changes
        trans.commit()
        print("Advanced analytics migration completed successfully.")
    except Exception as e:
        # Roll back in case of error
        trans.rollback()
        print(f"Error during migration: {str(e)}")
        raise
    finally:
        conn.close()

if __name__ == "__main__":
    with app.app_context():
        run_migration()