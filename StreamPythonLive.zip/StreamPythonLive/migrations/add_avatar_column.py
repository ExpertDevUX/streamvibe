import os
import sys

# Add the parent directory to the path so we can import app
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import db
from flask import Flask

# Create a Flask app context
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///streamapp.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db.init_app(app)

# Execute the migration within the app context
with app.app_context():
    # Import models here to ensure they are registered with SQLAlchemy
    import models

    # Execute raw SQL to add the column if it doesn't exist
    from sqlalchemy import text
    db.session.execute(text('ALTER TABLE users ADD COLUMN avatar_path VARCHAR(255)'))
    db.session.commit()
    
    print("Migration completed: Added avatar_path column to users table.")