#!/bin/bash
# StreamVibe Complete Auto Installation Script
# This script handles everything:
# 1. System dependencies
# 2. NGINX with RTMP module
# 3. Database setup
# 4. Full application deployment
# 5. Configuration and setup

# Text colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Default configuration
DOMAIN_NAME="streamvibe.biz"
INSTALL_DIR="/var/www/html"
DB_NAME="streamvibe"
DB_USER="streamvibe_user"
DB_PASS=$(openssl rand -base64 12 | tr -d "=+/" | cut -c1-16)
ADMIN_USER="admin"
ADMIN_EMAIL="admin@streamvibe.biz"
ADMIN_PASS="admin123"
SESSION_SECRET=$(openssl rand -base64 32)
USE_HTTPS=false
REPO_URL="https://github.com/yourusername/streamvibe.git"
USE_REPO=false

# Check if running as root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        echo -e "${RED}This script must be run as root${NC}"
        exit 1
    fi
}

# Print section header
print_header() {
    echo -e "\n${BLUE}====== $1 ======${NC}\n"
}

# Function to print status message
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Function to print success message
print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to print warning message
print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Function to print error message
print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    if [ "$2" == "exit" ]; then
        exit 1
    fi
}

# Function to wait for keypress
wait_for_key() {
    echo
    read -n 1 -s -r -p "Press any key to continue..."
    echo
}

# Function to ask for configuration
ask_for_config() {
    print_header "StreamVibe Configuration"
    
    # Ask for domain name
    read -p "Enter your domain name [$DOMAIN_NAME]: " input
    DOMAIN_NAME=${input:-$DOMAIN_NAME}
    
    # Ask for installation directory
    read -p "Enter installation directory [$INSTALL_DIR]: " input
    INSTALL_DIR=${input:-$INSTALL_DIR}
    
    # Ask for admin username
    read -p "Enter admin username [$ADMIN_USER]: " input
    ADMIN_USER=${input:-$ADMIN_USER}
    
    # Ask for admin email
    read -p "Enter admin email [$ADMIN_EMAIL]: " input
    ADMIN_EMAIL=${input:-$ADMIN_EMAIL}
    
    # Ask for admin password
    read -p "Enter admin password [$ADMIN_PASS]: " input
    ADMIN_PASS=${input:-$ADMIN_PASS}
    
    # Ask for database name
    read -p "Enter database name [$DB_NAME]: " input
    DB_NAME=${input:-$DB_NAME}
    
    # Ask for database user
    read -p "Enter database user [$DB_USER]: " input
    DB_USER=${input:-$DB_USER}
    
    # Ask for database password
    read -p "Enter database password (leave empty for random) [$DB_PASS]: " input
    DB_PASS=${input:-$DB_PASS}
    
    # Ask for HTTPS
    read -p "Configure HTTPS? (y/n) [n]: " input
    if [[ $input == "y" || $input == "Y" ]]; then
        USE_HTTPS=true
    else
        USE_HTTPS=false
    fi
    
    # Ask for Git repository
    read -p "Do you have a Git repository for StreamVibe? (y/n) [n]: " input
    if [[ $input == "y" || $input == "Y" ]]; then
        USE_REPO=true
        read -p "Enter Git repository URL: " REPO_URL
    fi
    
    # Display configuration summary
    print_header "Configuration Summary"
    echo "Domain name: $DOMAIN_NAME"
    echo "Installation directory: $INSTALL_DIR"
    echo "Admin username: $ADMIN_USER"
    echo "Admin email: $ADMIN_EMAIL"
    echo "Admin password: $ADMIN_PASS"
    echo "Database name: $DB_NAME"
    echo "Database user: $DB_USER"
    echo "Database password: $DB_PASS"
    echo "HTTPS: $USE_HTTPS"
    
    if [ "$USE_REPO" = true ]; then
        echo "Git repository: $REPO_URL"
    fi
    
    # Confirm configuration
    read -p "Is this configuration correct? (y/n) [y]: " input
    if [[ $input == "n" || $input == "N" ]]; then
        ask_for_config
    fi
}

# Function to update system
update_system() {
    print_header "Updating System"
    
    export DEBIAN_FRONTEND=noninteractive
    apt update
    apt upgrade -y
    apt install -y software-properties-common
    
    print_success "System updated successfully"
}

# Function to install dependencies
install_dependencies() {
    print_header "Installing Dependencies"
    
    export DEBIAN_FRONTEND=noninteractive
    
    # Install required packages
    apt install -y python3 python3-pip python3-venv git curl wget unzip
    apt install -y postgresql postgresql-contrib
    apt install -y nginx
    apt install -y ffmpeg
    apt install -y build-essential libssl-dev libpcre3-dev zlib1g-dev
    apt install -y certbot python3-certbot-nginx
    
    print_success "Dependencies installed successfully"
}

# Function to install NGINX with RTMP module
setup_nginx_rtmp() {
    print_header "Setting Up NGINX with RTMP Module"
    
    # First try to install via package manager
    apt install -y libnginx-mod-rtmp
    
    # Check if RTMP module was installed
    if [ ! -f "/usr/lib/nginx/modules/ngx_rtmp_module.so" ] && [ ! -f "/etc/nginx/modules-available/ngx_rtmp_module.so" ]; then
        print_warning "RTMP module not found in package manager. Installing from source..."
        
        # Stop NGINX
        systemctl stop nginx
        
        # Download and build NGINX with RTMP module
        cd /tmp
        wget -q https://nginx.org/download/nginx-1.20.1.tar.gz
        wget -q https://github.com/arut/nginx-rtmp-module/archive/master.zip
        
        tar -xf nginx-1.20.1.tar.gz
        unzip -q master.zip
        
        cd nginx-1.20.1
        
        # Configure with RTMP module
        ./configure --prefix=/usr/share/nginx \
                    --sbin-path=/usr/sbin/nginx \
                    --modules-path=/usr/lib/nginx/modules \
                    --conf-path=/etc/nginx/nginx.conf \
                    --error-log-path=/var/log/nginx/error.log \
                    --http-log-path=/var/log/nginx/access.log \
                    --pid-path=/var/run/nginx.pid \
                    --lock-path=/var/run/nginx.lock \
                    --http-client-body-temp-path=/var/cache/nginx/client_temp \
                    --http-proxy-temp-path=/var/cache/nginx/proxy_temp \
                    --http-fastcgi-temp-path=/var/cache/nginx/fastcgi_temp \
                    --http-uwsgi-temp-path=/var/cache/nginx/uwsgi_temp \
                    --http-scgi-temp-path=/var/cache/nginx/scgi_temp \
                    --with-http_ssl_module \
                    --with-http_v2_module \
                    --with-http_realip_module \
                    --with-http_addition_module \
                    --with-http_sub_module \
                    --with-http_dav_module \
                    --with-http_flv_module \
                    --with-http_mp4_module \
                    --with-http_gunzip_module \
                    --with-http_gzip_static_module \
                    --with-http_auth_request_module \
                    --with-http_random_index_module \
                    --with-http_secure_link_module \
                    --with-http_slice_module \
                    --with-threads \
                    --with-file-aio \
                    --add-module=../nginx-rtmp-module-master
        
        # Build and install
        make -j$(nproc)
        make install
        
        # Create cache directories
        mkdir -p /var/cache/nginx/client_temp
        
        print_success "NGINX with RTMP module built and installed from source"
    else
        print_success "NGINX RTMP module installed via package manager"
    fi
}

# Function to configure NGINX
configure_nginx() {
    print_header "Configuring NGINX"
    
    # Backup existing configuration
    if [ -f /etc/nginx/nginx.conf ]; then
        cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup
    fi
    
    # Create NGINX configuration with RTMP
    cat > /etc/nginx/nginx.conf << EOL
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

# RTMP Configuration
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path $INSTALL_DIR/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path $INSTALL_DIR/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;
    
    # Logging settings
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;
    
    # Gzip settings
    gzip on;
    gzip_disable "msie6";
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_buffers 16 8k;
    gzip_http_version 1.1;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # Virtual Host Configs
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
EOL
    
    # Create site configuration
    mkdir -p /etc/nginx/sites-available
    mkdir -p /etc/nginx/sites-enabled
    
    cat > /etc/nginx/sites-available/streamvibe << EOL
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /static {
        alias $INSTALL_DIR/static;
        expires 30d;
    }

    location /uploads {
        alias $INSTALL_DIR/uploads;
        expires 30d;
    }
    
    location /hls {
        alias $INSTALL_DIR/hls;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
    }
    
    location /dash {
        alias $INSTALL_DIR/dash;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/dash+xml mpd;
        }
    }
}
EOL
    
    # Enable site configuration
    ln -sf /etc/nginx/sites-available/streamvibe /etc/nginx/sites-enabled/
    
    # Remove default site if it exists
    if [ -f /etc/nginx/sites-enabled/default ]; then
        rm /etc/nginx/sites-enabled/default
    fi
    
    # Test NGINX configuration
    nginx -t
    
    # Start NGINX
    systemctl restart nginx
    systemctl enable nginx
    
    print_success "NGINX configuration completed"
}

# Function to set up PostgreSQL
setup_database() {
    print_header "Setting Up PostgreSQL Database"
    
    # Make sure PostgreSQL is running
    systemctl start postgresql
    systemctl enable postgresql
    
    # Create database and user
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" || print_warning "Failed to create user, may already exist"
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;" || print_warning "Failed to create database, may already exist"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
    
    print_success "PostgreSQL database setup completed"
    echo "Database details:"
    echo "  Name: $DB_NAME"
    echo "  User: $DB_USER"
    echo "  Password: $DB_PASS"
}

# Function to create directory structure
create_directory_structure() {
    print_header "Creating Directory Structure"
    
    # Create main directory
    mkdir -p $INSTALL_DIR
    
    # Create subdirectories
    mkdir -p $INSTALL_DIR/hls
    mkdir -p $INSTALL_DIR/dash
    mkdir -p $INSTALL_DIR/uploads
    mkdir -p $INSTALL_DIR/logs
    mkdir -p $INSTALL_DIR/static
    mkdir -p $INSTALL_DIR/templates
    mkdir -p $INSTALL_DIR/routes
    mkdir -p $INSTALL_DIR/utils
    
    # Set permissions
    chown -R www-data:www-data $INSTALL_DIR
    chmod -R 755 $INSTALL_DIR
    
    print_success "Directory structure created"
}

# Function to deploy StreamVibe code
deploy_streamvibe() {
    print_header "Deploying StreamVibe Code"
    
    cd $INSTALL_DIR
    
    if [ "$USE_REPO" = true ]; then
        # Clone from repository
        print_status "Cloning from repository: $REPO_URL"
        git clone $REPO_URL /tmp/streamvibe
        cp -R /tmp/streamvibe/* $INSTALL_DIR/
        rm -rf /tmp/streamvibe
    else
        # Create minimal files if no repository
        print_status "Creating minimal application structure"
        
        # Create app.py
        cat > $INSTALL_DIR/app.py << EOL
import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from flask_login import LoginManager

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Base class for SQLAlchemy models
class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "development-secret-key")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///streamvibe.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")
app.config["DEBUG"] = True

# Initialize the database
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'

@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Import and register blueprints
with app.app_context():
    try:
        # Import blueprints
        from routes.auth import auth_bp
        from routes.page import page_bp
        
        # Register blueprints
        app.register_blueprint(auth_bp)
        app.register_blueprint(page_bp)
        
        # Create database tables
        db.create_all()
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error during initialization: {e}")
EOL
        
        # Create main.py
        cat > $INSTALL_DIR/main.py << EOL
from app import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
EOL
        
        # Create models.py
        cat > $INSTALL_DIR/models.py << EOL
import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    profile_description = db.Column(db.Text, nullable=True)
    avatar_path = db.Column(db.String(255), nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Media(db.Model):
    __tablename__ = 'media'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=False)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    media_type = db.Column(db.String(20), nullable=False)  # video, audio
    duration = db.Column(db.Integer, nullable=True)  # Duration in seconds
    views = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __repr__(self):
        return f'<Media {self.title}>'

class Stream(db.Model):
    __tablename__ = 'streams'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    stream_key = db.Column(db.String(64), unique=True, nullable=False)
    is_live = db.Column(db.Boolean, default=False)
    viewers = db.Column(db.Integer, default=0)
    started_at = db.Column(db.DateTime, nullable=True)
    ended_at = db.Column(db.DateTime, nullable=True)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __repr__(self):
        return f'<Stream {self.title}>'
EOL
        
        # Create routes directory structure
        mkdir -p $INSTALL_DIR/routes
        
        # Create __init__.py in routes
        touch $INSTALL_DIR/routes/__init__.py
        
        # Create authentication routes
        cat > $INSTALL_DIR/routes/auth.py << EOL
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from models import User
import datetime

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('page.index'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('page.index'))
        else:
            flash('Invalid username or password', 'danger')
            
    return render_template('login.html')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('page.index'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('register.html')
            
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create new user
        user = User(
            username=username,
            email=email,
            created_at=datetime.datetime.utcnow()
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('auth.login'))
        
    return render_template('register.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('page.index'))
EOL
        
        # Create page routes
        cat > $INSTALL_DIR/routes/page.py << EOL
from flask import Blueprint, render_template
from flask_login import current_user

page_bp = Blueprint('page', __name__)

@page_bp.route('/')
def index():
    return render_template('index.html')
EOL
        
        # Create create_admin.py
        cat > $INSTALL_DIR/create_admin.py << EOL
import os
import sys
import datetime
from werkzeug.security import generate_password_hash
from sqlalchemy import create_engine, Column, Integer, String, Text, Boolean, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Get database URL from environment or use default
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///streamvibe.db")

# Set up database connection
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()
Base = declarative_base()

# Define User model for admin creation
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    profile_description = Column(Text, nullable=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

def create_admin_account(username="admin", email="admin@streamvibe.com", password="admin123"):
    # Create tables if they don't exist
    Base.metadata.create_all(engine)
    
    # Check if admin user already exists
    existing_admin = session.query(User).filter_by(is_admin=True).first()
    if existing_admin:
        print(f"Admin already exists: {existing_admin.username}")
        return
    
    # Check if username already exists
    existing_user = session.query(User).filter_by(username=username).first()
    if existing_user:
        print(f"Username already exists: {existing_user.username}")
        return
    
    # Create admin user
    admin = User(
        username=username,
        email=email,
        password_hash=generate_password_hash(password),
        is_admin=True,
        created_at=datetime.datetime.utcnow()
    )
    
    # Add to database
    try:
        session.add(admin)
        session.commit()
        print(f"Admin created successfully!")
        print(f"Username: {username}")
        print(f"Password: {password}")
    except Exception as e:
        session.rollback()
        print(f"Error creating admin: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 3:
        # If arguments provided, use them
        create_admin_account(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        # Otherwise use defaults
        create_admin_account()
EOL
        
        # Create templates directory
        mkdir -p $INSTALL_DIR/templates
        
        # Create base template
        cat > $INSTALL_DIR/templates/base.html << EOL
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}StreamVibe{% endblock %}</title>
    <link rel="stylesheet" href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css">
    <style>
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .main-content {
            flex: 1;
        }
        .navbar-brand {
            font-weight: bold;
            background: linear-gradient(45deg, #9370DB, #4169E1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .footer {
            background-color: rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
            margin-top: auto;
        }
    </style>
    {% block styles %}{% endblock %}
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">StreamVibe</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="/">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/browse">Browse</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/streams">Live Streams</a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    {% if current_user.is_authenticated %}
                        {% if current_user.is_admin %}
                        <li class="nav-item">
                            <a class="nav-link" href="/admin">Admin</a>
                        </li>
                        {% endif %}
                        <li class="nav-item">
                            <a class="nav-link" href="/studio">Studio</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                                {{ current_user.username }}
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="/profile">Profile</a></li>
                                <li><a class="dropdown-item" href="/settings">Settings</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="/logout">Logout</a></li>
                            </ul>
                        </li>
                    {% else %}
                        <li class="nav-item">
                            <a class="nav-link" href="/login">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/register">Register</a>
                        </li>
                    {% endif %}
                </ul>
            </div>
        </div>
    </nav>

    <div class="container main-content">
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ category }} alert-dismissible fade show mt-3" role="alert">
                        {{ message }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                {% endfor %}
            {% endif %}
        {% endwith %}
        
        {% block content %}{% endblock %}
    </div>

    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>&copy; 2025 StreamVibe. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="/terms" class="text-decoration-none me-3">Terms</a>
                    <a href="/privacy" class="text-decoration-none me-3">Privacy</a>
                    <a href="/help" class="text-decoration-none">Help</a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    {% block scripts %}{% endblock %}
</body>
</html>
EOL
        
        # Create index template
        cat > $INSTALL_DIR/templates/index.html << EOL
{% extends "base.html" %}

{% block title %}StreamVibe - Your Media Streaming Platform{% endblock %}

{% block content %}
<div class="row mt-5">
    <div class="col-md-8 mx-auto text-center">
        <h1 class="display-4">Welcome to StreamVibe</h1>
        <p class="lead">The ultimate streaming platform for creators and viewers</p>
        
        <div class="mt-5">
            <div class="row">
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Watch Content</h5>
                            <p class="card-text">Discover and watch amazing content created by our community.</p>
                            <a href="/browse" class="btn btn-primary">Browse Videos</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Go Live</h5>
                            <p class="card-text">Start streaming your own content to viewers worldwide.</p>
                            <a href="/studio" class="btn btn-primary">Start Streaming</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Upload Videos</h5>
                            <p class="card-text">Upload your content and share it with the community.</p>
                            <a href="/studio/upload" class="btn btn-primary">Upload Now</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-5">
    <div class="col-md-12">
        <h2 class="text-center mb-4">Featured Content</h2>
        <p class="text-center text-muted">No featured content yet. Start uploading and streaming to see content here!</p>
    </div>
</div>
{% endblock %}
EOL
        
        # Create login template
        cat > $INSTALL_DIR/templates/login.html << EOL
{% extends "base.html" %}

{% block title %}StreamVibe - Login{% endblock %}

{% block content %}
<div class="row mt-5">
    <div class="col-md-6 mx-auto">
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Login</h4>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="rememberMe" name="remember">
                        <label class="form-check-label" for="rememberMe">Remember me</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
                <div class="mt-3">
                    <p>Don't have an account? <a href="/register">Register here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOL
        
        # Create register template
        cat > $INSTALL_DIR/templates/register.html << EOL
{% extends "base.html" %}

{% block title %}StreamVibe - Register{% endblock %}

{% block content %}
<div class="row mt-5">
    <div class="col-md-6 mx-auto">
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Register</h4>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email address</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="confirmPassword" class="form-label">Confirm Password</label>
                        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="termsAgree" name="termsAgree" required>
                        <label class="form-check-label" for="termsAgree">I agree to the <a href="/terms">Terms of Service</a></label>
                    </div>
                    <button type="submit" class="btn btn-primary">Register</button>
                </form>
                <div class="mt-3">
                    <p>Already have an account? <a href="/login">Login here</a></p>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOL
    fi
    
    # Create virtual environment
    print_status "Setting up Python virtual environment"
    
    python3 -m venv $INSTALL_DIR/venv
    source $INSTALL_DIR/venv/bin/activate
    
    # Install Python dependencies
    print_status "Installing Python dependencies"
    
    pip install --upgrade pip
    pip install flask flask-login flask-sqlalchemy flask-wtf flask-migrate email-validator
    pip install psycopg2-binary python-dotenv requests gunicorn
    
    # Create .env file
    cat > $INSTALL_DIR/.env << EOL
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
SESSION_SECRET=$SESSION_SECRET
STREAM_SERVER=$DOMAIN_NAME
DOMAIN_NAME=$DOMAIN_NAME
RTMP_SERVER=rtmp://$DOMAIN_NAME/live
HLS_SERVER=https://$DOMAIN_NAME/hls
DASH_SERVER=https://$DOMAIN_NAME/dash
EOL
    
    # Set permissions
    chown -R www-data:www-data $INSTALL_DIR
    chmod -R 755 $INSTALL_DIR
    
    print_success "StreamVibe code deployed successfully"
}

# Function to create systemd service
create_systemd_service() {
    print_header "Creating SystemD Service"
    
    # Create streamvibe service
    cat > /etc/systemd/system/streamvibe.service << EOL
[Unit]
Description=StreamVibe Gunicorn Service
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin"
EnvironmentFile=$INSTALL_DIR/.env
ExecStart=$INSTALL_DIR/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
Restart=always

[Install]
WantedBy=multi-user.target
EOL
    
    # Reload systemd
    systemctl daemon-reload
    
    # Enable and start service
    systemctl enable streamvibe
    
    print_success "SystemD service created"
}

# Function to initialize database
initialize_database() {
    print_header "Initializing Database"
    
    cd $INSTALL_DIR
    source venv/bin/activate
    
    # Load environment variables
    set -a
    source .env
    set +a
    
    # Initialize database if needed
    python -c "from app import db; db.create_all()" || print_warning "Database initialization may have failed"
    
    # Create admin user
    python create_admin.py "$ADMIN_USER" "$ADMIN_EMAIL" "$ADMIN_PASS" || print_warning "Admin user creation may have failed"
    
    print_success "Database initialized"
    print_status "Admin credentials:"
    print_status "  Username: $ADMIN_USER"
    print_status "  Email: $ADMIN_EMAIL"
    print_status "  Password: $ADMIN_PASS"
}

# Function to setup SSL (if needed)
setup_ssl() {
    if [ "$USE_HTTPS" = true ]; then
        print_header "Setting Up SSL"
        
        # Check if the domain resolves to the server
        server_ip=$(curl -s https://ipinfo.io/ip)
        domain_ip=$(dig +short $DOMAIN_NAME)
        
        if [ "$server_ip" != "$domain_ip" ]; then
            print_warning "The domain $DOMAIN_NAME does not point to this server's IP ($server_ip)"
            print_warning "SSL setup will be skipped. You can set it up later with:"
            print_status "certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME"
        else
            # Set up SSL
            certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME --non-interactive --agree-tos --email $ADMIN_EMAIL --redirect || {
                print_warning "SSL setup failed. You can set it up later with:"
                print_status "certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME"
            }
        fi
    else
        print_status "SSL setup skipped as per configuration"
    fi
}

# Function to restart services
restart_services() {
    print_header "Restarting Services"
    
    systemctl restart postgresql
    systemctl restart nginx
    systemctl restart streamvibe
    
    print_success "All services restarted"
}

# Function to check if services are running
check_services() {
    print_header "Checking Services"
    
    postgresql_status=$(systemctl is-active postgresql)
    nginx_status=$(systemctl is-active nginx)
    streamvibe_status=$(systemctl is-active streamvibe)
    
    echo "PostgreSQL: $postgresql_status"
    echo "NGINX: $nginx_status"
    echo "StreamVibe: $streamvibe_status"
    
    if [ "$postgresql_status" = "active" ] && [ "$nginx_status" = "active" ] && [ "$streamvibe_status" = "active" ]; then
        print_success "All services are running correctly"
    else
        print_warning "Some services are not running correctly"
    fi
}

# Function to create installation report
create_report() {
    print_header "Creating Installation Report"
    
    mkdir -p $INSTALL_DIR/install-report
    
    # Create report file
    cat > $INSTALL_DIR/install-report/installation-summary.txt << EOL
StreamVibe Installation Summary
===================================
Installation Date: $(date)
Server IP: $(curl -s https://ipinfo.io/ip)

Configuration:
-------------
Domain Name: $DOMAIN_NAME
Installation Directory: $INSTALL_DIR
SSL Enabled: $USE_HTTPS

Database Information:
------------------
Database Name: $DB_NAME
Database User: $DB_USER
Database Password: $DB_PASS
Database URL: postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME

Admin Account:
-----------
Username: $ADMIN_USER
Email: $ADMIN_EMAIL
Password: $ADMIN_PASS

Access URLs:
---------
Website: http://$DOMAIN_NAME or https://$DOMAIN_NAME (if SSL is enabled)
Admin Login: http://$DOMAIN_NAME/login or https://$DOMAIN_NAME/login (if SSL is enabled)

Streaming Info:
------------
RTMP Streaming URL: rtmp://$DOMAIN_NAME/live
Stream Key: (Create in the StreamVibe dashboard)

Service Status:
------------
PostgreSQL: $(systemctl is-active postgresql)
NGINX: $(systemctl is-active nginx)
StreamVibe: $(systemctl is-active streamvibe)

Next Steps:
---------
1. Access your StreamVibe website at http://$DOMAIN_NAME
2. Log in with the admin credentials above
3. Start creating streams and uploading content
EOL
    
    print_success "Installation report created: $INSTALL_DIR/install-report/installation-summary.txt"
}

# Main installation function
main() {
    check_root
    
    # Show welcome message
    clear
    cat << EOL
===================================================
     StreamVibe Complete Installation Script      
===================================================

This script will install and configure:
- PostgreSQL database
- NGINX web server with RTMP module
- StreamVibe application
- Automatic SSL setup (optional)

EOL
    
    # Ask for configuration
    ask_for_config
    
    # Perform installation steps
    update_system
    install_dependencies
    setup_nginx_rtmp
    configure_nginx
    setup_database
    create_directory_structure
    deploy_streamvibe
    create_systemd_service
    initialize_database
    setup_ssl
    restart_services
    check_services
    create_report
    
    # Display final message
    clear
    cat << EOL
===================================================
     StreamVibe Installation Complete!      
===================================================

Your StreamVibe instance is now set up at:
http://$DOMAIN_NAME$([ "$USE_HTTPS" = true ] && echo " or https://$DOMAIN_NAME")

Admin login:
Username: $ADMIN_USER
Password: $ADMIN_PASS

A detailed installation report has been saved to:
$INSTALL_DIR/install-report/installation-summary.txt

Enjoy your new StreamVibe platform!
===================================================
EOL
}

# Run the main function
main