import os

class Config:
    """Base configuration class"""
    DEBUG = False
    TESTING = False
    SECRET_KEY = os.environ.get("SESSION_SECRET", "dev-secret-key")
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL", "sqlite:///streamapp.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(os.getcwd(), "uploads")
    MAX_CONTENT_LENGTH = 1000 * 1024 * 1024  # 1000 MB max upload
    
    # Stream settings
    STREAM_SERVER = os.environ.get("STREAM_SERVER", "streamvibe.biz")
    DOMAIN_NAME = os.environ.get("DOMAIN_NAME", "streamvibe.biz")
    TURN_SERVER = os.environ.get("TURN_SERVER", "")
    TURN_USERNAME = os.environ.get("TURN_USERNAME", "")
    TURN_PASSWORD = os.environ.get("TURN_PASSWORD", "")
    
    # NGINX RTMP settings
    RTMP_SERVER = os.environ.get("RTMP_SERVER", "rtmp://streamvibe.biz/live")
    RTMP_PORT = os.environ.get("RTMP_PORT", "1935")
    
    # HLS settings
    HLS_SERVER = os.environ.get("HLS_SERVER", "https://streamvibe.biz/hls")
    HLS_SEGMENT_DURATION = os.environ.get("HLS_SEGMENT_DURATION", "4")
    
    # DASH settings
    DASH_SERVER = os.environ.get("DASH_SERVER", "https://streamvibe.biz/dash")
    DASH_SEGMENT_DURATION = os.environ.get("DASH_SEGMENT_DURATION", "4")
    
    # FFmpeg settings
    FFMPEG_BINARY = os.environ.get("FFMPEG_BINARY", "ffmpeg")
    FFPROBE_BINARY = os.environ.get("FFPROBE_BINARY", "ffprobe")

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False

class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"

# Select the appropriate configuration based on environment
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

def get_config():
    """Returns the appropriate configuration object based on environment"""
    env = os.environ.get("FLASK_ENV", "default")
    return config.get(env, config['default'])
