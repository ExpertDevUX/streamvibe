# Empty __init__.py file to mark the routes directory as a package
