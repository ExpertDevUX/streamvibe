import os
import json
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify, current_app, send_from_directory
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from models import Media, Comment
from utils.media_processor import process_media, generate_thumbnail, get_media_duration, get_media_qualities

media_bp = Blueprint('media', __name__)

# Allowed file extensions
ALLOWED_EXTENSIONS = {'mp4', 'webm', 'avi', 'mov', 'mp3', 'wav', 'ogg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@media_bp.route('/')
def index():
    # Get latest videos and popular videos for the homepage
    latest_videos = Media.query.filter_by(media_type='video').order_by(Media.created_at.desc()).limit(8).all()
    popular_videos = Media.query.filter_by(media_type='video').order_by(Media.views.desc()).limit(8).all()
    
    # Get latest audio files
    latest_audio = Media.query.filter_by(media_type='audio').order_by(Media.created_at.desc()).limit(4).all()
    
    return render_template('index.html', 
                           latest_videos=latest_videos, 
                           popular_videos=popular_videos,
                           latest_audio=latest_audio)

@media_bp.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'media_file' not in request.files:
            flash('No file part', 'danger')
            return redirect(request.url)
        
        file = request.files['media_file']
        
        # If the user does not select a file, the browser submits an
        # empty file without a filename.
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            unique_filename = f"{timestamp}_{filename}"
            filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(filepath)
            
            # Get media metadata
            title = request.form.get('title', 'Untitled')
            description = request.form.get('description', '')
            tags = request.form.get('tags', '')
            
            # Determine if this is video or audio
            file_ext = filename.rsplit('.', 1)[1].lower()
            if file_ext in ['mp4', 'webm', 'avi', 'mov']:
                media_type = 'video'
            else:
                media_type = 'audio'
            
            # Process media file (generate different qualities, get duration)
            try:
                processed_path = process_media(filepath, media_type)
                thumbnail_path = generate_thumbnail(filepath) if media_type == 'video' else None
                duration = get_media_duration(filepath)
                quality_options = json.dumps(get_media_qualities(processed_path, media_type))
                
                # Create new media entry
                new_media = Media(
                    title=title,
                    description=description,
                    file_path=processed_path,
                    thumbnail_path=thumbnail_path,
                    media_type=media_type,
                    duration=duration,
                    quality_options=quality_options,
                    tags=tags,
                    user_id=current_user.id
                )
                
                db.session.add(new_media)
                db.session.commit()
                
                flash('Media uploaded successfully!', 'success')
                return redirect(url_for('media.view', media_id=new_media.id))
            
            except Exception as e:
                flash(f'Error processing media: {str(e)}', 'danger')
                return redirect(request.url)
        else:
            flash('File type not allowed. Please upload MP4, WEBM, AVI, MOV, MP3, WAV, or OGG files.', 'danger')
            return redirect(request.url)
    
    return render_template('upload.html')

@media_bp.route('/media/<int:media_id>')
def view(media_id):
    media = Media.query.get_or_404(media_id)
    
    # Increment view count
    media.views += 1
    db.session.commit()
    
    # Get comments
    comments = Comment.query.filter_by(media_id=media_id).order_by(Comment.created_at.desc()).all()
    
    # Get related media based on tags
    related_media = []
    if media.tags:
        tags = media.tags.split(',')
        related_query = Media.query.filter(
            Media.id != media_id,
            Media.media_type == media.media_type
        )
        
        for tag in tags:
            related_query = related_query.filter(Media.tags.like(f'%{tag.strip()}%'))
        
        related_media = related_query.limit(6).all()
    
    return render_template('player.html', media=media, comments=comments, related_media=related_media)

@media_bp.route('/media/<int:media_id>/comment', methods=['POST'])
@login_required
def add_comment(media_id):
    media = Media.query.get_or_404(media_id)
    
    content = request.form.get('content')
    if not content:
        flash('Comment cannot be empty', 'danger')
        return redirect(url_for('media.view', media_id=media_id))
    
    new_comment = Comment(
        content=content,
        user_id=current_user.id,
        media_id=media_id
    )
    
    db.session.add(new_comment)
    db.session.commit()
    
    flash('Comment added successfully', 'success')
    return redirect(url_for('media.view', media_id=media_id))

@media_bp.route('/search')
def search():
    query = request.args.get('q', '')
    media_type = request.args.get('type', 'all')
    
    if not query:
        return render_template('search.html', results=[], query='', media_type='all')
    
    # Build search query
    search_query = Media.query.filter(
        (Media.title.ilike(f'%{query}%')) | 
        (Media.description.ilike(f'%{query}%')) |
        (Media.tags.ilike(f'%{query}%'))
    )
    
    if media_type != 'all':
        search_query = search_query.filter_by(media_type=media_type)
    
    results = search_query.order_by(Media.created_at.desc()).all()
    
    return render_template('search.html', results=results, query=query, media_type=media_type)

@media_bp.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)
