import os
import uuid
from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from app import db
from models import User, Media, Stream
from utils.storage import get_upload_path

users_bp = Blueprint('users', __name__)

@users_bp.route('/profile')
@login_required
def profile():
    # Get user's media
    user_media = Media.query.filter_by(user_id=current_user.id).order_by(Media.created_at.desc()).all()
    
    # Get user's streams
    user_streams = Stream.query.filter_by(user_id=current_user.id).order_by(Stream.created_at.desc()).all()
    
    return render_template('profile.html', 
                          user=current_user, 
                          media=user_media,
                          streams=user_streams)

@users_bp.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        profile_description = request.form.get('profile_description')
        
        # Check if username already exists
        if username != current_user.username and User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return redirect(url_for('users.edit_profile'))
        
        # Check if email already exists
        if email != current_user.email and User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return redirect(url_for('users.edit_profile'))
        
        # Handle avatar upload
        if 'avatar' in request.files:
            avatar_file = request.files['avatar']
            if avatar_file and avatar_file.filename != '':
                # Check file extension
                allowed_extensions = {'png', 'jpg', 'jpeg', 'gif'}
                file_ext = avatar_file.filename.rsplit('.', 1)[1].lower() if '.' in avatar_file.filename else ''
                
                if file_ext in allowed_extensions:
                    # Generate unique filename
                    filename = secure_filename(f"{uuid.uuid4()}.{file_ext}")
                    avatar_path = get_upload_path(filename, current_user.id)
                    
                    # Ensure directory exists
                    os.makedirs(os.path.dirname(avatar_path), exist_ok=True)
                    
                    # Save the file
                    avatar_file.save(avatar_path)
                    
                    # Update user's avatar path
                    current_user.avatar_path = avatar_path
                else:
                    flash('Invalid file format. Please upload a PNG, JPG, JPEG, or GIF file.', 'danger')
                    return redirect(url_for('users.edit_profile'))
        
        # Update user
        current_user.username = username
        current_user.email = email
        current_user.profile_description = profile_description
        
        db.session.commit()
        
        flash('Profile updated successfully', 'success')
        return redirect(url_for('users.profile'))
    
    return render_template('profile.html', user=current_user, edit_mode=True)

@users_bp.route('/profile/change_password', methods=['POST'])
@login_required
def change_password():
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')
    
    # Check if current password is correct
    if not current_user.check_password(current_password):
        flash('Current password is incorrect', 'danger')
        return redirect(url_for('users.edit_profile'))
    
    # Check if new passwords match
    if new_password != confirm_password:
        flash('New passwords do not match', 'danger')
        return redirect(url_for('users.edit_profile'))
    
    # Update password
    current_user.set_password(new_password)
    db.session.commit()
    
    flash('Password updated successfully', 'success')
    return redirect(url_for('users.profile'))

@users_bp.route('/user/<username>')
def user_profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    
    # Get user's public media
    user_media = Media.query.filter_by(user_id=user.id).order_by(Media.created_at.desc()).all()
    
    # Get user's public streams
    if current_user.is_authenticated and current_user.id == user.id:
        # Show all streams to the owner
        user_streams = Stream.query.filter_by(user_id=user.id).order_by(Stream.created_at.desc()).all()
    else:
        # Show only public streams to others
        user_streams = Stream.query.filter_by(user_id=user.id, is_public=True).order_by(Stream.created_at.desc()).all()
    
    return render_template('profile.html', 
                          user=user, 
                          media=user_media,
                          streams=user_streams,
                          is_owner=current_user.is_authenticated and current_user.id == user.id)
