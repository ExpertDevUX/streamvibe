from datetime import datetime, timedelta
import json
from flask import Blueprint, render_template, jsonify, request, current_app
from flask_login import login_required, current_user
from sqlalchemy import func, desc, extract
from app import db
from models import Media, Stream, Analytics, AnalyticsEvent, User

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/analytics')
@login_required
def view_analytics():
    # Get user's media
    user_media = Media.query.filter_by(user_id=current_user.id).all()
    
    # Get user's streams
    user_streams = Stream.query.filter_by(user_id=current_user.id).all()
    
    return render_template('analytics.html', 
                          user_media=user_media,
                          user_streams=user_streams)

@analytics_bp.route('/analytics/data', methods=['GET'])
@login_required
def get_analytics_data():
    media_id = request.args.get('media_id', type=int)
    stream_id = request.args.get('stream_id', type=int)
    period = request.args.get('period', 'week')
    
    # Determine date range based on period
    today = datetime.utcnow().date()
    if period == 'week':
        start_date = today - timedelta(days=7)
    elif period == 'month':
        start_date = today - timedelta(days=30)
    elif period == 'year':
        start_date = today - timedelta(days=365)
    else:
        start_date = today - timedelta(days=7)  # Default to week
    
    # Build query
    query = db.session.query(
        func.date(Analytics.date),
        func.sum(Analytics.views),
        func.sum(Analytics.unique_viewers),
        func.sum(Analytics.watch_time),
        func.max(Analytics.peak_viewers),
        func.sum(Analytics.device_mobile),
        func.sum(Analytics.device_desktop),
        func.sum(Analytics.device_tablet),
        func.sum(Analytics.device_other),
        func.avg(Analytics.avg_watch_duration),
        func.avg(Analytics.engagement_rate),
        func.avg(Analytics.bounce_rate)
    ).filter(
        Analytics.user_id == current_user.id,
        Analytics.date >= start_date,
        Analytics.date <= today
    )
    
    # Filter by media or stream if provided
    if media_id:
        query = query.filter(Analytics.media_id == media_id)
    if stream_id:
        query = query.filter(Analytics.stream_id == stream_id)
    
    # Group by date
    results = query.group_by(func.date(Analytics.date)).all()
    
    # Format data for charts
    dates = []
    views = []
    unique_viewers = []
    watch_time = []
    peak_viewers = []
    device_mobile = []
    device_desktop = []
    device_tablet = []
    device_other = []
    avg_watch_duration = []
    engagement_rate = []
    bounce_rate = []
    
    for row in results:
        dates.append(row[0].strftime('%Y-%m-%d'))
        views.append(row[1] or 0)
        unique_viewers.append(row[2] or 0)
        watch_time.append((row[3] or 0) / 60)  # Convert seconds to minutes
        peak_viewers.append(row[4] or 0)
        device_mobile.append(row[5] or 0)
        device_desktop.append(row[6] or 0)
        device_tablet.append(row[7] or 0)
        device_other.append(row[8] or 0)
        avg_watch_duration.append((row[9] or 0) / 60)  # Convert seconds to minutes
        engagement_rate.append(float(row[10] or 0))
        bounce_rate.append(float(row[11] or 0))
    
    # Get total stats
    total_stats = {
        'total_views': sum(views),
        'total_unique_viewers': sum(unique_viewers),
        'total_watch_time': sum(watch_time),
        'max_peak_viewers': max(peak_viewers) if peak_viewers else 0,
        'avg_session_duration': sum(avg_watch_duration) / len(avg_watch_duration) if avg_watch_duration else 0,
        'avg_engagement_rate': sum(engagement_rate) / len(engagement_rate) if engagement_rate else 0,
        'avg_bounce_rate': sum(bounce_rate) / len(bounce_rate) if bounce_rate else 0
    }
    
    # Calculate device breakdown
    total_devices = sum(device_mobile) + sum(device_desktop) + sum(device_tablet) + sum(device_other)
    device_breakdown = {
        'mobile': round((sum(device_mobile) / total_devices) * 100 if total_devices > 0 else 0, 1),
        'desktop': round((sum(device_desktop) / total_devices) * 100 if total_devices > 0 else 0, 1),
        'tablet': round((sum(device_tablet) / total_devices) * 100 if total_devices > 0 else 0, 1),
        'other': round((sum(device_other) / total_devices) * 100 if total_devices > 0 else 0, 1)
    }
    
    # Get country data if available
    country_data = {}
    country_query = db.session.query(
        Analytics.country_data
    ).filter(
        Analytics.user_id == current_user.id,
        Analytics.date >= start_date,
        Analytics.date <= today,
        Analytics.country_data.isnot(None)
    )
    
    if media_id:
        country_query = country_query.filter(Analytics.media_id == media_id)
    if stream_id:
        country_query = country_query.filter(Analytics.stream_id == stream_id)
    
    country_results = country_query.all()
    
    for row in country_results:
        if row[0]:
            try:
                country_json = json.loads(row[0])
                for country, count in country_json.items():
                    country_data[country] = country_data.get(country, 0) + count
            except json.JSONDecodeError:
                current_app.logger.warning(f"Invalid JSON in country_data: {row[0]}")
    
    # Sort and limit to top 10 countries
    country_data = dict(sorted(country_data.items(), key=lambda x: x[1], reverse=True)[:10])
    
    # Get referrer data if available
    referrer_data = {}
    referrer_query = db.session.query(
        Analytics.referrer_data
    ).filter(
        Analytics.user_id == current_user.id,
        Analytics.date >= start_date,
        Analytics.date <= today,
        Analytics.referrer_data.isnot(None)
    )
    
    if media_id:
        referrer_query = referrer_query.filter(Analytics.media_id == media_id)
    if stream_id:
        referrer_query = referrer_query.filter(Analytics.stream_id == stream_id)
    
    referrer_results = referrer_query.all()
    
    for row in referrer_results:
        if row[0]:
            try:
                referrer_json = json.loads(row[0])
                for referrer, count in referrer_json.items():
                    referrer_data[referrer] = referrer_data.get(referrer, 0) + count
            except json.JSONDecodeError:
                current_app.logger.warning(f"Invalid JSON in referrer_data: {row[0]}")
    
    # Sort and limit to top 5 referrers
    referrer_data = dict(sorted(referrer_data.items(), key=lambda x: x[1], reverse=True)[:5])
    
    return jsonify({
        'dates': dates,
        'views': views,
        'unique_viewers': unique_viewers,
        'watch_time': watch_time,
        'peak_viewers': peak_viewers,
        'device_mobile': device_mobile,
        'device_desktop': device_desktop,
        'device_tablet': device_tablet,
        'device_other': device_other,
        'avg_watch_duration': avg_watch_duration,
        'engagement_rate': engagement_rate,
        'bounce_rate': bounce_rate,
        'total_stats': total_stats,
        'device_breakdown': device_breakdown,
        'country_data': country_data,
        'referrer_data': referrer_data
    })

@analytics_bp.route('/analytics/summary', methods=['GET'])
@login_required
def get_analytics_summary():
    # Get total views for all user's media
    total_media_views = db.session.query(func.sum(Media.views)).filter(
        Media.user_id == current_user.id
    ).scalar() or 0
    
    # Get total number of media items
    total_media_count = Media.query.filter_by(user_id=current_user.id).count()
    
    # Get total number of streams
    total_stream_count = Stream.query.filter_by(user_id=current_user.id).count()
    
    # Get most viewed media
    most_viewed_media = Media.query.filter_by(user_id=current_user.id).order_by(
        Media.views.desc()
    ).first()
    
    # Get most viewed stream
    most_viewed_stream = Stream.query.filter_by(user_id=current_user.id).order_by(
        Stream.viewers.desc()
    ).first()
    
    # Calculate total watch time from analytics
    total_watch_time = db.session.query(func.sum(Analytics.watch_time)).filter(
        Analytics.user_id == current_user.id
    ).scalar() or 0
    
    # Calculate average engagement rate
    avg_engagement = db.session.query(func.avg(Analytics.engagement_rate)).filter(
        Analytics.user_id == current_user.id,
        Analytics.engagement_rate > 0
    ).scalar() or 0
    
    # Get trending content (most viewed in last 7 days)
    today = datetime.utcnow().date()
    seven_days_ago = today - timedelta(days=7)
    
    trending_media = Media.query.join(Analytics, Analytics.media_id == Media.id).filter(
        Media.user_id == current_user.id,
        Analytics.date >= seven_days_ago
    ).group_by(Media.id).order_by(
        func.sum(Analytics.views).desc()
    ).first()
    
    trending_stream = Stream.query.join(Analytics, Analytics.stream_id == Stream.id).filter(
        Stream.user_id == current_user.id,
        Analytics.date >= seven_days_ago
    ).group_by(Stream.id).order_by(
        func.sum(Analytics.views).desc()
    ).first()
    
    # Get audience demographics (devices)
    device_stats = db.session.query(
        func.sum(Analytics.device_mobile),
        func.sum(Analytics.device_desktop),
        func.sum(Analytics.device_tablet),
        func.sum(Analytics.device_other)
    ).filter(
        Analytics.user_id == current_user.id
    ).first()
    
    total_devices = sum(0 if x is None else x for x in device_stats)
    devices = {
        'mobile': round((device_stats[0] or 0) / total_devices * 100 if total_devices > 0 else 0, 1),
        'desktop': round((device_stats[1] or 0) / total_devices * 100 if total_devices > 0 else 0, 1),
        'tablet': round((device_stats[2] or 0) / total_devices * 100 if total_devices > 0 else 0, 1),
        'other': round((device_stats[3] or 0) / total_devices * 100 if total_devices > 0 else 0, 1)
    }
    
    # Calculate growth (compare current month with previous month)
    this_month = today.replace(day=1)
    last_month = (this_month - timedelta(days=1)).replace(day=1)
    
    current_month_views = db.session.query(func.sum(Analytics.views)).filter(
        Analytics.user_id == current_user.id,
        Analytics.date >= this_month
    ).scalar() or 0
    
    previous_month_views = db.session.query(func.sum(Analytics.views)).filter(
        Analytics.user_id == current_user.id,
        Analytics.date >= last_month,
        Analytics.date < this_month
    ).scalar() or 0
    
    growth = {
        'views_percent': round(((current_month_views - previous_month_views) / previous_month_views * 100) 
                              if previous_month_views > 0 else 100, 1),
        'current_month_views': current_month_views,
        'previous_month_views': previous_month_views
    }
    
    return jsonify({
        'total_media_views': total_media_views,
        'total_media_count': total_media_count,
        'total_stream_count': total_stream_count,
        'total_watch_time_minutes': round(total_watch_time / 60),
        'avg_engagement_rate': round(avg_engagement * 100, 1),
        'most_viewed_media': {
            'title': most_viewed_media.title,
            'views': most_viewed_media.views,
            'id': most_viewed_media.id
        } if most_viewed_media else None,
        'most_viewed_stream': {
            'title': most_viewed_stream.title,
            'viewers': most_viewed_stream.viewers,
            'id': most_viewed_stream.id
        } if most_viewed_stream else None,
        'trending_media': {
            'title': trending_media.title,
            'id': trending_media.id
        } if trending_media else None,
        'trending_stream': {
            'title': trending_stream.title,
            'id': trending_stream.id
        } if trending_stream else None,
        'devices': devices,
        'growth': growth
    })

@analytics_bp.route('/analytics/events', methods=['POST'])
def record_analytics_event():
    """API endpoint to record analytics events from the client side"""
    try:
        # Get data from request
        data = request.json
        
        # Required fields
        if not all(k in data for k in ['user_id', 'event_type', 'session_id']):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Create new event
        event = AnalyticsEvent(
            user_id=data['user_id'],
            media_id=data.get('media_id'),
            stream_id=data.get('stream_id'),
            event_type=data['event_type'],
            value=data.get('value'),
            session_id=data['session_id'],
            device_type=data.get('device_type'),
            browser=data.get('browser'),
            os=data.get('os'),
            country_code=data.get('country_code'),
            referrer=data.get('referrer')
        )
        
        db.session.add(event)
        db.session.commit()
        
        # Aggregate analytics data daily
        aggregate_event_data(event)
        
        return jsonify({'success': True}), 200
    except Exception as e:
        current_app.logger.error(f"Error recording analytics event: {str(e)}")
        return jsonify({'error': 'Internal server error'}), 500

def aggregate_event_data(event):
    """Aggregate event data into the daily analytics table"""
    try:
        today = datetime.utcnow().date()
        
        # Get or create analytics record for today
        analytics = Analytics.query.filter_by(
            date=today,
            user_id=event.user_id,
            media_id=event.media_id,
            stream_id=event.stream_id
        ).first()
        
        if not analytics:
            analytics = Analytics(
                date=today,
                user_id=event.user_id,
                media_id=event.media_id,
                stream_id=event.stream_id,
                views=0,
                unique_viewers=0,
                watch_time=0,
                peak_viewers=0,
                device_mobile=0,
                device_desktop=0,
                device_tablet=0,
                device_other=0,
                avg_watch_duration=0,
                engagement_rate=0,
                bounce_rate=0
            )
        
        # Update analytics based on event type
        if event.event_type == 'view':
            analytics.views += 1
            
            # Check if this is a unique viewer for today
            session_count = AnalyticsEvent.query.filter(
                AnalyticsEvent.date == today,
                AnalyticsEvent.user_id == event.user_id,
                AnalyticsEvent.session_id == event.session_id,
                AnalyticsEvent.media_id == event.media_id if event.media_id else True,
                AnalyticsEvent.stream_id == event.stream_id if event.stream_id else True
            ).count()
            
            if session_count <= 1:  # If this is the first event for this session
                analytics.unique_viewers += 1
                
            # Update device stats
            if event.device_type == 'mobile':
                analytics.device_mobile += 1
            elif event.device_type == 'desktop':
                analytics.device_desktop += 1
            elif event.device_type == 'tablet':
                analytics.device_tablet += 1
            else:
                analytics.device_other += 1
                
            # Update country data
            if event.country_code:
                country_data = {}
                if analytics.country_data:
                    try:
                        country_data = json.loads(analytics.country_data)
                    except json.JSONDecodeError:
                        country_data = {}
                
                country_data[event.country_code] = country_data.get(event.country_code, 0) + 1
                analytics.country_data = json.dumps(country_data)
                
            # Update referrer data
            if event.referrer:
                referrer_data = {}
                if analytics.referrer_data:
                    try:
                        referrer_data = json.loads(analytics.referrer_data)
                    except json.JSONDecodeError:
                        referrer_data = {}
                
                # Simplify referrer to domain
                domain = event.referrer.split('//')[-1].split('/')[0]
                referrer_data[domain] = referrer_data.get(domain, 0) + 1
                analytics.referrer_data = json.dumps(referrer_data)
                
        elif event.event_type == 'play':
            # For streams, increment peak viewers
            if event.stream_id:
                concurrent_viewers = AnalyticsEvent.query.filter(
                    AnalyticsEvent.timestamp >= datetime.utcnow() - timedelta(minutes=5),
                    AnalyticsEvent.stream_id == event.stream_id,
                    AnalyticsEvent.event_type.in_(['play', 'heartbeat']),
                    AnalyticsEvent.session_id != event.session_id  # Don't count this session twice
                ).distinct(AnalyticsEvent.session_id).count() + 1  # +1 for this session
                
                if concurrent_viewers > analytics.peak_viewers:
                    analytics.peak_viewers = concurrent_viewers
        
        elif event.event_type == 'watch':
            # Update watch time
            watch_time = int(event.value) if event.value else 0
            analytics.watch_time += watch_time
            
            # Update average watch duration
            if analytics.views > 0:
                analytics.avg_watch_duration = analytics.watch_time / analytics.views
        
        elif event.event_type == 'engagement':
            # Engagement events (comments, likes, shares, etc.)
            analytics.engagement_rate = event.value if event.value else analytics.engagement_rate
        
        elif event.event_type == 'bounce':
            # Bounce rate updates
            analytics.bounce_rate = event.value if event.value else analytics.bounce_rate
            
        # Save analytics
        db.session.add(analytics)
        db.session.commit()
        
    except Exception as e:
        current_app.logger.error(f"Error aggregating event data: {str(e)}")
        db.session.rollback()

@analytics_bp.route('/analytics/audience', methods=['GET'])
@login_required
def get_audience_data():
    """Get detailed audience data for advanced reporting"""
    period = request.args.get('period', 'month')
    
    # Determine date range based on period
    today = datetime.utcnow().date()
    if period == 'week':
        start_date = today - timedelta(days=7)
    elif period == 'month':
        start_date = today - timedelta(days=30)
    elif period == 'year':
        start_date = today - timedelta(days=365)
    else:
        start_date = today - timedelta(days=30)  # Default to month
    
    # Get device breakdown
    device_query = db.session.query(
        func.sum(Analytics.device_mobile),
        func.sum(Analytics.device_desktop),
        func.sum(Analytics.device_tablet),
        func.sum(Analytics.device_other)
    ).filter(
        Analytics.user_id == current_user.id,
        Analytics.date >= start_date,
        Analytics.date <= today
    ).first()
    
    total_devices = sum(0 if x is None else x for x in device_query)
    devices = {
        'mobile': round((device_query[0] or 0) / total_devices * 100 if total_devices > 0 else 0, 1),
        'desktop': round((device_query[1] or 0) / total_devices * 100 if total_devices > 0 else 0, 1),
        'tablet': round((device_query[2] or 0) / total_devices * 100 if total_devices > 0 else 0, 1),
        'other': round((device_query[3] or 0) / total_devices * 100 if total_devices > 0 else 0, 1)
    }
    
    # Get country data
    countries = {}
    country_results = db.session.query(Analytics.country_data).filter(
        Analytics.user_id == current_user.id,
        Analytics.date >= start_date,
        Analytics.date <= today,
        Analytics.country_data.isnot(None)
    ).all()
    
    for row in country_results:
        if row[0]:
            try:
                country_json = json.loads(row[0])
                for country, count in country_json.items():
                    countries[country] = countries.get(country, 0) + count
            except json.JSONDecodeError:
                current_app.logger.warning(f"Invalid JSON in country_data: {row[0]}")
    
    # Get top countries
    top_countries = dict(sorted(countries.items(), key=lambda x: x[1], reverse=True)[:10])
    
    # Get referrer data
    referrers = {}
    referrer_results = db.session.query(Analytics.referrer_data).filter(
        Analytics.user_id == current_user.id,
        Analytics.date >= start_date,
        Analytics.date <= today,
        Analytics.referrer_data.isnot(None)
    ).all()
    
    for row in referrer_results:
        if row[0]:
            try:
                referrer_json = json.loads(row[0])
                for referrer, count in referrer_json.items():
                    referrers[referrer] = referrers.get(referrer, 0) + count
            except json.JSONDecodeError:
                current_app.logger.warning(f"Invalid JSON in referrer_data: {row[0]}")
    
    # Get top referrers
    top_referrers = dict(sorted(referrers.items(), key=lambda x: x[1], reverse=True)[:5])
    
    return jsonify({
        'devices': devices,
        'countries': top_countries,
        'referrers': top_referrers
    })
