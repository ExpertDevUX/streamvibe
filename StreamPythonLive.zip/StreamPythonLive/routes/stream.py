import os
import uuid
from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify, current_app
from flask_login import login_required, current_user
from app import db
from models import Stream, Comment
from utils.stream_handler import (
    create_stream_session, end_stream_session, get_rtmp_url, 
    get_hls_url, get_dash_url, get_stream_info, check_nginx_status,
    restart_stream, check_stream_active
)

stream_bp = Blueprint('stream', __name__)

@stream_bp.route('/livestreams')
def list_streams():
    # Get all currently live streams
    live_streams = Stream.query.filter_by(is_live=True, is_public=True).order_by(Stream.viewers.desc()).all()
    
    # Get upcoming streams (those with scheduled start times in the future)
    upcoming_streams = Stream.query.filter_by(is_live=False, is_public=True).filter(
        Stream.started_at > datetime.utcnow()
    ).order_by(Stream.started_at).all()
    
    # Get recent ended streams
    recent_streams = Stream.query.filter_by(is_live=False, is_public=True).filter(
        Stream.ended_at.isnot(None)
    ).order_by(Stream.ended_at.desc()).limit(8).all()
    
    return render_template('livestream.html', 
                          live_streams=live_streams, 
                          upcoming_streams=upcoming_streams,
                          recent_streams=recent_streams)

@stream_bp.route('/livestream/create', methods=['GET', 'POST'])
@login_required
def create_stream():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        is_public = request.form.get('is_public') == 'on'
        tags = request.form.get('tags')
        
        # Generate a unique stream key
        stream_key = str(uuid.uuid4())
        
        # Create new stream
        new_stream = Stream(
            title=title,
            description=description,
            stream_key=stream_key,
            is_public=is_public,
            tags=tags,
            user_id=current_user.id
        )
        
        db.session.add(new_stream)
        db.session.commit()
        
        flash('Stream created successfully! You can now start streaming.', 'success')
        return redirect(url_for('stream.broadcaster', stream_id=new_stream.id))
    
    return render_template('create_livestream.html')

@stream_bp.route('/livestream/<int:stream_id>')
def view_stream(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if stream is public or if current user is the owner
    if not stream.is_public and (not current_user.is_authenticated or current_user.id != stream.user_id):
        flash('This stream is private', 'danger')
        return redirect(url_for('stream.list_streams'))
    
    # Increment viewer count
    if stream.is_live:
        stream.viewers += 1
        db.session.commit()
    
    # Get comments
    comments = Comment.query.filter_by(stream_id=stream_id).order_by(Comment.created_at.desc()).all()
    
    return render_template('player.html', stream=stream, comments=comments)

@stream_bp.route('/stream/<int:stream_id>/broadcaster')
@login_required
def broadcaster(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner
    if current_user.id != stream.user_id:
        flash('You are not authorized to broadcast this stream', 'danger')
        return redirect(url_for('stream.list_streams'))
    
    # Get TURN server settings from config
    turn_config = {
        'server': current_app.config.get('TURN_SERVER'),
        'username': current_app.config.get('TURN_USERNAME'),
        'credential': current_app.config.get('TURN_PASSWORD')
    }
    
    # Get RTMP and streaming info for OBS/XSplit
    rtmp_url = get_rtmp_url(stream.stream_key)
    hls_url = get_hls_url(stream.stream_key)
    dash_url = get_dash_url(stream.stream_key)
    
    # Pass streaming info to template
    streaming_info = {
        'rtmp_url': rtmp_url,
        'hls_url': hls_url,
        'dash_url': dash_url
    }
    
    return render_template('studio/broadcaster.html', 
                          stream=stream,
                          turn_config=turn_config,
                          streaming_info=streaming_info)

@stream_bp.route('/stream/<int:stream_id>/start', methods=['POST'])
@login_required
def start_stream(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner
    if current_user.id != stream.user_id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    # Start the stream
    try:
        stream.is_live = True
        stream.started_at = datetime.utcnow()
        stream.viewers = 0
        db.session.commit()
        
        # Create the streaming session
        session_info = create_stream_session(stream.stream_key)
        
        return jsonify({
            'success': True, 
            'message': 'Stream started successfully',
            'session_info': session_info
        })
    
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@stream_bp.route('/stream/<int:stream_id>/end', methods=['POST'])
@login_required
def end_stream(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner
    if current_user.id != stream.user_id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    # End the stream
    try:
        stream.is_live = False
        stream.ended_at = datetime.utcnow()
        db.session.commit()
        
        # End the streaming session
        end_stream_session(stream.stream_key)
        
        return jsonify({
            'success': True, 
            'message': 'Stream ended successfully'
        })
    
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@stream_bp.route('/livestream/<int:stream_id>/comment', methods=['POST'])
@login_required
def add_comment(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    content = request.form.get('content')
    if not content:
        flash('Comment cannot be empty', 'danger')
        return redirect(url_for('stream.view_stream', stream_id=stream_id))
    
    new_comment = Comment(
        content=content,
        user_id=current_user.id,
        stream_id=stream_id
    )
    
    db.session.add(new_comment)
    db.session.commit()
    
    # For AJAX requests
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'success': True,
            'comment': {
                'content': new_comment.content,
                'user': current_user.username,
                'timestamp': new_comment.created_at.strftime('%Y-%m-%d %H:%M:%S')
            }
        })
    
    flash('Comment added successfully', 'success')
    return redirect(url_for('stream.view_stream', stream_id=stream_id))

@stream_bp.route('/livestream/<int:stream_id>/get-comments', methods=['GET'])
def get_comments(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Get last comment ID from request
    last_comment_id = request.args.get('last_id', 0, type=int)
    
    # Get new comments
    new_comments = Comment.query.filter_by(stream_id=stream_id).filter(
        Comment.id > last_comment_id
    ).order_by(Comment.created_at).all()
    
    # Format comments for JSON response
    formatted_comments = []
    for comment in new_comments:
        formatted_comments.append({
            'id': comment.id,
            'content': comment.content,
            'user': comment.user.username,
            'timestamp': comment.created_at.strftime('%Y-%m-%d %H:%M:%S')
        })
    
    return jsonify({'comments': formatted_comments})

@stream_bp.route('/livestream/<int:stream_id>/delete', methods=['POST'])
@login_required
def delete_stream(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner
    if current_user.id != stream.user_id and not current_user.is_admin:
        flash('You are not authorized to delete this stream', 'danger')
        return redirect(url_for('stream.list_streams'))
    
    # Don't allow deletion of live streams
    if stream.is_live:
        flash('Cannot delete a live stream. End the stream first.', 'danger')
        return redirect(url_for('stream.list_streams') if not current_user.is_admin else url_for('admin.stream_list'))
    
    # Delete associated comments
    Comment.query.filter_by(stream_id=stream_id).delete()
    
    # Delete stream
    db.session.delete(stream)
    db.session.commit()
    
    flash(f'Stream "{stream.title}" has been deleted.', 'success')
    
    # Redirect based on user role
    if current_user.is_admin:
        return redirect(url_for('admin.stream_list'))
    else:
        return redirect(url_for('studio.stream_list'))

@stream_bp.route('/stream/<int:stream_id>/stream_info', methods=['GET'])
@login_required
def stream_info(stream_id):
    """Get streaming information for OBS/XSplit integration"""
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner
    if current_user.id != stream.user_id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        # Get streaming URLs from configuration
        rtmp_url = get_rtmp_url(stream.stream_key)
        hls_url = get_hls_url(stream.stream_key)
        dash_url = get_dash_url(stream.stream_key)
        
        stream_info = get_stream_info(stream.stream_key)
        stream_info['success'] = True
        
        return jsonify(stream_info)
    except Exception as e:
        return jsonify({
            'success': False, 
            'message': f'Error retrieving stream information: {str(e)}'
        }), 500

@stream_bp.route('/stream/<int:stream_id>/formats', methods=['POST'])
@login_required
def update_stream_formats(stream_id):
    """Update the enabled streaming formats for this stream"""
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner
    if current_user.id != stream.user_id:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403
    
    try:
        data = request.json
        
        # In a production environment, you would update the configuration
        # in nginx or other streaming server to enable/disable formats
        # For now, we just log the changes
        formats = {
            'hls': data.get('hls', True),
            'dash': data.get('dash', True),
            'webrtc': data.get('webrtc', True)
        }
        
        # Update the stream record with enabled formats (stored as JSON string)
        # This would require adding a formats column to the Stream model
        # stream.formats = json.dumps(formats)
        # db.session.commit()
        
        # Log the formats change
        current_app.logger.info(f"Stream {stream_id} formats updated: {formats}")
        
        return jsonify({
            'success': True,
            'message': 'Stream formats updated successfully'
        })
    except Exception as e:
        return jsonify({
            'success': False, 
            'message': f'Error updating stream formats: {str(e)}'
        }), 500

@stream_bp.route('/stream/<int:stream_id>/viewers', methods=['GET'])
def get_viewer_count(stream_id):
    """Get the current viewer count for a stream"""
    stream = Stream.query.get_or_404(stream_id)
    
    # Return the current viewer count
    return jsonify({
        'success': True,
        'count': stream.viewers
    })

@stream_bp.route('/stream/<int:stream_id>/embed', methods=['GET'])
def embed_stream(stream_id):
    """Render the embedded stream view for WebRTC/HLS/DASH playback"""
    stream = Stream.query.get_or_404(stream_id)
    
    # Get comprehensive stream info with protocol availability
    stream_info = get_stream_info(stream.stream_key)
    
    # Get individual URLs for each protocol
    rtmp_url = stream_info['rtmp_url']
    hls_url = stream_info['hls_url']
    dash_url = stream_info['dash_url']
    
    # Get TURN server settings from config
    turn_config = {
        'server': current_app.config.get('TURN_SERVER'),
        'username': current_app.config.get('TURN_USERNAME'),
        'credential': current_app.config.get('TURN_PASSWORD')
    }
    
    # Get domain name for branding
    domain_name = current_app.config.get('DOMAIN_NAME', 'streamvibe.biz')
    
    # Pass stream info to the embedded player template
    return render_template('embed/player.html', 
                          stream=stream,
                          rtmp_url=rtmp_url,
                          hls_url=hls_url,
                          dash_url=dash_url,
                          turn_config=turn_config,
                          stream_info=stream_info,
                          domain_name=domain_name,
                          embedded=True)

@stream_bp.route('/api/stream/health-check', methods=['GET'])
def health_check_endpoint():
    """API endpoint to check the health of the streaming infrastructure"""
    try:
        # Check NGINX status
        nginx_status = check_nginx_status()
        
        return jsonify({
            'success': True,
            'status': nginx_status,
            'timestamp': datetime.utcnow().isoformat()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@stream_bp.route('/api/stream/check/<stream_key>', methods=['GET'])
def check_stream_status(stream_key):
    """API endpoint to check if a specific stream is active"""
    try:
        is_active = check_stream_active(stream_key)
        
        return jsonify({
            'success': True,
            'stream_key': stream_key,
            'is_active': is_active,
            'timestamp': datetime.utcnow().isoformat()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'stream_key': stream_key,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@stream_bp.route('/api/stream/restart/<stream_key>', methods=['POST'])
@login_required
def restart_stream_endpoint(stream_key):
    """API endpoint to restart a crashed or stalled stream"""
    # Find the stream by stream_key
    stream = Stream.query.filter_by(stream_key=stream_key).first_or_404()
    
    # Check if current user is the owner or admin
    if current_user.id != stream.user_id and not current_user.is_admin:
        return jsonify({
            'success': False,
            'message': 'Unauthorized: You do not have permission to restart this stream'
        }), 403
    
    try:
        # Check if stream is marked as live in the database
        if not stream.is_live:
            return jsonify({
                'success': False,
                'message': 'Stream is not currently live'
            }), 400
        
        # Attempt to restart the stream
        success = restart_stream(stream_key)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Stream successfully restarted',
                'stream_key': stream_key,
                'timestamp': datetime.utcnow().isoformat()
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Failed to restart stream',
                'stream_key': stream_key,
                'timestamp': datetime.utcnow().isoformat()
            }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'stream_key': stream_key,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }), 500

@stream_bp.route('/api/stream/auth', methods=['POST'])
def auth_rtmp_stream():
    """
    Authentication endpoint for NGINX RTMP module
    
    NGINX RTMP module calls this endpoint when a broadcaster tries to publish a stream.
    It should verify the stream key is valid and return HTTP 200 for success,
    or any other HTTP code to deny the stream.
    """
    try:
        stream_key = request.form.get('name')
        
        if not stream_key:
            current_app.logger.warning("RTMP auth attempt with no stream key")
            return "Stream key required", 400
            
        # Find the stream by stream_key
        stream = Stream.query.filter_by(stream_key=stream_key).first()
        
        if not stream:
            current_app.logger.warning(f"RTMP auth attempt with invalid stream key: {stream_key}")
            return "Invalid stream key", 404
            
        # Mark the stream as live in the database
        if not stream.is_live:
            stream.is_live = True
            stream.started_at = datetime.utcnow()
            db.session.commit()
            current_app.logger.info(f"Stream {stream_key} is now live via RTMP")
            
        return "OK", 200
    except Exception as e:
        current_app.logger.error(f"Error in RTMP auth: {str(e)}")
        return str(e), 500

@stream_bp.route('/api/stream/done', methods=['POST'])
def done_rtmp_stream():
    """
    Callback endpoint for NGINX RTMP module when publishing stops
    
    NGINX RTMP module calls this endpoint when a broadcaster stops publishing
    """
    try:
        stream_key = request.form.get('name')
        
        if not stream_key:
            current_app.logger.warning("RTMP done callback with no stream key")
            return "Stream key required", 400
            
        # Find the stream by stream_key
        stream = Stream.query.filter_by(stream_key=stream_key).first()
        
        if not stream:
            current_app.logger.warning(f"RTMP done callback with invalid stream key: {stream_key}")
            return "Invalid stream key", 404
            
        # Mark the stream as no longer live in the database
        if stream.is_live:
            stream.is_live = False
            stream.ended_at = datetime.utcnow()
            db.session.commit()
            current_app.logger.info(f"Stream {stream_key} ended via RTMP")
            
        return "OK", 200
    except Exception as e:
        current_app.logger.error(f"Error in RTMP done callback: {str(e)}")
        return str(e), 500
