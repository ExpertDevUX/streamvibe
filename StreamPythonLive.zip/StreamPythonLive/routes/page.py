from flask import Blueprint, render_template

# Blueprint for static pages
page_bp = Blueprint('page', __name__, url_prefix='/page')

@page_bp.route('/help-center')
def help_center():
    """Help Center page"""
    return render_template('pages/help_center.html')

@page_bp.route('/creator-academy')
def creator_academy():
    """Creator Academy page"""
    return render_template('pages/creator_academy.html')

@page_bp.route('/community')
def community():
    """Community page"""
    return render_template('pages/community.html')

@page_bp.route('/monetization')
def monetization():
    """Monetization page"""
    return render_template('pages/monetization.html')

@page_bp.route('/terms')
def terms():
    """Terms of Service page"""
    return render_template('pages/terms.html')

@page_bp.route('/privacy')
def privacy():
    """Privacy Policy page"""
    return render_template('pages/privacy.html')

@page_bp.route('/cookies')
def cookies():
    """Cookie Policy page"""
    return render_template('pages/cookies.html')