from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_required, current_user
from functools import wraps
from app import db
from models import User, Media, Stream, Comment, Analytics
from sqlalchemy import func, desc
import datetime

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# Admin required decorator
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('media.index'))
        return f(*args, **kwargs)
    return decorated_function

# Admin dashboard
@admin_bp.route('/')
@login_required
@admin_required
def dashboard():
    # Count of users, media, and streams
    users_count = User.query.count()
    media_count = Media.query.count()
    streams_count = Stream.query.count()
    comment_count = Comment.query.count()
    
    # Recent users
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    
    # Recent media
    recent_media = Media.query.order_by(Media.created_at.desc()).limit(5).all()
    
    # Active streams
    active_streams = Stream.query.filter_by(is_live=True).all()
    active_streams_count = len(active_streams)
    
    # System stats (simulated data for demonstration)
    storage_total = 100  # GB
    storage_used = 25    # GB
    storage_percent = int((storage_used / storage_total) * 100)
    
    cpu_cores = 4
    cpu_percent = 35
    
    memory_total = 16  # GB
    memory_used = 8    # GB
    memory_percent = int((memory_used / memory_total) * 100)
    
    uptime_days = 15
    uptime_hours = 7
    uptime_minutes = 42
    last_restart = "March 28, 2025 at 15:32"
    
    return render_template('admin/dashboard.html', 
                          users_count=users_count,
                          media_count=media_count,
                          streams_count=streams_count,
                          comment_count=comment_count,
                          recent_users=recent_users,
                          recent_media=recent_media,
                          active_streams=active_streams,
                          active_streams_count=active_streams_count,
                          storage_total=storage_total,
                          storage_used=storage_used,
                          storage_percent=storage_percent,
                          cpu_cores=cpu_cores,
                          cpu_percent=cpu_percent,
                          memory_total=memory_total,
                          memory_used=memory_used,
                          memory_percent=memory_percent,
                          uptime_days=uptime_days,
                          uptime_hours=uptime_hours,
                          uptime_minutes=uptime_minutes,
                          last_restart=last_restart)

# User management
@admin_bp.route('/users')
@login_required
@admin_required
def user_list():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    users = User.query.order_by(User.username).paginate(page=page, per_page=per_page)
    return render_template('admin/user_list.html', users=users)

@admin_bp.route('/users/<int:user_id>')
@login_required
@admin_required
def user_detail(user_id):
    user = User.query.get_or_404(user_id)
    
    # User's media and streams
    media = Media.query.filter_by(user_id=user_id).order_by(Media.created_at.desc()).all()
    streams = Stream.query.filter_by(user_id=user_id).order_by(Stream.created_at.desc()).all()
    
    # User stats
    total_views = db.session.query(func.sum(Media.views)).filter(Media.user_id == user_id).scalar() or 0
    
    return render_template('admin/user_detail.html', 
                          user=user, 
                          media=media, 
                          streams=streams,
                          total_views=total_views)

@admin_bp.route('/users/<int:user_id>/toggle-admin', methods=['POST'])
@login_required
@admin_required
def toggle_admin(user_id):
    user = User.query.get_or_404(user_id)
    
    # Prevent self-demotion
    if user.id == current_user.id:
        flash('You cannot change your own admin status.', 'danger')
        return redirect(url_for('admin.user_detail', user_id=user_id))
    
    user.is_admin = not user.is_admin
    db.session.commit()
    
    if user.is_admin:
        flash(f'User {user.username} is now an admin.', 'success')
    else:
        flash(f'User {user.username} is no longer an admin.', 'warning')
    
    return redirect(url_for('admin.user_detail', user_id=user_id))

# Media management
@admin_bp.route('/media')
@login_required
@admin_required
def media_list():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    media = Media.query.order_by(Media.created_at.desc()).paginate(page=page, per_page=per_page)
    return render_template('admin/media_list.html', media=media)

@admin_bp.route('/media/<int:media_id>')
@login_required
@admin_required
def media_detail(media_id):
    media = Media.query.get_or_404(media_id)
    comments = Comment.query.filter_by(media_id=media_id).order_by(Comment.created_at.desc()).all()
    return render_template('admin/media_detail.html', media=media, comments=comments)

@admin_bp.route('/media/<int:media_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_media(media_id):
    media = Media.query.get_or_404(media_id)
    
    # Delete associated comments
    Comment.query.filter_by(media_id=media_id).delete()
    
    # Delete analytics
    Analytics.query.filter_by(media_id=media_id).delete()
    
    # Delete media
    db.session.delete(media)
    db.session.commit()
    
    flash(f'Media "{media.title}" has been deleted.', 'success')
    return redirect(url_for('admin.media_list'))

# Stream management
@admin_bp.route('/streams')
@login_required
@admin_required
def stream_list():
    page = request.args.get('page', 1, type=int)
    per_page = 20
    streams = Stream.query.order_by(Stream.created_at.desc()).paginate(page=page, per_page=per_page)
    return render_template('admin/stream_list.html', streams=streams)

@admin_bp.route('/streams/<int:stream_id>')
@login_required
@admin_required
def stream_detail(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    comments = Comment.query.filter_by(stream_id=stream_id).order_by(Comment.created_at.desc()).all()
    return render_template('admin/stream_detail.html', stream=stream, comments=comments)

@admin_bp.route('/streams/<int:stream_id>/end', methods=['POST'])
@login_required
@admin_required
def end_stream_admin(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    if stream.is_live:
        stream.is_live = False
        stream.ended_at = datetime.datetime.utcnow()
        db.session.commit()
        flash(f'Stream "{stream.title}" has been ended.', 'success')
    else:
        flash(f'Stream is not currently live.', 'warning')
    
    return redirect(url_for('admin.stream_detail', stream_id=stream_id))

@admin_bp.route('/streams/<int:stream_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_stream(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Don't allow deletion of live streams
    if stream.is_live:
        flash('Cannot delete a live stream. End the stream first.', 'danger')
        return redirect(url_for('admin.stream_list'))
    
    # Delete associated comments
    Comment.query.filter_by(stream_id=stream_id).delete()
    
    # Delete analytics
    Analytics.query.filter_by(stream_id=stream_id).delete()
    
    # Delete stream
    title = stream.title
    db.session.delete(stream)
    db.session.commit()
    
    flash(f'Stream "{title}" has been deleted.', 'success')
    return redirect(url_for('admin.stream_list'))

# Comment management
@admin_bp.route('/comments/<int:comment_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_comment(comment_id):
    comment = Comment.query.get_or_404(comment_id)
    
    # Store the IDs before deleting
    media_id = comment.media_id
    stream_id = comment.stream_id
    
    # Delete the comment
    db.session.delete(comment)
    db.session.commit()
    
    flash('Comment deleted successfully', 'success')
    
    # Redirect to the appropriate page
    if media_id and request.form.get('media_id'):
        return redirect(url_for('admin.media_detail', media_id=media_id))
    elif stream_id and request.form.get('stream_id'):
        return redirect(url_for('admin.stream_detail', stream_id=stream_id))
    else:
        return redirect(url_for('admin.dashboard'))

# System stats
@admin_bp.route('/stats')
@login_required
@admin_required
def system_stats():
    # User stats
    total_users = User.query.count()
    users_today = User.query.filter(User.created_at >= datetime.datetime.utcnow().date()).count()
    
    # Media stats
    total_media = Media.query.count()
    media_today = Media.query.filter(Media.created_at >= datetime.datetime.utcnow().date()).count()
    total_views = db.session.query(func.sum(Media.views)).scalar() or 0
    
    # Stream stats
    total_streams = Stream.query.count()
    active_streams = Stream.query.filter_by(is_live=True).count()
    
    # Comment stats
    total_comments = Comment.query.count()
    comments_today = Comment.query.filter(Comment.created_at >= datetime.datetime.utcnow().date()).count()
    
    return render_template('admin/stats.html',
                          total_users=total_users,
                          users_today=users_today,
                          total_media=total_media,
                          media_today=media_today,
                          total_views=total_views,
                          total_streams=total_streams,
                          active_streams=active_streams,
                          total_comments=total_comments,
                          comments_today=comments_today)