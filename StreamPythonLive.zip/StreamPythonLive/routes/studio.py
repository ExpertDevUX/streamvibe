from flask import Blueprint, render_template, redirect, url_for, request, flash, current_app
from flask_login import login_required, current_user
from sqlalchemy import desc
from app import db
from models import Media, Stream, User
import os
import uuid
from datetime import datetime
from werkzeug.utils import secure_filename

studio_bp = Blueprint('studio', __name__, url_prefix='/studio')

@studio_bp.route('/')
@login_required
def dashboard():
    """Studio dashboard with overview of user's content"""
    # Get user's media
    recent_media = Media.query.filter_by(user_id=current_user.id).order_by(Media.created_at.desc()).limit(5).all()
    media_count = Media.query.filter_by(user_id=current_user.id).count()
    
    # Get user's streams
    recent_streams = Stream.query.filter_by(user_id=current_user.id).order_by(Stream.created_at.desc()).limit(5).all()
    stream_count = Stream.query.filter_by(user_id=current_user.id).count()
    
    # Get active stream if any
    active_stream = Stream.query.filter_by(user_id=current_user.id, is_live=True).first()
    
    # Get total views
    total_media_views = sum([media.views for media in Media.query.filter_by(user_id=current_user.id).all()])
    
    return render_template('studio/dashboard.html',
                          recent_media=recent_media,
                          media_count=media_count,
                          recent_streams=recent_streams,
                          stream_count=stream_count,
                          active_stream=active_stream,
                          total_media_views=total_media_views)

@studio_bp.route('/media')
@login_required
def media_list():
    """List all user's uploaded media with management options"""
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    media = Media.query.filter_by(user_id=current_user.id).order_by(
        Media.created_at.desc()
    ).paginate(page=page, per_page=per_page)
    
    return render_template('studio/media_list.html', media=media)

@studio_bp.route('/streams')
@login_required
def stream_list():
    """List all user's streams with management options"""
    page = request.args.get('page', 1, type=int)
    per_page = 10
    
    streams = Stream.query.filter_by(user_id=current_user.id).order_by(
        Stream.created_at.desc()
    ).paginate(page=page, per_page=per_page)
    
    return render_template('studio/stream_list.html', streams=streams)

@studio_bp.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    """Upload new media files"""
    if request.method == 'POST':
        # Check if file was uploaded
        if 'file' not in request.files:
            flash('No file selected', 'danger')
            return redirect(request.url)
        
        file = request.files['file']
        
        # Check if file name is empty
        if file.filename == '':
            flash('No file selected', 'danger')
            return redirect(request.url)
        
        # Check file type
        allowed_extensions = {'mp4', 'webm', 'mov', 'avi', 'mp3', 'wav', 'ogg'}
        file_ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        
        if file_ext not in allowed_extensions:
            flash(f'File type not allowed. Allowed types: {", ".join(allowed_extensions)}', 'danger')
            return redirect(request.url)
        
        # Determine media type
        if file_ext in ['mp4', 'webm', 'mov', 'avi']:
            media_type = 'video'
        else:
            media_type = 'audio'
        
        # Create unique filename
        unique_filename = f"{uuid.uuid4().hex}.{file_ext}"
        
        # Get the upload folder from config
        upload_folder = current_app.config['UPLOAD_FOLDER']
        
        # Create user directory if it doesn't exist
        user_dir = os.path.join(upload_folder, str(current_user.id))
        if not os.path.exists(user_dir):
            os.makedirs(user_dir)
        
        # Create year/month directory
        now = datetime.utcnow()
        date_dir = os.path.join(user_dir, f"{now.year}/{now.month:02d}")
        if not os.path.exists(date_dir):
            os.makedirs(date_dir)
        
        # Save file
        file_path = os.path.join(date_dir, unique_filename)
        file.save(file_path)
        
        # Get relative path for storage in database
        relative_path = os.path.join(str(current_user.id), f"{now.year}/{now.month:02d}", unique_filename)
        
        # Create media record
        new_media = Media(
            title=request.form.get('title'),
            description=request.form.get('description'),
            file_path=relative_path,
            media_type=media_type,
            tags=request.form.get('tags'),
            user_id=current_user.id
        )
        
        # Save to database
        db.session.add(new_media)
        db.session.commit()
        
        flash('Media uploaded successfully', 'success')
        return redirect(url_for('studio.media_list'))
    
    return render_template('studio/upload.html')

@studio_bp.route('/create-stream', methods=['GET', 'POST'])
@login_required
def create_stream():
    """Create a new stream"""
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        is_public = request.form.get('is_public', 'on') == 'on'
        tags = request.form.get('tags')
        
        # Generate a unique stream key
        stream_key = str(uuid.uuid4())
        
        # Create new stream
        new_stream = Stream(
            title=title,
            description=description,
            stream_key=stream_key,
            is_public=is_public,
            tags=tags,
            user_id=current_user.id
        )
        
        db.session.add(new_stream)
        db.session.commit()
        
        flash('Stream created successfully! You can now start streaming.', 'success')
        return redirect(url_for('studio.broadcaster', stream_id=new_stream.id))
    
    return render_template('studio/create_stream.html')

@studio_bp.route('/stream/<int:stream_id>/broadcast')
@login_required
def broadcaster(stream_id):
    """Broadcaster view for streaming"""
    stream = Stream.query.get_or_404(stream_id)
    
    # Check if current user is the owner
    if current_user.id != stream.user_id:
        flash('You are not authorized to broadcast this stream', 'danger')
        return redirect(url_for('studio.dashboard'))
    
    # Get TURN server settings from config
    turn_config = {
        'server': current_app.config.get('TURN_SERVER', ''),
        'username': current_app.config.get('TURN_USERNAME', ''),
        'credential': current_app.config.get('TURN_PASSWORD', '')
    }
    
    return render_template('studio/broadcaster.html', 
                          stream=stream, 
                          turn_config=turn_config)

@studio_bp.route('/analytics')
@login_required
def analytics():
    """Display analytics for user's content"""
    from datetime import datetime, timedelta
    
    # Get user's media
    user_media = Media.query.filter_by(user_id=current_user.id).order_by(Media.views.desc()).all()
    
    # Get user's streams
    user_streams = Stream.query.filter_by(user_id=current_user.id).order_by(Stream.viewers.desc()).all()
    
    # Calculate totals for overview metrics
    total_views = sum(media.views for media in user_media)
    total_viewers = sum(stream.viewers for stream in user_streams)
    
    # Total unique viewers (this is an estimation without real analytics data)
    unique_viewers = int(total_views * 0.7) + total_viewers  # Assume 70% of views are unique
    
    # Estimate watch hours (dummy calculation)
    # Assume 2.5 minutes average watch time per video view
    # Assume 5 minutes average watch time per stream viewer
    video_watch_hours = (sum(media.views for media in user_media) * 2.5) / 60
    stream_watch_hours = (sum(stream.viewers for stream in user_streams) * 5) / 60
    watch_hours = int(video_watch_hours + stream_watch_hours)
    
    # Growth percentage (dummy value)
    growth_percentage = 12
    
    # Add helper for templates
    now = datetime.utcnow()
    def days(n):
        return timedelta(days=n)
    
    return render_template('studio/analytics.html', 
                          user_media=user_media,
                          user_streams=user_streams,
                          total_views=total_views,
                          unique_viewers=unique_viewers,
                          watch_hours=watch_hours,
                          growth_percentage=growth_percentage,
                          now=now,
                          days=days)

@studio_bp.route('/media/<int:media_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_media(media_id):
    """Edit media details"""
    media = Media.query.get_or_404(media_id)
    
    # Check if current user is the owner
    if current_user.id != media.user_id:
        flash('You are not authorized to edit this media', 'danger')
        return redirect(url_for('studio.media_list'))
    
    if request.method == 'POST':
        # Update media details
        media.title = request.form.get('title')
        media.description = request.form.get('description')
        media.tags = request.form.get('tags')
        
        db.session.commit()
        
        flash('Media updated successfully', 'success')
        return redirect(url_for('studio.media_list'))
    
    return render_template('studio/edit_media.html', media=media)

@studio_bp.route('/settings')
@login_required
def settings():
    """Studio settings"""
    return render_template('studio/settings.html', user=current_user)