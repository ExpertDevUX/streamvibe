#!/bin/bash
# StreamVibe Installer Launcher
# This script launches the StreamVibe installer

# Colors for better readability
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo -e "${RED}[ERROR]${NC} This script must be run as root. Please use sudo or run as root."
    exit 1
fi

# Path to the installer
INSTALLER_PATH="./install/auto_install.sh"

# Make sure the installer is executable
chmod +x "$INSTALLER_PATH"

# Welcome message
clear
echo "================================================================="
echo "                  StreamVibe Installer Launcher                  "
echo "================================================================="
echo
echo -e "${BLUE}Welcome to the StreamVibe installer!${NC}"
echo
echo "This script will help you install StreamVibe on your server."
echo "The installation will set up all required components, including:"
echo
echo "  • NGINX with RTMP module for streaming"
echo "  • PostgreSQL database"
echo "  • Python environment for StreamVibe"
echo "  • SSL certificates (optional)"
echo "  • Firewall configuration"
echo

# Check which installation method to use
echo "Please select your preferred installation method:"
echo
echo "1. Web Dashboard Installation (recommended)"
echo "   - User-friendly web interface"
echo "   - Real-time progress tracking"
echo "   - Easy configuration"
echo
echo "2. Command Line Installation"
echo "   - Faster installation"
echo "   - Suitable for servers without a GUI"
echo "   - Minimal interaction required"
echo
echo "3. Exit"
echo

read -p "Select an option (1-3): " install_option

case $install_option in
    1)
        # Launch the web dashboard installer
        echo -e "${BLUE}[INFO]${NC} Starting web dashboard installation..."
        "$INSTALLER_PATH" 1
        ;;
    2)
        # Launch the command line installer
        echo -e "${BLUE}[INFO]${NC} Starting command line installation..."
        "$INSTALLER_PATH" 2
        ;;
    3)
        # Exit
        echo -e "${YELLOW}Installation cancelled.${NC}"
        exit 0
        ;;
    *)
        # Invalid option
        echo -e "${RED}[ERROR]${NC} Invalid option. Please select 1, 2, or 3."
        exit 1
        ;;
esac