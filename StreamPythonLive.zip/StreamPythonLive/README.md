# StreamVibe - Media Streaming Platform

StreamVibe is a powerful, Python-based media streaming platform that leverages Flask and WebRTC for high-performance live content delivery and interactive broadcasting experiences.

## Features

- **Live Streaming**: Stream in real-time with support for RTMP, HLS, and DASH protocols
- **Media Management**: Upload, manage, and share videos and audio content
- **User Profiles**: Personalized user accounts and profile customization
- **Studio Interface**: Professional tools for content creators
- **Analytics**: Comprehensive performance tracking and audience insights
- **Admin Dashboard**: Complete control over users, content, and platform settings
- **Responsive Design**: Works on desktop, tablet, and mobile devices

## Quick Installation

For a streamlined installation experience, use our auto-installer script:

```bash
# Clone the repository
git clone https://github.com/yourusername/streamvibe.git
cd streamvibe

# Make the installer executable
chmod +x install.sh

# Run the installer
sudo ./install.sh
```

The installer provides two methods:

1. **Web Dashboard Installation** (recommended): User-friendly web interface with real-time progress tracking
2. **Command Line Installation**: Faster installation suitable for servers without a GUI

## Manual Installation

For detailed installation instructions, refer to our documentation:

- [Complete Installation Guide](docs/installation_guide.md)
- [RTMP Module Setup Guide](docs/rtmp_setup_guide.md)
- [Deployment Checklist](docs/deployment_checklist.md)

## System Requirements

- **Operating System**: Ubuntu 20.04 LTS or CentOS 8 (recommended)
- **RAM**: Minimum 2GB (4GB recommended)
- **Storage**: 20GB+ free space
- **CPU**: 2+ cores recommended
- **Software**: Python 3.8+, PostgreSQL 12+, NGINX with RTMP module, FFmpeg

## Architecture

StreamVibe uses a modern, scalable architecture:

- **Backend**: Flask web framework with SQLAlchemy ORM
- **Database**: PostgreSQL for reliable data storage
- **Streaming**: NGINX with RTMP module, supporting HLS and DASH
- **Frontend**: Responsive Bootstrap-based UI with custom components
- **Media Processing**: FFmpeg for encoding and thumbnail generation

## Documentation

Comprehensive documentation is available in the `docs` directory:

- [User Guide](docs/user_guide.md)
- [Administrator Guide](docs/admin_guide.md)
- [Developer Guide](docs/developer_guide.md)
- [API Reference](docs/api_reference.md)

## Configuration Options

StreamVibe is highly configurable. Key settings are stored in the `.env` file and include:

- Database connection parameters
- Domain and streaming URLs
- Session security settings
- Media storage paths

## Contributing

We welcome contributions! Please see our [Contributing Guidelines](CONTRIBUTING.md) for details.

## License

StreamVibe is licensed under the [MIT License](LICENSE).