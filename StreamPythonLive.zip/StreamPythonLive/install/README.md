# StreamVibe Installation Tools

This directory contains tools for installing StreamVibe on your server.

## Quick Start

If you want to set up StreamVibe quickly with a web-based dashboard:

1. Log in to your server as root or a user with sudo privileges
2. Download the installation files to your server
3. Make the installer executable: `chmod +x auto_install.sh`
4. Run the installer: `sudo ./auto_install.sh`
5. Select option 1 for the web-based dashboard
6. Open the provided URL in your browser to continue installation

## Installation Methods

### 1. Web Dashboard Installation (Recommended)

The web dashboard provides a user-friendly interface for installing StreamVibe:

- Configure all settings through a web interface
- Real-time installation progress tracking
- Comprehensive setup with all required components

To start the web dashboard:

```bash
sudo ./auto_install.sh
# Select option 1
```

### 2. Command Line Installation

For advanced users or servers without a GUI:

```bash
sudo ./auto_install.sh
# Select option 2
```

Alternatively, you can run the installer directly in command line mode:

```bash
sudo ./auto_install.sh 2
```

### 3. Step-by-Step Manual Installation

If you prefer to run each installation step individually:

```bash
# 1. Check system requirements
sudo ./auto_install.sh check_system

# 2. Install dependencies
sudo ./auto_install.sh install_dependencies

# 3. Set up PostgreSQL database
sudo ./auto_install.sh setup_database

# 4. Configure NGINX with RTMP
sudo ./auto_install.sh configure_nginx_rtmp

# 5. Install StreamVibe application
sudo ./auto_install.sh setup_streamvibe

# 6. Set up SSL certificates
sudo ./auto_install.sh setup_ssl

# 7. Finalize installation
sudo ./auto_install.sh finalize_installation
```

## Customization Options

You can customize the installation by setting parameters:

```bash
sudo ./auto_install.sh --domain-name=yourdomain.com --install-dir=/path/to/install
```

Available parameters:

- `--domain-name`: Domain name for the StreamVibe instance
- `--install-dir`: Directory to install StreamVibe
- `--db-name`: PostgreSQL database name
- `--db-user`: PostgreSQL database user
- `--db-pass`: PostgreSQL database password
- `--admin-user`: StreamVibe admin username
- `--admin-email`: StreamVibe admin email
- `--admin-pass`: StreamVibe admin password
- `--dashboard-port`: Port for the web installation dashboard

## Post-Installation

After installation completes:

1. Log in to your StreamVibe admin account
2. Change the default admin password
3. Configure your site settings
4. Start uploading content or streaming!

## Troubleshooting

If you encounter issues during installation:

- Check the installation logs
- Verify your system meets all requirements
- Ensure your domain is correctly configured in DNS
- Make sure all ports (80, 443, 1935) are open

For detailed troubleshooting, refer to the documentation in the `docs` directory:
- [Installation Guide](../docs/installation_guide.md)
- [RTMP Setup Guide](../docs/rtmp_setup_guide.md)
- [Deployment Checklist](../docs/deployment_checklist.md)