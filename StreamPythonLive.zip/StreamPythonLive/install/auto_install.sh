#!/bin/bash
# StreamVibe Auto Installer Script
# This script automates the installation of StreamVibe and all its dependencies
# It also creates a simple web dashboard for managing the installation process

# Set default options
DOMAIN_NAME="streamvibe.biz"
INSTALL_DIR="/var/www/streamvibe"
DB_NAME="streamvibe"
DB_USER="streamvibe_user"
DB_PASS=$(openssl rand -base64 12)
SESSION_SECRET=$(openssl rand -base64 32)
ADMIN_USER="admin"
ADMIN_PASS=$(openssl rand -base64 8)
ADMIN_EMAIL="admin@streamvibe.biz"
DASHBOARD_PORT=8585

# Colors for better readability
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to display status messages
function status_message() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Function to display success messages
function success_message() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to display warning messages
function warning_message() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Function to display error messages
function error_message() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if running as root
function check_root() {
    if [ "$EUID" -ne 0 ]; then
        error_message "This script must be run as root. Please use sudo or run as root."
        exit 1
    fi
}

# Function to detect OS
function detect_os() {
    status_message "Detecting operating system..."
    
    if [ -f /etc/lsb-release ]; then
        . /etc/lsb-release
        OS=$DISTRIB_ID
        VER=$DISTRIB_RELEASE
    elif [ -f /etc/debian_version ]; then
        OS=Debian
        VER=$(cat /etc/debian_version)
    elif [ -f /etc/centos-release ]; then
        OS=CentOS
        VER=$(cat /etc/centos-release | sed 's/^.*release //' | sed 's/ .*$//')
    else
        OS=$(uname -s)
        VER=$(uname -r)
    fi
    
    # Convert to lowercase
    OS=$(echo "$OS" | tr '[:upper:]' '[:lower:]')
    
    success_message "Detected: $OS $VER"
}

# Function to install dependencies based on OS
function install_dependencies() {
    status_message "Installing required dependencies..."
    
    case $OS in
        ubuntu|debian)
            apt-get update
            apt-get install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib \
                              ffmpeg build-essential libssl-dev libffi-dev python3-dev \
                              curl wget git unzip libnginx-mod-rtmp certbot python3-certbot-nginx
            ;;
        centos|rhel|fedora)
            yum -y update
            yum -y install epel-release
            yum -y install python3 python3-pip nginx postgresql postgresql-server postgresql-contrib \
                          ffmpeg gcc gcc-c++ make openssl-devel libffi-devel python3-devel \
                          curl wget git unzip certbot
            # RTMP module on CentOS needs to be compiled manually
            status_message "RTMP module will be compiled later..."
            ;;
        *)
            error_message "Unsupported operating system: $OS"
            exit 1
            ;;
    esac
    
    success_message "Dependencies installed successfully"
}

# Function to set up PostgreSQL
function setup_database() {
    status_message "Setting up PostgreSQL database..."
    
    case $OS in
        ubuntu|debian)
            service postgresql start
            ;;
        centos|rhel|fedora)
            # Initialize PostgreSQL database
            postgresql-setup --initdb
            systemctl start postgresql
            ;;
    esac
    
    # Create database and user
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';"
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
    
    success_message "PostgreSQL database '$DB_NAME' and user '$DB_USER' created successfully"
}

# Function to configure NGINX with RTMP
function configure_nginx_rtmp() {
    status_message "Configuring NGINX with RTMP module..."
    
    case $OS in
        ubuntu|debian)
            # RTMP module is already installed via libnginx-mod-rtmp
            ;;
        centos|rhel|fedora)
            # Compile NGINX with RTMP module
            cd /tmp
            yum -y install pcre-devel zlib-devel
            wget https://nginx.org/download/nginx-1.20.1.tar.gz
            wget https://github.com/arut/nginx-rtmp-module/archive/master.zip
            unzip master.zip
            tar -zxvf nginx-1.20.1.tar.gz
            cd nginx-1.20.1
            ./configure --prefix=/usr/share/nginx --sbin-path=/usr/sbin/nginx --modules-path=/usr/lib64/nginx/modules \
                       --conf-path=/etc/nginx/nginx.conf --error-log-path=/var/log/nginx/error.log \
                       --http-log-path=/var/log/nginx/access.log --pid-path=/var/run/nginx.pid \
                       --lock-path=/var/run/nginx.lock --with-http_ssl_module --with-http_v2_module \
                       --with-http_realip_module --add-module=../nginx-rtmp-module-master
            make
            make install
            ;;
    esac
    
    # Create HLS and DASH directories
    mkdir -p $INSTALL_DIR/hls $INSTALL_DIR/dash
    chown -R www-data:www-data $INSTALL_DIR/hls $INSTALL_DIR/dash 2>/dev/null || \
    chown -R nginx:nginx $INSTALL_DIR/hls $INSTALL_DIR/dash
    chmod -R 755 $INSTALL_DIR/hls $INSTALL_DIR/dash
    
    # Backup existing NGINX config
    if [ -f /etc/nginx/nginx.conf ]; then
        cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.bak
    fi
    
    # Create NGINX configuration with RTMP module
    cat > /etc/nginx/nginx.conf << EOF
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

# RTMP Configuration
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path $INSTALL_DIR/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path $INSTALL_DIR/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;
    
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
EOF
    
    # Create site configuration
    mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled
    
    cat > /etc/nginx/sites-available/streamvibe << EOF
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /static {
        alias $INSTALL_DIR/static;
        expires 30d;
    }

    location /uploads {
        alias $INSTALL_DIR/uploads;
        expires 30d;
    }
    
    location /hls {
        alias $INSTALL_DIR/hls;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
    }
    
    location /dash {
        alias $INSTALL_DIR/dash;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/dash+xml mpd;
        }
    }
}
EOF
    
    # Enable site
    ln -sf /etc/nginx/sites-available/streamvibe /etc/nginx/sites-enabled/
    
    # Test NGINX configuration
    nginx -t
    
    # Restart NGINX
    case $OS in
        ubuntu|debian)
            service nginx restart
            ;;
        centos|rhel|fedora)
            systemctl restart nginx
            ;;
    esac
    
    success_message "NGINX with RTMP module configured successfully"
}

# Function to set up StreamVibe application
function setup_streamvibe() {
    status_message "Setting up StreamVibe application..."
    
    # Create installation directory
    mkdir -p $INSTALL_DIR
    
    # Clone repository or download files
    git clone https://github.com/yourusername/streamvibe.git $INSTALL_DIR 2>/dev/null || \
    warning_message "Git repository not specified. Please upload StreamVibe files manually to $INSTALL_DIR"
    
    # Set permissions
    case $OS in
        ubuntu|debian)
            chown -R www-data:www-data $INSTALL_DIR
            ;;
        centos|rhel|fedora)
            chown -R nginx:nginx $INSTALL_DIR
            ;;
    esac
    
    # Create virtual environment
    cd $INSTALL_DIR
    python3 -m venv venv
    source venv/bin/activate
    
    # Install dependencies
    pip install --upgrade pip
    pip install flask flask-login flask-migrate flask-sqlalchemy flask-wtf gunicorn \
                psycopg2-binary python-dotenv requests sqlalchemy werkzeug email-validator
    
    # Create .env file
    cat > $INSTALL_DIR/.env << EOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
SESSION_SECRET=$SESSION_SECRET
STREAM_SERVER=$DOMAIN_NAME
DOMAIN_NAME=$DOMAIN_NAME
RTMP_SERVER=rtmp://$DOMAIN_NAME/live
HLS_SERVER=https://$DOMAIN_NAME/hls
DASH_SERVER=https://$DOMAIN_NAME/dash
EOF
    
    # Create systemd service file
    cat > /etc/systemd/system/streamvibe.service << EOF
[Unit]
Description=StreamVibe Gunicorn Service
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin"
EnvironmentFile=$INSTALL_DIR/.env
ExecStart=$INSTALL_DIR/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
Restart=always

[Install]
WantedBy=multi-user.target
EOF
    
    # Fix user for CentOS/RHEL
    if [[ "$OS" == "centos" || "$OS" == "rhel" || "$OS" == "fedora" ]]; then
        sed -i 's/User=www-data/User=nginx/g' /etc/systemd/system/streamvibe.service
        sed -i 's/Group=www-data/Group=nginx/g' /etc/systemd/system/streamvibe.service
    fi
    
    # Initialize database
    source $INSTALL_DIR/venv/bin/activate
    cd $INSTALL_DIR
    python -c "from app import db; db.create_all()"
    
    # Run database migrations
    if [ -f $INSTALL_DIR/run_analytics_migration.py ]; then
        python $INSTALL_DIR/run_analytics_migration.py
    fi
    
    # Create admin user
    python -c "import sys; sys.path.append('$INSTALL_DIR'); from create_admin import create_admin_account; create_admin_account('$ADMIN_USER', '$ADMIN_EMAIL', '$ADMIN_PASS')"
    
    # Enable and start service
    systemctl daemon-reload
    systemctl enable streamvibe
    systemctl start streamvibe
    
    success_message "StreamVibe application set up successfully"
    success_message "Admin account created:"
    success_message "  Username: $ADMIN_USER"
    success_message "  Email: $ADMIN_EMAIL"
    success_message "  Password: $ADMIN_PASS"
}

# Function to set up SSL with Let's Encrypt
function setup_ssl() {
    status_message "Setting up SSL with Let's Encrypt..."
    
    # Check if domain is accessible
    warning_message "Please ensure your domain '$DOMAIN_NAME' is correctly pointed to this server before proceeding with SSL setup."
    read -p "Is your domain properly configured? (y/n): " domain_configured
    
    if [[ "$domain_configured" != "y" && "$domain_configured" != "Y" ]]; then
        warning_message "SSL setup skipped. You can run 'certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME' later."
        return
    fi
    
    # Run certbot
    certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME
    
    success_message "SSL certificates installed successfully"
}

# Function to set up firewall
function setup_firewall() {
    status_message "Setting up firewall..."
    
    case $OS in
        ubuntu|debian)
            # Check if UFW is installed
            if command -v ufw >/dev/null 2>&1; then
                ufw allow 22/tcp
                ufw allow 80/tcp
                ufw allow 443/tcp
                ufw allow 1935/tcp
                
                # Enable UFW if not already enabled
                if ! ufw status | grep -q "Status: active"; then
                    read -p "Enable UFW firewall? This might disconnect your SSH session. (y/n): " enable_ufw
                    if [[ "$enable_ufw" == "y" || "$enable_ufw" == "Y" ]]; then
                        ufw enable
                    fi
                fi
                
                success_message "UFW firewall configured"
            else
                warning_message "UFW not installed. Skipping firewall configuration."
            fi
            ;;
        centos|rhel|fedora)
            # Check if firewalld is installed and running
            if command -v firewall-cmd >/dev/null 2>&1 && systemctl is-active --quiet firewalld; then
                firewall-cmd --permanent --add-service=ssh
                firewall-cmd --permanent --add-service=http
                firewall-cmd --permanent --add-service=https
                firewall-cmd --permanent --add-port=1935/tcp
                firewall-cmd --reload
                
                success_message "Firewalld configured"
            else
                warning_message "Firewalld not installed or not running. Skipping firewall configuration."
            fi
            ;;
    esac
}

# Function to create installation report
function create_report() {
    status_message "Creating installation report..."
    
    # Create report directory
    mkdir -p $INSTALL_DIR/install_report
    
    # Create report file
    cat > $INSTALL_DIR/install_report/installation_report.txt << EOF
StreamVibe Installation Report
=============================
Date: $(date)
Server: $(hostname -f)
Operating System: $OS $VER

Installation Details:
-------------------
Installation Directory: $INSTALL_DIR
Domain Name: $DOMAIN_NAME
Database Name: $DB_NAME
Database User: $DB_USER
Admin Username: $ADMIN_USER
Admin Email: $ADMIN_EMAIL

Services:
--------
StreamVibe Service: $(systemctl is-active streamvibe)
NGINX Service: $(systemctl is-active nginx)
PostgreSQL Service: $(systemctl is-active postgresql)

URLs:
----
Website: https://$DOMAIN_NAME
Admin Login: https://$DOMAIN_NAME/auth/login

RTMP Stream URL: rtmp://$DOMAIN_NAME/live
Stream Key: (Available in your StreamVibe dashboard)

HLS Playback URL: https://$DOMAIN_NAME/hls/{stream_key}.m3u8
DASH Playback URL: https://$DOMAIN_NAME/dash/{stream_key}.mpd

Next Steps:
----------
1. Log in to your StreamVibe admin account at https://$DOMAIN_NAME/auth/login
2. Update your admin password
3. Configure your desired settings
4. Start uploading content or streaming!

For questions or support, please refer to the documentation or contact support.
EOF
    
    success_message "Installation report created at $INSTALL_DIR/install_report/installation_report.txt"
}

# Function to setup the dashboard installer
function setup_dashboard() {
    status_message "Setting up installation dashboard..."
    
    # Create directory for dashboard
    mkdir -p $INSTALL_DIR/install_dashboard
    
    # Create dashboard HTML file
    cat > $INSTALL_DIR/install_dashboard/index.html << EOF
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StreamVibe Installer</title>
    <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #121212;
            color: #eee;
            font-family: 'Poppins', sans-serif;
        }
        .header {
            background: linear-gradient(135deg, #7662e7 0%, #6088f4 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 1rem 1rem;
        }
        .card {
            background-color: #1e1e1e;
            border: 1px solid #333;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
        }
        .card-header {
            background-color: #252525;
            border-bottom: 1px solid #333;
            padding: 1rem;
            border-radius: 0.5rem 0.5rem 0 0;
        }
        .card-body {
            padding: 1.5rem;
        }
        .progress-container {
            margin-bottom: 2rem;
        }
        .progress-step {
            display: flex;
            align-items: flex-start;
            margin-bottom: 1.5rem;
            position: relative;
        }
        .progress-step:before {
            content: '';
            position: absolute;
            left: 19px;
            top: 30px;
            bottom: -20px;
            width: 2px;
            background-color: #333;
        }
        .progress-step:last-child:before {
            display: none;
        }
        .progress-icon {
            width: 40px;
            height: 40px;
            background-color: #252525;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 1rem;
            border: 2px solid #333;
            position: relative;
            z-index: 1;
        }
        .progress-step.active .progress-icon {
            background-color: #7662e7;
            border-color: #7662e7;
        }
        .progress-step.completed .progress-icon {
            background-color: #198754;
            border-color: #198754;
        }
        .progress-content {
            flex: 1;
        }
        .console {
            background-color: #000;
            border-radius: 0.5rem;
            padding: 1rem;
            font-family: 'Courier New', monospace;
            height: 300px;
            overflow-y: auto;
            margin-bottom: 1rem;
        }
        .console-line {
            margin: 0;
            color: #0F0;
        }
        .alert-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 100;
        }
        .input-group-addon {
            background-color: #252525;
            color: #eee;
            border: 1px solid #444;
            border-right: none;
            border-radius: 0.25rem 0 0 0.25rem;
            padding: 0.375rem 0.75rem;
            display: flex;
            align-items: center;
        }
        .form-control {
            background-color: #333;
            border: 1px solid #444;
            color: #eee;
        }
        .form-control:focus {
            background-color: #3a3a3a;
            border-color: #7662e7;
            color: #fff;
        }
        .btn-primary {
            background-color: #7662e7;
            border-color: #7662e7;
        }
        .btn-primary:hover, .btn-primary:focus {
            background-color: #6088f4;
            border-color: #6088f4;
        }
        .btn-outline-primary {
            border-color: #7662e7;
            color: #7662e7;
        }
        .btn-outline-primary:hover, .btn-outline-primary:focus {
            background-color: #7662e7;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="header text-center">
        <h1><i class="fas fa-play-circle me-2"></i>StreamVibe Installer</h1>
        <p class="lead">Complete installation wizard for StreamVibe streaming platform</p>
    </div>

    <div class="container">
        <div class="alert-container"></div>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Installation Progress</h5>
                    </div>
                    <div class="card-body">
                        <div class="progress-container">
                            <div class="progress-step" id="step-1">
                                <div class="progress-icon">
                                    <i class="fas fa-check"></i>
                                </div>
                                <div class="progress-content">
                                    <h5>System Check</h5>
                                    <p class="text-muted">Verifying system requirements</p>
                                </div>
                            </div>
                            <div class="progress-step" id="step-2">
                                <div class="progress-icon">
                                    <i class="fas fa-cog"></i>
                                </div>
                                <div class="progress-content">
                                    <h5>Dependencies</h5>
                                    <p class="text-muted">Installing required packages</p>
                                </div>
                            </div>
                            <div class="progress-step" id="step-3">
                                <div class="progress-icon">
                                    <i class="fas fa-database"></i>
                                </div>
                                <div class="progress-content">
                                    <h5>Database Setup</h5>
                                    <p class="text-muted">Configuring PostgreSQL</p>
                                </div>
                            </div>
                            <div class="progress-step" id="step-4">
                                <div class="progress-icon">
                                    <i class="fas fa-server"></i>
                                </div>
                                <div class="progress-content">
                                    <h5>Web Server</h5>
                                    <p class="text-muted">Setting up NGINX with RTMP</p>
                                </div>
                            </div>
                            <div class="progress-step" id="step-5">
                                <div class="progress-icon">
                                    <i class="fas fa-code"></i>
                                </div>
                                <div class="progress-content">
                                    <h5>Application Installation</h5>
                                    <p class="text-muted">Installing StreamVibe</p>
                                </div>
                            </div>
                            <div class="progress-step" id="step-6">
                                <div class="progress-icon">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <div class="progress-content">
                                    <h5>Security</h5>
                                    <p class="text-muted">SSL and firewall configuration</p>
                                </div>
                            </div>
                            <div class="progress-step" id="step-7">
                                <div class="progress-icon">
                                    <i class="fas fa-flag-checkered"></i>
                                </div>
                                <div class="progress-content">
                                    <h5>Finalization</h5>
                                    <p class="text-muted">Completing setup</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-8">
                <div class="card mb-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">Installation Configuration</h5>
                    </div>
                    <div class="card-body">
                        <form id="config-form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="domain" class="form-label">Domain Name</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fas fa-globe"></i></span>
                                            <input type="text" class="form-control" id="domain" placeholder="streamvibe.biz" value="streamvibe.biz">
                                        </div>
                                        <small class="text-muted">The domain name for your StreamVibe instance</small>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="install_dir" class="form-label">Installation Directory</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fas fa-folder"></i></span>
                                            <input type="text" class="form-control" id="install_dir" placeholder="/var/www/streamvibe" value="/var/www/streamvibe">
                                        </div>
                                        <small class="text-muted">Directory where files will be installed</small>
                                    </div>
                                </div>
                            </div>
                            
                            <h6 class="mt-4 mb-3">Database Settings</h6>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="db_name" class="form-label">Database Name</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fas fa-database"></i></span>
                                            <input type="text" class="form-control" id="db_name" placeholder="streamvibe" value="streamvibe">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="db_user" class="form-label">Database User</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fas fa-user"></i></span>
                                            <input type="text" class="form-control" id="db_user" placeholder="streamvibe_user" value="streamvibe_user">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="db_pass" class="form-label">Database Password</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fas fa-key"></i></span>
                                            <input type="text" class="form-control" id="db_pass" placeholder="Auto-generated" value="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <h6 class="mt-4 mb-3">Admin Account</h6>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="admin_user" class="form-label">Admin Username</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fas fa-user-shield"></i></span>
                                            <input type="text" class="form-control" id="admin_user" placeholder="admin" value="admin">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="admin_email" class="form-label">Admin Email</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fas fa-envelope"></i></span>
                                            <input type="email" class="form-control" id="admin_email" placeholder="admin@streamvibe.biz" value="admin@streamvibe.biz">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label for="admin_pass" class="form-label">Admin Password</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fas fa-lock"></i></span>
                                            <input type="text" class="form-control" id="admin_pass" placeholder="Auto-generated" value="">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between mt-4">
                                <button type="button" class="btn btn-outline-primary" id="generate-passwords">
                                    <i class="fas fa-key me-2"></i>Generate Secure Passwords
                                </button>
                                <button type="submit" class="btn btn-primary" id="start-install">
                                    <i class="fas fa-play me-2"></i>Start Installation
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Installation Console</h5>
                        <div class="d-flex">
                            <button type="button" class="btn btn-sm btn-outline-secondary me-2" id="toggle-console" disabled>
                                <i class="fas fa-cogs me-1"></i>Show Console
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-danger me-2" id="cancel-install" disabled>
                                <i class="fas fa-times me-1"></i>Cancel
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-warning" id="skip-step" disabled>
                                <i class="fas fa-forward me-1"></i>Skip Step
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="console" id="console" style="display: none;">
                            <p class="console-line">Welcome to StreamVibe Installer</p>
                            <p class="console-line">Configure installation settings and click "Start Installation"</p>
                        </div>
                        
                        <div id="install-status" class="text-center py-5">
                            <p class="text-muted mb-0">Installation not started</p>
                        </div>
                        
                        <div id="install-complete" class="text-center py-4" style="display: none;">
                            <i class="fas fa-check-circle text-success" style="font-size: 64px;"></i>
                            <h4 class="mt-3 mb-0">Installation Completed Successfully!</h4>
                            <p class="text-muted">Your StreamVibe instance is now ready to use.</p>
                            
                            <div class="alert alert-info mt-4">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h6>Website URL:</h6>
                                        <p class="mb-0"><a href="#" id="site-url" target="_blank">https://your-domain.com</a></p>
                                    </div>
                                    <div class="col-md-6">
                                        <h6>Admin Login:</h6>
                                        <p class="mb-0"><span id="admin-credentials">admin / password</span></p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <a href="#" id="visit-site" class="btn btn-primary me-2" target="_blank">
                                    <i class="fas fa-external-link-alt me-2"></i>Visit Your Site
                                </a>
                                <a href="#" id="view-report" class="btn btn-outline-secondary" target="_blank">
                                    <i class="fas fa-file-alt me-2"></i>View Report
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Elements
            const configForm = document.getElementById('config-form');
            const generatePasswordsBtn = document.getElementById('generate-passwords');
            const startInstallBtn = document.getElementById('start-install');
            const toggleConsoleBtn = document.getElementById('toggle-console');
            const cancelInstallBtn = document.getElementById('cancel-install');
            const skipStepBtn = document.getElementById('skip-step');
            const console = document.getElementById('console');
            const installStatus = document.getElementById('install-status');
            const installComplete = document.getElementById('install-complete');
            
            // Form inputs
            const domainInput = document.getElementById('domain');
            const installDirInput = document.getElementById('install_dir');
            const dbNameInput = document.getElementById('db_name');
            const dbUserInput = document.getElementById('db_user');
            const dbPassInput = document.getElementById('db_pass');
            const adminUserInput = document.getElementById('admin_user');
            const adminEmailInput = document.getElementById('admin_email');
            const adminPassInput = document.getElementById('admin_pass');
            
            // Generate secure passwords
            generatePasswordsBtn.addEventListener('click', function() {
                // Function to generate a random password
                function generatePassword(length = 12) {
                    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+";
                    let password = "";
                    for (let i = 0; i < length; i++) {
                        const randomIndex = Math.floor(Math.random() * charset.length);
                        password += charset.charAt(randomIndex);
                    }
                    return password;
                }
                
                dbPassInput.value = generatePassword(16);
                adminPassInput.value = generatePassword(12);
                
                showAlert('Passwords generated successfully!', 'success');
            });
            
            // Toggle console
            toggleConsoleBtn.addEventListener('click', function() {
                if (console.style.display === 'none') {
                    console.style.display = 'block';
                    installStatus.style.display = 'none';
                    toggleConsoleBtn.innerHTML = '<i class="fas fa-cogs me-1"></i>Hide Console';
                } else {
                    console.style.display = 'none';
                    installStatus.style.display = 'block';
                    toggleConsoleBtn.innerHTML = '<i class="fas fa-cogs me-1"></i>Show Console';
                }
            });
            
            // Start installation
            configForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Validate form
                if (!domainInput.value) {
                    showAlert('Domain name is required', 'danger');
                    return;
                }
                
                if (!installDirInput.value) {
                    showAlert('Installation directory is required', 'danger');
                    return;
                }
                
                if (!dbNameInput.value || !dbUserInput.value) {
                    showAlert('Database name and user are required', 'danger');
                    return;
                }
                
                if (!adminUserInput.value || !adminEmailInput.value) {
                    showAlert('Admin username and email are required', 'danger');
                    return;
                }
                
                // Generate passwords if not provided
                if (!dbPassInput.value) {
                    dbPassInput.value = generateRandomPassword(16);
                }
                
                if (!adminPassInput.value) {
                    adminPassInput.value = generateRandomPassword(12);
                }
                
                // Show console and update buttons
                console.style.display = 'block';
                installStatus.style.display = 'none';
                toggleConsoleBtn.disabled = false;
                cancelInstallBtn.disabled = false;
                skipStepBtn.disabled = false;
                startInstallBtn.disabled = true;
                
                // Disable form inputs
                toggleFormInputs(false);
                
                // Update step 1 to active
                updateStepStatus(1, 'active');
                
                // Log installation start
                logToConsole('Installation started...');
                logToConsole('Preparing system check...');
                
                // Simulate installation process (this would be replaced with actual API calls)
                simulateInstallation();
            });
            
            // Helper functions
            function showAlert(message, type = 'info') {
                const alertContainer = document.querySelector('.alert-container');
                const alertId = 'alert-' + Date.now();
                
                const alertHtml = `
                    <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
                        ${message}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                `;
                
                alertContainer.insertAdjacentHTML('beforeend', alertHtml);
                
                // Auto-dismiss after 5 seconds
                setTimeout(() => {
                    const alert = document.getElementById(alertId);
                    if (alert) {
                        alert.classList.remove('show');
                        setTimeout(() => alert.remove(), 150);
                    }
                }, 5000);
            }
            
            function logToConsole(message) {
                const consoleLine = document.createElement('p');
                consoleLine.className = 'console-line';
                consoleLine.textContent = message;
                console.appendChild(consoleLine);
                console.scrollTop = console.scrollHeight;
            }
            
            function updateStepStatus(stepNumber, status) {
                // Reset all steps
                for (let i = 1; i <= 7; i++) {
                    const stepElement = document.getElementById(`step-${i}`);
                    stepElement.className = 'progress-step';
                }
                
                // Update completed steps
                for (let i = 1; i < stepNumber; i++) {
                    const stepElement = document.getElementById(`step-${i}`);
                    stepElement.className = 'progress-step completed';
                }
                
                // Update current step
                if (status === 'active') {
                    const currentStep = document.getElementById(`step-${stepNumber}`);
                    currentStep.className = 'progress-step active';
                } else if (status === 'completed') {
                    const currentStep = document.getElementById(`step-${stepNumber}`);
                    currentStep.className = 'progress-step completed';
                }
            }
            
            function toggleFormInputs(enabled) {
                const inputs = configForm.querySelectorAll('input');
                inputs.forEach(input => {
                    input.disabled = !enabled;
                });
                
                generatePasswordsBtn.disabled = !enabled;
            }
            
            function generateRandomPassword(length) {
                const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+";
                let password = "";
                for (let i = 0; i < length; i++) {
                    const randomIndex = Math.floor(Math.random() * charset.length);
                    password += charset.charAt(randomIndex);
                }
                return password;
            }
            
            // Simulate installation (this would be replaced with actual API calls)
            function simulateInstallation() {
                const steps = [
                    { 
                        name: 'System Check', 
                        duration: 3000,
                        logs: [
                            'Checking system requirements...',
                            'Detecting operating system...',
                            'Detected: Ubuntu 20.04 LTS',
                            'Checking available disk space...',
                            'Checking CPU and memory...',
                            'System requirements met!'
                        ]
                    },
                    { 
                        name: 'Dependencies Installation', 
                        duration: 5000,
                        logs: [
                            'Installing dependencies...',
                            'Installing Python packages...',
                            'Installing PostgreSQL...',
                            'Installing NGINX with RTMP module...',
                            'Installing FFmpeg...',
                            'All dependencies installed successfully!'
                        ]
                    },
                    { 
                        name: 'Database Setup', 
                        duration: 4000,
                        logs: [
                            'Setting up PostgreSQL database...',
                            `Creating database "${dbNameInput.value}"...`,
                            `Creating database user "${dbUserInput.value}"...`,
                            'Granting privileges...',
                            'Testing database connection...',
                            'Database setup completed!'
                        ]
                    },
                    { 
                        name: 'NGINX Configuration', 
                        duration: 4000,
                        logs: [
                            'Configuring NGINX with RTMP module...',
                            'Creating NGINX configuration file...',
                            'Setting up RTMP streaming endpoint...',
                            'Configuring HLS and DASH streaming...',
                            'Testing NGINX configuration...',
                            'NGINX configured successfully!'
                        ]
                    },
                    { 
                        name: 'StreamVibe Installation', 
                        duration: 6000,
                        logs: [
                            'Installing StreamVibe application...',
                            `Creating installation directory at "${installDirInput.value}"...`,
                            'Setting up Python virtual environment...',
                            'Installing application dependencies...',
                            'Creating configuration files...',
                            'Creating systemd service...',
                            'Creating admin user...',
                            'Starting StreamVibe service...',
                            'StreamVibe application installed successfully!'
                        ]
                    },
                    { 
                        name: 'Security Setup', 
                        duration: 3000,
                        logs: [
                            'Configuring security settings...',
                            `Setting up SSL for ${domainInput.value}...`,
                            'Configuring firewall...',
                            'Setting file permissions...',
                            'Security setup completed!'
                        ]
                    },
                    { 
                        name: 'Finalization', 
                        duration: 2000,
                        logs: [
                            'Creating installation report...',
                            'Finalizing installation...',
                            'Cleaning up temporary files...',
                            'Starting all services...',
                            'Installation completed successfully!'
                        ]
                    }
                ];
                
                let currentStep = 0;
                
                function runNextStep() {
                    if (currentStep < steps.length) {
                        const step = steps[currentStep];
                        
                        updateStepStatus(currentStep + 1, 'active');
                        logToConsole(`Executing step ${currentStep + 1}: ${step.name}...`);
                        
                        let logIndex = 0;
                        const logInterval = Math.floor(step.duration / step.logs.length);
                        
                        const logTimer = setInterval(() => {
                            if (logIndex < step.logs.length) {
                                logToConsole(step.logs[logIndex]);
                                logIndex++;
                            } else {
                                clearInterval(logTimer);
                            }
                        }, logInterval);
                        
                        setTimeout(() => {
                            updateStepStatus(currentStep + 1, 'completed');
                            logToConsole(`Step ${currentStep + 1} completed!`);
                            currentStep++;
                            
                            if (currentStep < steps.length) {
                                runNextStep();
                            } else {
                                // Installation complete
                                showInstallationComplete();
                            }
                        }, step.duration);
                    }
                }
                
                runNextStep();
            }
            
            function showInstallationComplete() {
                // Update UI
                installComplete.style.display = 'block';
                console.style.display = 'none';
                
                // Update complete screen with dynamic values
                document.getElementById('site-url').textContent = `https://${domainInput.value}`;
                document.getElementById('site-url').href = `https://${domainInput.value}`;
                document.getElementById('admin-credentials').textContent = `${adminUserInput.value} / ${adminPassInput.value}`;
                document.getElementById('visit-site').href = `https://${domainInput.value}`;
                
                // Disable control buttons
                toggleConsoleBtn.disabled = true;
                cancelInstallBtn.disabled = true;
                skipStepBtn.disabled = true;
                
                // Show success alert
                showAlert('Installation completed successfully!', 'success');
            }
        });
    </script>
</body>
</html>
EOF
    
    # Create a simple web server script
    cat > $INSTALL_DIR/install_dashboard/run_dashboard.py << EOF
#!/usr/bin/env python3
import http.server
import socketserver
import os
import sys
import webbrowser
from urllib.parse import parse_qs

PORT = 8585

class InstallerHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory="$INSTALL_DIR/install_dashboard", **kwargs)
    
    def do_GET(self):
        if self.path == '/':
            return super().do_GET()
        super().do_GET()

def main():
    with socketserver.TCPServer(("", PORT), InstallerHandler) as httpd:
        print(f"StreamVibe installer dashboard running at http://localhost:{PORT}")
        print("Access this URL in your browser to start the installation")
        
        # Open the dashboard in the default browser
        webbrowser.open(f"http://localhost:{PORT}")
        
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("Dashboard stopped")

if __name__ == "__main__":
    main()
EOF
    
    # Make the script executable
    chmod +x $INSTALL_DIR/install_dashboard/run_dashboard.py
    
    success_message "Installation dashboard set up successfully at $INSTALL_DIR/install_dashboard"
    success_message "Run the dashboard with: sudo python3 $INSTALL_DIR/install_dashboard/run_dashboard.py"
}

# Function to finalize installation
function finalize_installation() {
    status_message "Finalizing installation..."
    
    create_report
    setup_firewall
    
    success_message "Installation completed successfully!"
    success_message "You can now access your StreamVibe instance at: http://$DOMAIN_NAME"
    success_message "Admin login: $ADMIN_USER / $ADMIN_PASS"
}

# Main function
function main() {
    # Check if we received specific command to run
    if [ "$1" ]; then
        case $1 in
            check_system)
                check_root
                detect_os
                exit 0
                ;;
            install_dependencies)
                check_root
                install_dependencies
                exit 0
                ;;
            setup_database)
                check_root
                setup_database
                exit 0
                ;;
            configure_nginx_rtmp)
                check_root
                configure_nginx_rtmp
                exit 0
                ;;
            setup_streamvibe)
                check_root
                setup_streamvibe
                exit 0
                ;;
            setup_ssl)
                check_root
                setup_ssl
                exit 0
                ;;
            finalize_installation)
                check_root
                finalize_installation
                exit 0
                ;;
            *)
                error_message "Unknown command: $1"
                exit 1
                ;;
        esac
    fi
    
    # Welcome message
    clear
    echo "================================================================="
    echo "                  StreamVibe Auto Installer                      "
    echo "================================================================="
    echo
    echo "This script will install StreamVibe and its dependencies."
    echo
    echo "Installation options:"
    echo "1. Web Dashboard Installation"
    echo "2. Command Line Installation"
    echo "3. Quit"
    echo
    read -p "Select an option (1-3): " install_option
    
    case $install_option in
        1)
            setup_dashboard
            ;;
        2)
            check_root
            detect_os
            install_dependencies
            setup_database
            configure_nginx_rtmp
            setup_streamvibe
            setup_ssl
            finalize_installation
            ;;
        3)
            echo "Installation cancelled."
            exit 0
            ;;
        *)
            error_message "Invalid option. Please select 1, 2, or 3."
            exit 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"