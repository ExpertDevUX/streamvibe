import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_login import LoginManager
import datetime

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Base class for SQLAlchemy models
class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///streamapp.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Explicitly enable debug mode for stream handler to work correctly
app.config["DEBUG"] = True

# Configure upload path
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# Initialize the database
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'

# Add custom Jinja2 filters
@app.template_filter('zfill')
def jinja2_zfill(value, width):
    """Pad a string with zeros to specified width."""
    return str(value).zfill(width)

@app.template_filter('tojson')
def jinja2_tojson(obj):
    """Convert object to JSON string."""
    import json
    return json.dumps(obj)

@app.template_filter('json_loads')
def jinja2_json_loads(json_str):
    """Load JSON string into Python object."""
    import json
    try:
        return json.loads(json_str)
    except:
        return []

@app.template_filter('timesince')
def jinja2_timesince(dt, default="just now"):
    """Format a date as time since (e.g., "4 hours ago")."""
    if dt is None:
        return default
        
    now = datetime.datetime.utcnow()
    diff = now - dt
    
    seconds = diff.total_seconds()
    
    if seconds < 60:
        return 'just now'
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif seconds < 604800:
        days = int(seconds / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"
    elif seconds < 2592000:
        weeks = int(seconds / 604800)
        return f"{weeks} week{'s' if weeks != 1 else ''} ago"
    elif seconds < 31536000:
        months = int(seconds / 2592000)
        return f"{months} month{'s' if months != 1 else ''} ago"
    else:
        years = int(seconds / 31536000)
        return f"{years} year{'s' if years != 1 else ''} ago"

# Import and register blueprints
with app.app_context():
    # Import models
    import models
    
    # Import routes
    from routes.auth import auth_bp
    from routes.media import media_bp
    from routes.stream import stream_bp
    from routes.users import users_bp
    from routes.analytics import analytics_bp
    from routes.admin import admin_bp
    from routes.studio import studio_bp
    from routes.page import page_bp
    
    # Register blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(media_bp)
    app.register_blueprint(stream_bp)
    app.register_blueprint(users_bp)
    app.register_blueprint(analytics_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(studio_bp)
    app.register_blueprint(page_bp)
    
    # Create all database tables
    db.create_all()
    
    # Start stream health monitoring if not in testing mode
    if not app.config.get('TESTING', False):
        from utils.stream_handler import start_health_check
        # Pass the app instance to properly set up application context
        start_health_check(app)
        app.logger.info("Stream health monitoring started with application context")

# Load user from session
@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))
