#!/bin/bash
# StreamVibe Simplified Installation Script
# This script installs everything in a single folder for easy deployment

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/var/www/html"
DOMAIN_NAME="streamvibe.biz"
DB_NAME="streamvibe"
DB_USER="streamvibe_user"
DB_PASS=$(openssl rand -base64 12 | tr -d "=+/" | cut -c1-16)
ADMIN_USER="admin"
ADMIN_EMAIL="admin@streamvibe.biz"
ADMIN_PASS="admin123"

# Function to print status
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Function to print success
print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Function to print error
print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root"
    exit 1
fi

# Installation steps
print_status "Starting StreamVibe installation (Single-Folder Version)"

# Step 1: Update system and install dependencies
print_status "Updating system and installing dependencies..."
apt update
apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib \
    ffmpeg build-essential libssl-dev libpcre3-dev zlib1g-dev \
    curl wget git unzip libnginx-mod-rtmp certbot python3-certbot-nginx

# Step 2: Install RTMP module if not already installed
if [ ! -f "/usr/lib/nginx/modules/ngx_rtmp_module.so" ] && [ ! -f "/etc/nginx/modules-available/ngx_rtmp_module.so" ]; then
    print_warning "RTMP module not found. Installing manually..."
    # This would have more complex RTMP module installation code
    # But we'll assume it's available in the package manager for simplicity
fi

# Step 3: Configure Nginx
print_status "Configuring Nginx with RTMP..."
cat > /etc/nginx/nginx.conf << EOF
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

# RTMP Configuration
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path $INSTALL_DIR/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path $INSTALL_DIR/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/auth;
            on_publish_done http://127.0.0.1:5000/done;
        }
    }
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;
    
    # Logging settings
    access_log /var/log/nginx/access.log;
    error_log /var/log/nginx/error.log;
    
    # Gzip settings
    gzip on;
    gzip_disable "msie6";
    gzip_vary on;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    
    # Virtual Host Configs
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
EOF

# Create site configuration
cat > /etc/nginx/sites-available/streamvibe << EOF
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /static {
        alias $INSTALL_DIR/static;
        expires 30d;
    }

    location /hls {
        alias $INSTALL_DIR/hls;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
    }
    
    location /dash {
        alias $INSTALL_DIR/dash;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/dash+xml mpd;
        }
    }
}
EOF

# Enable the site configuration
ln -sf /etc/nginx/sites-available/streamvibe /etc/nginx/sites-enabled/
if [ -f /etc/nginx/sites-enabled/default ]; then
    rm /etc/nginx/sites-enabled/default
fi

# Test Nginx configuration
nginx -t
systemctl restart nginx
systemctl enable nginx

# Step 4: Configure PostgreSQL
print_status "Setting up PostgreSQL database..."
systemctl start postgresql
systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" || print_warning "User may already exist"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;" || print_warning "Database may already exist"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

# Step 5: Create Directory Structure (simplified)
print_status "Creating directory structure..."
mkdir -p $INSTALL_DIR
mkdir -p $INSTALL_DIR/hls
mkdir -p $INSTALL_DIR/dash
mkdir -p $INSTALL_DIR/static
mkdir -p $INSTALL_DIR/uploads

# Step 6: Create Flask Application Files (All in one folder)
print_status "Creating StreamVibe application files..."

# Create app.py with all routes integrated
cat > $INSTALL_DIR/app.py << 'EOF'
import os
import logging
import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Base class for SQLAlchemy models
class Base(DeclarativeBase):
    pass

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "development-secret-key")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///streamvibe.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")
app.config["DEBUG"] = True

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

#-------------------------
# Models
#-------------------------
class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    profile_description = db.Column(db.Text, nullable=True)
    avatar_path = db.Column(db.String(255), nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Media(db.Model):
    __tablename__ = 'media'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=False)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    media_type = db.Column(db.String(20), nullable=False)  # video, audio
    duration = db.Column(db.Integer, nullable=True)  # Duration in seconds
    views = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __repr__(self):
        return f'<Media {self.title}>'

class Stream(db.Model):
    __tablename__ = 'streams'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    stream_key = db.Column(db.String(64), unique=True, nullable=False)
    is_live = db.Column(db.Boolean, default=False)
    viewers = db.Column(db.Integer, default=0)
    started_at = db.Column(db.DateTime, nullable=True)
    ended_at = db.Column(db.DateTime, nullable=True)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    def __repr__(self):
        return f'<Stream {self.title}>'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

#-------------------------
# Authentication Routes
#-------------------------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Please enter both username and password', 'danger')
            return render_template('login.html')
            
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

#-------------------------
# Main Routes
#-------------------------
@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

#-------------------------
# Admin Routes
#-------------------------
def admin_required(f):
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You need admin privileges to access this page', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return decorated_function

@app.route('/admin')
@login_required
@admin_required
def admin():
    return render_template('admin.html')

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    users = User.query.all()
    return render_template('admin_users.html', users=users)

#-------------------------
# Stream Routes
#-------------------------
@app.route('/auth')
def auth_stream():
    # Simple authentication for RTMP streams
    # In a real application, this would check stream keys
    return '', 200

@app.route('/done')
def done_stream():
    # Stream ended callback
    return '', 200

#-------------------------
# Create tables and admin user
#-------------------------
@app.before_first_request
def create_tables_and_admin():
    db.create_all()
    
    # Check if admin user exists
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        # Create admin user
        admin = User(
            username='admin',
            email='admin@streamvibe.biz',
            is_admin=True
        )
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()
        logger.info("Admin user created")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
EOF

# Create main.py
cat > $INSTALL_DIR/main.py << 'EOF'
from app import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
EOF

# Create HTML templates
mkdir -p $INSTALL_DIR/templates
mkdir -p $INSTALL_DIR/static/css
mkdir -p $INSTALL_DIR/static/js

# Base template
cat > $INSTALL_DIR/templates/base.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}StreamVibe{% endblock %}</title>
    <link rel="stylesheet" href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css">
    <style>
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .main-content {
            flex: 1;
        }
        .navbar-brand {
            font-weight: bold;
            background: linear-gradient(45deg, #9370DB, #4169E1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .footer {
            padding: 1rem 0;
            margin-top: auto;
        }
    </style>
    {% block styles %}{% endblock %}
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">StreamVibe</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    {% if current_user.is_authenticated %}
                    <li class="nav-item">
                        <a class="nav-link" href="/dashboard">Dashboard</a>
                    </li>
                    {% if current_user.is_admin %}
                    <li class="nav-item">
                        <a class="nav-link" href="/admin">Admin</a>
                    </li>
                    {% endif %}
                    {% endif %}
                </ul>
                <ul class="navbar-nav">
                    {% if current_user.is_authenticated %}
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            {{ current_user.username }}
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="/profile">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/logout">Logout</a></li>
                        </ul>
                    </li>
                    {% else %}
                    <li class="nav-item">
                        <a class="nav-link" href="/login">Login</a>
                    </li>
                    {% endif %}
                </ul>
            </div>
        </div>
    </nav>

    <div class="container main-content py-4">
        {% with messages = get_flashed_messages(with_categories=true) %}
        {% if messages %}
            {% for category, message in messages %}
            <div class="alert alert-{{ category }} alert-dismissible fade show" role="alert">
                {{ message }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            {% endfor %}
        {% endif %}
        {% endwith %}
        
        {% block content %}{% endblock %}
    </div>

    <footer class="footer bg-dark text-light">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; 2025 StreamVibe. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    {% block scripts %}{% endblock %}
</body>
</html>
EOF

# Login template
cat > $INSTALL_DIR/templates/login.html << 'EOF'
{% extends "base.html" %}

{% block title %}Login - StreamVibe{% endblock %}

{% block content %}
<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Login</h4>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember">Remember me</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOF

# Dashboard template
cat > $INSTALL_DIR/templates/dashboard.html << 'EOF'
{% extends "base.html" %}

{% block title %}Dashboard - StreamVibe{% endblock %}

{% block content %}
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Dashboard</h1>
            <div>
                <a href="/stream/create" class="btn btn-primary me-2">Go Live</a>
                <a href="/upload" class="btn btn-success">Upload Media</a>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Your Streams</h5>
                        <p class="card-text">Manage your live streams</p>
                        <a href="/streams" class="btn btn-primary">View Streams</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Your Videos</h5>
                        <p class="card-text">Manage your uploaded videos</p>
                        <a href="/videos" class="btn btn-primary">View Videos</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Analytics</h5>
                        <p class="card-text">View your stream and video analytics</p>
                        <a href="/analytics" class="btn btn-primary">View Analytics</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOF

# Admin template
cat > $INSTALL_DIR/templates/admin.html << 'EOF'
{% extends "base.html" %}

{% block title %}Admin Dashboard - StreamVibe{% endblock %}

{% block content %}
<div class="row">
    <div class="col-12">
        <h1>Admin Dashboard</h1>
        
        <div class="row mt-4">
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Users</h5>
                        <p class="card-text">Manage user accounts</p>
                        <a href="/admin/users" class="btn btn-primary">Manage Users</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Streams</h5>
                        <p class="card-text">Manage live streams</p>
                        <a href="/admin/streams" class="btn btn-primary">Manage Streams</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Videos</h5>
                        <p class="card-text">Manage uploaded videos</p>
                        <a href="/admin/videos" class="btn btn-primary">Manage Videos</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">System</h5>
                        <p class="card-text">System configuration</p>
                        <a href="/admin/system" class="btn btn-primary">System Settings</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOF

# Admin users template
cat > $INSTALL_DIR/templates/admin_users.html << 'EOF'
{% extends "base.html" %}

{% block title %}Manage Users - StreamVibe{% endblock %}

{% block content %}
<div class="row">
    <div class="col-12">
        <h1>Manage Users</h1>
        
        <div class="card mt-4">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Admin</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {% for user in users %}
                            <tr>
                                <td>{{ user.id }}</td>
                                <td>{{ user.username }}</td>
                                <td>{{ user.email }}</td>
                                <td>
                                    {% if user.is_admin %}
                                    <span class="badge bg-success">Yes</span>
                                    {% else %}
                                    <span class="badge bg-secondary">No</span>
                                    {% endif %}
                                </td>
                                <td>{{ user.created_at.strftime('%Y-%m-%d') }}</td>
                                <td>
                                    <a href="/admin/users/{{ user.id }}" class="btn btn-sm btn-primary">View</a>
                                    <a href="/admin/users/{{ user.id }}/edit" class="btn btn-sm btn-warning">Edit</a>
                                </td>
                            </tr>
                            {% endfor %}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOF

# Step 7: Create virtual environment and install packages
print_status "Setting up Python environment and installing dependencies..."
cd $INSTALL_DIR
python3 -m venv venv
source venv/bin/activate

pip install Flask==2.3.3 flask-login==0.6.2 flask-sqlalchemy==3.1.1 flask-wtf==1.2.1
pip install werkzeug==2.3.7 gunicorn==23.0.0 psycopg2-binary==2.9.9 email-validator==2.1.0

# Step 8: Create .env file
print_status "Creating environment configuration..."
cat > $INSTALL_DIR/.env << EOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
SESSION_SECRET=$(openssl rand -base64 32)
STREAM_SERVER=$DOMAIN_NAME
DOMAIN_NAME=$DOMAIN_NAME
RTMP_SERVER=rtmp://$DOMAIN_NAME/live
EOF

# Step 9: Create systemd service
print_status "Creating systemd service..."
cat > /etc/systemd/system/streamvibe.service << EOF
[Unit]
Description=StreamVibe Gunicorn Service
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin"
EnvironmentFile=$INSTALL_DIR/.env
ExecStart=$INSTALL_DIR/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# Step 10: Set permissions
print_status "Setting permissions..."
chown -R www-data:www-data $INSTALL_DIR
chmod -R 755 $INSTALL_DIR

# Step 11: Start services
print_status "Starting services..."
systemctl daemon-reload
systemctl restart nginx
systemctl enable streamvibe
systemctl restart streamvibe

# Step 12: Final output
print_success "StreamVibe installation completed!"
echo
echo "===============================================" 
echo "  StreamVibe has been installed successfully! "
echo "===============================================" 
echo
echo "Access your StreamVibe instance at: http://$DOMAIN_NAME"
echo "Login with:"
echo "  Username: $ADMIN_USER"
echo "  Password: $ADMIN_PASS"
echo
echo "Important paths:"
echo "  Installation directory: $INSTALL_DIR"
echo "  Database credentials:"
echo "    Database: $DB_NAME"
echo "    Username: $DB_USER" 
echo "    Password: $DB_PASS"
echo
echo "RTMP Streaming URL: rtmp://$DOMAIN_NAME/live"
echo "Stream Key: Create one in the dashboard"
echo
echo "If you need to restart services:"
echo "  sudo systemctl restart streamvibe"
echo "  sudo systemctl restart nginx"
echo