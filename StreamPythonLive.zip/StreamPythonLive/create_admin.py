import os
import sys
import datetime
from werkzeug.security import generate_password_hash
from sqlalchemy import create_engine, Column, Integer, String, Text, Boolean, DateTime, ForeignKey, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

# Define database URL
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///instance/streamapp.db")

# Create engine and session
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()
Base = declarative_base()

# Define User model matching our app's model
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    profile_description = Column(Text, nullable=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

# Create admin function
def create_admin_account(username="admin", email="admin@streamvibe.com", password="admin123"):
    # Check if is_admin column exists and add it if necessary
    try:
        # Try to access is_admin column
        session.query(User.is_admin).first()
        print("is_admin column exists")
    except Exception as e:
        print(f"Adding is_admin column to users table: {e}")
        try:
            connection = engine.connect()
            connection.execute(text("ALTER TABLE users ADD COLUMN is_admin BOOLEAN DEFAULT 0"))
            connection.close()
            print("Added is_admin column successfully")
        except Exception as e:
            print(f"Error adding is_admin column: {e}")
            # Try to create tables if they don't exist
            Base.metadata.create_all(engine)
            print("Created/updated database tables")

    # Check if admin exists
    existing_admin = session.query(User).filter_by(is_admin=True).first()
    if existing_admin:
        print(f"Admin already exists: {existing_admin.username}")
        return
        
    # Check if username exists
    existing_user = session.query(User).filter_by(username=username).first()
    if existing_user:
        print(f"Username '{username}' already exists. Choose another username.")
        return
        
    # Create admin user
    admin = User(
        username=username,
        email=email,
        password_hash=generate_password_hash(password),
        is_admin=True
    )
    
    try:
        session.add(admin)
        session.commit()
        print(f"Admin account created successfully!")
        print(f"Username: {username}")
        print(f"Password: {password}")
    except Exception as e:
        session.rollback()
        print(f"Error creating admin account: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 3:
        create_admin_account(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        create_admin_account()