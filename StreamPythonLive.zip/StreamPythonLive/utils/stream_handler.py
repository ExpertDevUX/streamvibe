import os
import json
import uuid
import logging
import requests
import time
import threading
import socket
from datetime import datetime, timedelta
from flask import current_app

# Configure logging
logging.basicConfig(level=logging.INFO, 
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Health check thread condition and lock
health_check_thread_running = False
health_check_lock = threading.Lock()

# Health check interval - longer in development mode to reduce log spam
def get_health_check_interval():
    """Get the appropriate health check interval based on environment"""
    try:
        if current_app.config.get('DEBUG', False):
            return 120  # Check every 2 minutes in development
        else:
            return 30   # Check every 30 seconds in production
    except RuntimeError:
        # If no Flask app context is available, use default
        return 30

# In-memory storage for active streams
# Key: stream_key, Value: {session_id, peers, started_at, etc.}
active_streams = {}

def create_stream_session(stream_key):
    """
    Create a new WebRTC streaming session
    Returns session information needed for the broadcaster
    """
    session_id = str(uuid.uuid4())
    
    # Initialize session data
    active_streams[stream_key] = {
        'session_id': session_id,
        'peers': {},
        'ice_servers': get_ice_servers(),
        'active': True
    }
    
    logger.info(f"Created new streaming session {session_id} for stream {stream_key}")
    
    return {
        'session_id': session_id,
        'ice_servers': get_ice_servers()
    }

def end_stream_session(stream_key):
    """End a WebRTC streaming session"""
    if stream_key in active_streams:
        active_streams[stream_key]['active'] = False
        logger.info(f"Ended streaming session for stream {stream_key}")
        return True
    return False

def join_stream(stream_key, peer_id):
    """
    Join a viewer to a stream
    Returns session information needed for the viewer
    """
    if stream_key not in active_streams or not active_streams[stream_key]['active']:
        logger.warning(f"Attempted to join non-existent or inactive stream {stream_key}")
        return None
    
    # Add viewer to the stream's peers
    active_streams[stream_key]['peers'][peer_id] = {
        'joined_at': datetime.utcnow(),
        'last_activity': datetime.utcnow()
    }
    
    logger.info(f"Peer {peer_id} joined stream {stream_key}")
    
    return {
        'session_id': active_streams[stream_key]['session_id'],
        'ice_servers': active_streams[stream_key]['ice_servers']
    }

def leave_stream(stream_key, peer_id):
    """Remove a viewer from a stream"""
    if stream_key in active_streams and peer_id in active_streams[stream_key]['peers']:
        del active_streams[stream_key]['peers'][peer_id]
        logger.info(f"Peer {peer_id} left stream {stream_key}")
        return True
    return False

def get_stream_status(stream_key):
    """Get the current status of a stream"""
    if stream_key not in active_streams:
        return {
            'active': False,
            'viewer_count': 0
        }
    
    return {
        'active': active_streams[stream_key]['active'],
        'viewer_count': len(active_streams[stream_key]['peers'])
    }

def get_ice_servers():
    """Get ICE servers configuration for WebRTC"""
    turn_server = current_app.config.get('TURN_SERVER')
    turn_username = current_app.config.get('TURN_USERNAME')
    turn_password = current_app.config.get('TURN_PASSWORD')
    
    ice_servers = [
        {'urls': 'stun:stun.l.google.com:19302'},
        {'urls': 'stun:stun1.l.google.com:19302'}
    ]
    
    # Add TURN server if configured
    if turn_server:
        turn_config = {
            'urls': turn_server
        }
        
        if turn_username and turn_password:
            turn_config['username'] = turn_username
            turn_config['credential'] = turn_password
        
        ice_servers.append(turn_config)
    
    return ice_servers

def cleanup_inactive_streams(timeout_minutes=30):
    """Clean up inactive streams and peers"""
    current_time = datetime.utcnow()
    timeout = timedelta(minutes=timeout_minutes)
    
    for stream_key in list(active_streams.keys()):
        stream = active_streams[stream_key]
        
        # Remove inactive peers
        for peer_id in list(stream['peers'].keys()):
            peer = stream['peers'][peer_id]
            if current_time - peer['last_activity'] > timeout:
                del stream['peers'][peer_id]
                logger.info(f"Removed inactive peer {peer_id} from stream {stream_key}")
        
        # Remove empty inactive streams
        if not stream['active'] and not stream['peers']:
            del active_streams[stream_key]
            logger.info(f"Removed inactive stream {stream_key}")

# NGINX-RTMP Integration functions
def get_rtmp_url(stream_key):
    """Get the RTMP URL for broadcasters"""
    rtmp_server = current_app.config.get('RTMP_SERVER')
    # Ensure we have a valid RTMP server URL
    if not rtmp_server:
        rtmp_server = "rtmp://streamvibe.biz/live"
    return f"{rtmp_server}/{stream_key}"

def get_hls_url(stream_key):
    """Get the HLS URL for viewers"""
    hls_server = current_app.config.get('HLS_SERVER')
    # Ensure we have a valid HLS server URL
    if not hls_server:
        hls_server = "https://streamvibe.biz/hls"
    return f"{hls_server}/{stream_key}.m3u8"

def get_dash_url(stream_key):
    """Get the DASH URL for viewers"""
    dash_server = current_app.config.get('DASH_SERVER')
    # Ensure we have a valid DASH server URL
    if not dash_server:
        dash_server = "https://streamvibe.biz/dash"
    return f"{dash_server}/{stream_key}.mpd"

def check_stream_active(stream_key):
    """Check if a stream is active on NGINX-RTMP"""
    # Check if we're in development mode first
    if current_app.config.get('DEBUG', False):
        # In development mode, simply use our in-memory tracking
        is_active = stream_key in active_streams and active_streams[stream_key].get('active', False)
        logger.debug(f"Development mode: Stream {stream_key} is {'active' if is_active else 'inactive'} (from in-memory tracking)")
        return is_active
    
    # In production, check the actual NGINX RTMP status
    try:
        server = current_app.config.get('STREAM_SERVER', "streamvibe.biz")
        rtmp_status_url = f"http://{server}/nginx_stat"
        response = requests.get(rtmp_status_url, timeout=5)
        
        if response.status_code == 200:
            # Parse XML response to find the stream
            # This is a simplified version; in production you'd use proper XML parsing
            is_active = stream_key in response.text
            logger.info(f"RTMP stream {stream_key} is {'active' if is_active else 'inactive'}")
            return is_active
            
        logger.warning(f"Failed to check RTMP status for {stream_key}: nginx returned {response.status_code}")
        return False
    except Exception as e:
        logger.error(f"Error checking RTMP stream status: {str(e)}")
        # If we can't check and not in dev mode, assume it's not active
        return False

def get_stream_viewers(stream_key):
    """Get the number of viewers for a stream from NGINX-RTMP stats"""
    # In development mode, count peers from our in-memory tracking
    if current_app.config.get('DEBUG', False):
        # Check if stream exists and is active
        if stream_key in active_streams:
            # Count peers
            peers_count = len(active_streams[stream_key].get('peers', {}))
            
            # In development, add some random viewers for testing
            import random
            fake_viewers = random.randint(5, 50)
            total_viewers = peers_count + fake_viewers
            
            logger.debug(f"Development mode: Stream {stream_key} has {peers_count} real viewers plus {fake_viewers} simulated = {total_viewers} total")
            return total_viewers
        else:
            logger.debug(f"Development mode: Stream {stream_key} doesn't exist, returning 0 viewers")
            return 0
    
    # In production, check the actual NGINX RTMP status
    try:
        server = current_app.config.get('STREAM_SERVER', "streamvibe.biz")
        rtmp_status_url = f"http://{server}/nginx_stat"
        response = requests.get(rtmp_status_url, timeout=5)
        
        if response.status_code == 200:
            # Parse XML response to find viewers
            # This is a simplified version; in production you'd use proper XML parsing
            # and extract the actual viewer count for the specified stream
            # Placeholder for actual implementation
            logger.warning(f"Production mode: Viewer counting not fully implemented for {stream_key}")
            return 0
            
        logger.warning(f"Failed to get viewer count for {stream_key}: nginx returned {response.status_code}")
        return 0
    except Exception as e:
        logger.error(f"Error getting stream viewers: {str(e)}")
        return 0

def get_available_protocols(stream_key):
    """
    Check which streaming protocols are available for this stream
    Returns a dictionary with the availability status of each protocol
    """
    protocols = {
        'rtmp': False,
        'hls': False,
        'dash': False,
        'webrtc': False
    }
    
    # Check if we're in development mode
    if current_app.config.get('DEBUG', False):
        # In development mode, assume all protocols are available for active streams
        if stream_key in active_streams and active_streams[stream_key].get('active', False):
            logger.info(f"Development mode: Simulating all protocols available for active stream {stream_key}")
            for protocol in protocols:
                protocols[protocol] = True
        else:
            # Stream is not active or doesn't exist
            logger.info(f"Development mode: Stream {stream_key} is not active, no protocols available")
            # WebRTC might still be available even if the stream isn't active yet
            protocols['webrtc'] = stream_key in active_streams
        
        return protocols
        
    # In production, check actual protocol availability
    try:
        # Check RTMP availability by trying to connect to the RTMP server
        server = current_app.config.get('STREAM_SERVER', 'streamvibe.biz')
        rtmp_status_url = f"http://{server}/nginx_stat"
        response = requests.get(rtmp_status_url, timeout=3)
        
        if response.status_code == 200:
            protocols['rtmp'] = stream_key in response.text
            
            # Check for HLS/DASH - in a real implementation, we would check if the
            # playlist files exist on the server
            if protocols['rtmp']:  # If RTMP is available, HLS/DASH might be too
                protocols['hls'] = True
                protocols['dash'] = True
    except Exception as e:
        logger.warning(f"Error checking protocol availability: {str(e)}")
    
    # Check WebRTC availability (if we have an active session)
    protocols['webrtc'] = stream_key in active_streams and active_streams[stream_key].get('active', False)
    
    return protocols

def get_preferred_protocol(stream_key):
    """
    Determine the best streaming protocol to use based on availability
    Returns the name of the preferred protocol to use
    Order of preference: WebRTC > HLS > DASH > RTMP
    """
    protocols = get_available_protocols(stream_key)
    
    # Preferred order for lowest latency and best compatibility
    if protocols['webrtc']:
        return 'webrtc'
    elif protocols['hls']:
        return 'hls'
    elif protocols['dash']:
        return 'dash'
    elif protocols['rtmp']:
        return 'rtmp'
    else:
        # No protocols available, default to HLS as it's most compatible
        logger.warning(f"No streaming protocols available for {stream_key}, defaulting to HLS")
        return 'hls'

def get_stream_info(stream_key):
    """Get comprehensive information about a stream"""
    is_active = check_stream_active(stream_key)
    viewer_count = get_stream_viewers(stream_key) if is_active else 0
    protocols = get_available_protocols(stream_key)
    preferred_protocol = get_preferred_protocol(stream_key)
    
    return {
        'is_active': is_active,
        'viewer_count': viewer_count,
        'rtmp_url': get_rtmp_url(stream_key),
        'hls_url': get_hls_url(stream_key),
        'dash_url': get_dash_url(stream_key),
        'stream_key': stream_key,
        'available_protocols': protocols,
        'preferred_protocol': preferred_protocol
    }

def check_rtmp_connection(host, port=1935, timeout=3):
    """
    Check if RTMP server is accessible by attempting a socket connection
    Returns True if connection succeeds, False otherwise
    """
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception as e:
        logger.error(f"Error checking RTMP connection to {host}:{port}: {str(e)}")
        return False

def check_nginx_status():
    """
    Check if NGINX is running and properly configured for streaming
    Returns a dict with status information
    """
    status = {
        'nginx_running': False,
        'rtmp_module_loaded': False,
        'hls_enabled': False,
        'dash_enabled': False
    }
    
    # Check if we're in development mode
    if current_app.config.get('DEBUG', False):
        # In development mode, simulate NGINX as working
        logger.info("Development mode: Simulating NGINX is properly configured")
        for key in status:
            status[key] = True
        return status
    
    try:
        # Only in production, check actual NGINX status
        server = current_app.config.get('STREAM_SERVER', 'streamvibe.biz')
        nginx_status_url = f"http://{server}/nginx_status"
        response = requests.get(nginx_status_url, timeout=5)
        status['nginx_running'] = response.status_code == 200
        
        # Check RTMP module
        rtmp_port = current_app.config.get('RTMP_PORT', 1935)
        status['rtmp_module_loaded'] = check_rtmp_connection(server, int(rtmp_port))
        
        # Check for HLS/DASH directories
        # In a real environment, would check if the directories exist and are writable
        
        return status
    except Exception as e:
        logger.error(f"Error checking NGINX status: {str(e)}")
        # If we're in development mode, don't worry about it
        return status

def restart_stream(stream_key):
    """
    Attempt to restart a stream that has crashed or become unresponsive
    Returns True if restart was successful
    """
    try:
        logger.info(f"Attempting to restart stream {stream_key}")
        
        # Check if stream exists in our tracking
        if stream_key not in active_streams:
            logger.warning(f"Cannot restart non-existent stream {stream_key}")
            return False
            
        # Mark stream as inactive
        active_streams[stream_key]['active'] = False
        
        # Create a new session
        new_session = create_stream_session(stream_key)
        
        # Transfer any existing peers to the new session
        if 'peers' in active_streams[stream_key]:
            active_streams[stream_key]['peers'] = active_streams[stream_key].get('peers', {})
            
        logger.info(f"Successfully restarted stream {stream_key}")
        return True
    except Exception as e:
        logger.error(f"Failed to restart stream {stream_key}: {str(e)}")
        return False

def health_check_worker():
    """
    Background thread that periodically checks the health of all active streams
    and attempts to recover from failures automatically
    """
    # Import in function scope to avoid circular imports
    from flask import current_app
    import traceback
    
    logger.info("Stream health check worker started")
    
    # Use a try-finally to ensure we log if the thread stops
    try:
        while health_check_thread_running:
            try:
                # Check overall NGINX status first
                nginx_status = check_nginx_status()
                
                if not nginx_status['nginx_running']:
                    logger.warning("NGINX is not running! Streams will not function properly.")
                
                if not nginx_status['rtmp_module_loaded']:
                    logger.warning("NGINX RTMP module is not loaded! RTMP streaming will not work.")
                    
                # Check each active stream
                for stream_key in list(active_streams.keys()):
                    try:
                        if not active_streams[stream_key]['active']:
                            continue
                            
                        # Verify stream is still running
                        is_active = check_stream_active(stream_key)
                        
                        if not is_active:
                            logger.warning(f"Stream {stream_key} appears to be down, attempting recovery")
                            restart_success = restart_stream(stream_key)
                            if restart_success:
                                logger.info(f"Successfully restarted stream {stream_key}")
                            else:
                                logger.error(f"Failed to restart stream {stream_key}")
                    except Exception as stream_e:
                        # Use a separate try-except for each stream to prevent one bad stream from affecting others
                        logger.error(f"Error checking/restarting stream {stream_key}: {str(stream_e)}")
                        logger.debug(traceback.format_exc())
                        
                # Clean up inactive streams and peers
                try:
                    cleanup_inactive_streams()
                except Exception as clean_e:
                    logger.error(f"Error cleaning up inactive streams: {str(clean_e)}")
                    logger.debug(traceback.format_exc())
                    
            except Exception as e:
                logger.error(f"Unhandled error in health check worker: {str(e)}")
                logger.debug(traceback.format_exc())
            
            # Sleep until next check
            interval = get_health_check_interval()
            time.sleep(interval)
            
    except Exception as fatal_e:
        logger.critical(f"Fatal error in health check worker: {str(fatal_e)}")
        logger.debug(traceback.format_exc())
    finally:
        logger.info("Stream health check worker stopped")

def start_health_check(app=None):
    """
    Start the background health check thread if not already running
    If app is provided, it will be used to create an application context
    """
    global health_check_thread_running
    
    with health_check_lock:
        if health_check_thread_running:
            logger.info("Health check thread already running")
            return
        
        if app:
            # Define a wrapper function that provides app context to the worker
            def app_context_health_worker():
                with app.app_context():
                    health_check_worker()
                    
            # Set the flag to true to prevent multiple threads
            health_check_thread_running = True
            
            # Start the thread with the app context wrapper
            thread = threading.Thread(target=app_context_health_worker, daemon=True)
            thread.start()
            logger.info("Started stream health check thread with provided app context")
        else:
            # Original version without app context - may not work correctly
            health_check_thread_running = True
            thread = threading.Thread(target=health_check_worker, daemon=True)
            thread.start()
            logger.info("Started stream health check thread WITHOUT app context - may fail")

def stop_health_check():
    """Stop the background health check thread"""
    global health_check_thread_running
    
    with health_check_lock:
        if not health_check_thread_running:
            logger.info("Health check thread not running")
            return
            
        health_check_thread_running = False
        logger.info("Signaled stream health check thread to stop")
