import os
import uuid
import shutil
from datetime import datetime
from flask import current_app
import logging

logger = logging.getLogger(__name__)

def get_upload_path(filename, user_id):
    """
    Generate a unique path for uploaded files.
    Structure: uploads/[user_id]/[year]/[month]/[random_uuid]-[filename]
    """
    # Get current date for folder structure
    now = datetime.now()
    year = now.strftime('%Y')
    month = now.strftime('%m')
    
    # Create unique filename with UUID
    unique_filename = f"{uuid.uuid4()}-{filename}"
    
    # Create directory path
    path = os.path.join(
        current_app.config['UPLOAD_FOLDER'],
        str(user_id),
        year,
        month
    )
    
    # Create directories if they don't exist
    os.makedirs(path, exist_ok=True)
    
    # Return full path and relative path
    full_path = os.path.join(path, unique_filename)
    relative_path = os.path.join(str(user_id), year, month, unique_filename)
    
    return full_path, relative_path

def delete_file(file_path):
    """Delete a file from storage"""
    try:
        # Check if it's a directory
        if os.path.isdir(file_path):
            shutil.rmtree(file_path)
        else:
            os.remove(file_path)
        return True
    except Exception as e:
        logger.error(f"Error deleting file {file_path}: {str(e)}")
        return False

def get_available_space():
    """Get available disk space in MB"""
    try:
        stats = shutil.disk_usage(current_app.config['UPLOAD_FOLDER'])
        available_mb = stats.free / (1024 * 1024)  # Convert bytes to MB
        return round(available_mb, 2)
    except Exception as e:
        logger.error(f"Error getting available space: {str(e)}")
        return 0

def clean_old_files(days=30, min_free_space_mb=5000):
    """
    Clean up files older than specified days if free space is below threshold
    Returns the number of files removed
    """
    try:
        # Check if we need to clean up
        if get_available_space() > min_free_space_mb:
            return 0
        
        # Calculate cutoff date
        cutoff = datetime.now() - timedelta(days=days)
        uploads_dir = current_app.config['UPLOAD_FOLDER']
        
        count = 0
        for root, dirs, files in os.walk(uploads_dir):
            for file in files:
                file_path = os.path.join(root, file)
                file_time = datetime.fromtimestamp(os.path.getmtime(file_path))
                
                if file_time < cutoff:
                    if delete_file(file_path):
                        count += 1
        
        return count
    
    except Exception as e:
        logger.error(f"Error cleaning old files: {str(e)}")
        return 0
