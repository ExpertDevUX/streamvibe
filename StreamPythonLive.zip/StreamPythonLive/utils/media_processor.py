import os
import json
import subprocess
import tempfile
from flask import current_app
import logging

logger = logging.getLogger(__name__)

def process_media(file_path, media_type):
    """
    Process uploaded media file to prepare it for streaming.
    Returns the path to the processed file.
    """
    logger.debug(f"Processing media file: {file_path}")
    
    # Get the file name and extension
    file_name, file_ext = os.path.splitext(os.path.basename(file_path))
    
    # Create output directory for processed files
    output_dir = os.path.join(os.path.dirname(file_path), file_name)
    os.makedirs(output_dir, exist_ok=True)
    
    # Process based on media type
    if media_type == 'video':
        return process_video(file_path, output_dir)
    else:  # audio
        return process_audio(file_path, output_dir)

def process_video(file_path, output_dir):
    """Process video file to create multiple quality versions"""
    # Define quality presets
    qualities = [
        {'name': '1080p', 'resolution': '1920x1080', 'bitrate': '5000k'},
        {'name': '720p', 'resolution': '1280x720', 'bitrate': '2500k'},
        {'name': '480p', 'resolution': '854x480', 'bitrate': '1000k'},
        {'name': '360p', 'resolution': '640x360', 'bitrate': '500k'}
    ]
    
    # Output file path for master playlist
    master_playlist = os.path.join(output_dir, 'master.m3u8')
    
    # Create master playlist file
    with open(master_playlist, 'w') as f:
        f.write('#EXTM3U\n')
        f.write('#EXT-X-VERSION:3\n')
        
        for quality in qualities:
            try:
                output_file = os.path.join(output_dir, f"{quality['name']}.m3u8")
                
                # Create HLS segments for this quality
                cmd = [
                    current_app.config.get('FFMPEG_BINARY', 'ffmpeg'),
                    '-i', file_path,
                    '-c:v', 'libx264',
                    '-c:a', 'aac',
                    '-s', quality['resolution'],
                    '-b:v', quality['bitrate'],
                    '-g', '48',
                    '-keyint_min', '48',
                    '-sc_threshold', '0',
                    '-hls_time', '10',
                    '-hls_playlist_type', 'vod',
                    '-hls_segment_filename', os.path.join(output_dir, f"{quality['name']}_%03d.ts"),
                    output_file
                ]
                
                subprocess.run(cmd, check=True)
                
                # Add this quality to the master playlist
                f.write(f'#EXT-X-STREAM-INF:BANDWIDTH={(int(quality["bitrate"][:-1]) * 1000)},RESOLUTION={quality["resolution"]}\n')
                f.write(f'{quality["name"]}.m3u8\n')
                
            except subprocess.CalledProcessError as e:
                logger.error(f"Error processing video at quality {quality['name']}: {str(e)}")
                # Continue with other qualities if one fails
    
    return output_dir

def process_audio(file_path, output_dir):
    """Process audio file to create multiple quality versions"""
    # Define quality presets
    qualities = [
        {'name': 'high', 'bitrate': '192k'},
        {'name': 'medium', 'bitrate': '128k'},
        {'name': 'low', 'bitrate': '64k'}
    ]
    
    # Output file path for master playlist
    master_playlist = os.path.join(output_dir, 'master.m3u8')
    
    # Create master playlist file
    with open(master_playlist, 'w') as f:
        f.write('#EXTM3U\n')
        f.write('#EXT-X-VERSION:3\n')
        
        for quality in qualities:
            try:
                output_file = os.path.join(output_dir, f"{quality['name']}.m3u8")
                
                # Create HLS segments for this quality
                cmd = [
                    current_app.config.get('FFMPEG_BINARY', 'ffmpeg'),
                    '-i', file_path,
                    '-c:a', 'aac',
                    '-b:a', quality['bitrate'],
                    '-hls_time', '10',
                    '-hls_playlist_type', 'vod',
                    '-hls_segment_filename', os.path.join(output_dir, f"{quality['name']}_%03d.ts"),
                    output_file
                ]
                
                subprocess.run(cmd, check=True)
                
                # Add this quality to the master playlist
                f.write(f'#EXT-X-STREAM-INF:BANDWIDTH={(int(quality["bitrate"][:-1]) * 1000)}\n')
                f.write(f'{quality["name"]}.m3u8\n')
                
            except subprocess.CalledProcessError as e:
                logger.error(f"Error processing audio at quality {quality['name']}: {str(e)}")
                # Continue with other qualities if one fails
    
    return output_dir

def generate_thumbnail(video_path):
    """Generate a thumbnail for a video file"""
    try:
        # Get the file name and create thumbnail path
        file_name = os.path.splitext(os.path.basename(video_path))[0]
        thumbnail_path = os.path.join(os.path.dirname(video_path), f"{file_name}_thumbnail.jpg")
        
        # Extract a frame from the 5% mark of the video
        cmd = [
            current_app.config.get('FFMPEG_BINARY', 'ffmpeg'),
            '-i', video_path,
            '-ss', '00:00:05',
            '-vframes', '1',
            '-vf', 'scale=480:-1',
            thumbnail_path
        ]
        
        subprocess.run(cmd, check=True)
        return thumbnail_path
    
    except subprocess.CalledProcessError as e:
        logger.error(f"Error generating thumbnail: {str(e)}")
        return None

def get_media_duration(file_path):
    """Get the duration of a media file in seconds"""
    try:
        cmd = [
            current_app.config.get('FFPROBE_BINARY', 'ffprobe'),
            '-v', 'error',
            '-show_entries', 'format=duration',
            '-of', 'json',
            file_path
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
        
        # Extract duration and round to nearest second
        duration = round(float(data['format']['duration']))
        return duration
    
    except (subprocess.CalledProcessError, json.JSONDecodeError, KeyError) as e:
        logger.error(f"Error getting media duration: {str(e)}")
        return 0

def get_media_qualities(output_dir, media_type):
    """
    Get available quality options for a processed media file
    Returns a list of quality options
    """
    try:
        # Read the master playlist
        master_playlist = os.path.join(output_dir, 'master.m3u8')
        qualities = []
        
        with open(master_playlist, 'r') as f:
            lines = f.readlines()
            
            for i, line in enumerate(lines):
                if line.startswith('#EXT-X-STREAM-INF:'):
                    # Extract quality info from the line
                    info = line.strip().split(':')[1]
                    
                    # For video, resolution is included
                    if media_type == 'video' and 'RESOLUTION=' in info:
                        resolution = info.split('RESOLUTION=')[1].split(',')[0]
                        name = lines[i+1].strip().split('.')[0]  # Get the name from the next line
                        qualities.append({
                            'name': name,
                            'resolution': resolution,
                            'url': lines[i+1].strip()
                        })
                    # For audio, only bitrate is included
                    else:
                        name = lines[i+1].strip().split('.')[0]  # Get the name from the next line
                        qualities.append({
                            'name': name,
                            'url': lines[i+1].strip()
                        })
        
        return qualities
    
    except Exception as e:
        logger.error(f"Error getting media qualities: {str(e)}")
        return []
