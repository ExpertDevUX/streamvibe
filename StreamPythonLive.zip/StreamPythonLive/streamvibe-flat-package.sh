#!/bin/bash
# StreamVibe Ultra-Flat Packaging Script
# This script creates a single-folder package with no subdirectories

# Output directory and file
OUTPUT_DIR="streamvibe-flat"
OUTPUT_FILE="streamvibe-flat.zip"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print status
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Function to print success
print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Function to print error
print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Create output directory
print_status "Creating output directory..."
mkdir -p $OUTPUT_DIR

# Create all-in-one app.py
print_status "Creating all-in-one app.py..."
cat > $OUTPUT_DIR/app.py << 'EOF'
# StreamVibe All-in-One Flask Application
# This file contains all models, routes, and application logic in a single file

import os
import logging
import datetime
import uuid
import json
from flask import (
    Flask, render_template, redirect, url_for, flash, request, jsonify, 
    send_from_directory, abort, session, g
)
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_login import (
    LoginManager, UserMixin, login_user, logout_user, login_required, 
    current_user
)
from functools import wraps

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------
# APPLICATION SETUP
# ---------------------------------------------------------------------

# Base class for SQLAlchemy models
class Base(DeclarativeBase):
    pass

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "development-secret-key")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///streamvibe.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")
app.config["MAX_CONTENT_LENGTH"] = 1000 * 1024 * 1024  # 1GB max upload
app.config["DEBUG"] = True

# Make sure upload directories exist
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
os.makedirs(os.path.join(os.getcwd(), "hls"), exist_ok=True)
os.makedirs(os.path.join(os.getcwd(), "dash"), exist_ok=True)

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# ---------------------------------------------------------------------
# MODELS
# ---------------------------------------------------------------------

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    profile_description = db.Column(db.Text, nullable=True)
    avatar_path = db.Column(db.String(255), nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    media_items = db.relationship('Media', backref='owner', lazy='dynamic')
    streams = db.relationship('Stream', backref='owner', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Media(db.Model):
    __tablename__ = 'media'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=False)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    media_type = db.Column(db.String(20), nullable=False)  # video, audio
    duration = db.Column(db.Integer, nullable=True)  # Duration in seconds
    views = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Additional fields
    quality_options = db.Column(db.String(255), nullable=True)  # JSON string of available quality options
    tags = db.Column(db.String(255), nullable=True)  # Comma-separated tags
    
    def __repr__(self):
        return f'<Media {self.title}>'

class Stream(db.Model):
    __tablename__ = 'streams'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    stream_key = db.Column(db.String(64), unique=True, nullable=False)
    is_live = db.Column(db.Boolean, default=False)
    viewers = db.Column(db.Integer, default=0)
    started_at = db.Column(db.DateTime, nullable=True)
    ended_at = db.Column(db.DateTime, nullable=True)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Additional fields
    is_public = db.Column(db.Boolean, default=True)
    tags = db.Column(db.String(255), nullable=True)  # Comma-separated tags
    
    def __repr__(self):
        return f'<Stream {self.title}>'

class Comment(db.Model):
    __tablename__ = 'comments'
    
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    
    user = db.relationship('User', backref='comments')
    
    def __repr__(self):
        return f'<Comment {self.id}>'

class Analytics(db.Model):
    __tablename__ = 'analytics'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    views = db.Column(db.Integer, default=0)
    unique_viewers = db.Column(db.Integer, default=0)
    watch_time = db.Column(db.Integer, default=0)  # In seconds
    peak_viewers = db.Column(db.Integer, default=0)
    device_mobile = db.Column(db.Integer, default=0)  # Mobile viewers count
    device_desktop = db.Column(db.Integer, default=0)  # Desktop viewers count
    device_tablet = db.Column(db.Integer, default=0)  # Tablet viewers count
    device_other = db.Column(db.Integer, default=0)  # Other device viewers count
    avg_watch_duration = db.Column(db.Float, default=0.0)  # Average watch duration in seconds
    engagement_rate = db.Column(db.Float, default=0.0)  # Percentage of engagement (interactions/views)
    bounce_rate = db.Column(db.Float, default=0.0)  # Percentage of viewers who leave quickly
    country_data = db.Column(db.Text, nullable=True)  # JSON string of country distribution
    referrer_data = db.Column(db.Text, nullable=True)  # JSON string of traffic sources
    
    user = db.relationship('User', backref='analytics')
    
    def __repr__(self):
        return f'<Analytics {self.id}>'

class AnalyticsEvent(db.Model):
    """Detailed analytics events for user interactions"""
    __tablename__ = 'analytics_events'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    event_type = db.Column(db.String(50), nullable=False)  # view, play, pause, seek, end, etc.
    value = db.Column(db.Float, nullable=True)  # Custom value for event (e.g. seek position)
    session_id = db.Column(db.String(64), nullable=False)  # Unique viewer session
    device_type = db.Column(db.String(20), nullable=True)  # mobile, desktop, tablet, etc.
    browser = db.Column(db.String(50), nullable=True)  # Browser information
    os = db.Column(db.String(50), nullable=True)  # Operating system
    country_code = db.Column(db.String(2), nullable=True)  # ISO country code
    referrer = db.Column(db.String(255), nullable=True)  # Where the viewer came from
    
    user = db.relationship('User', backref='analytics_events')
    
    def __repr__(self):
        return f'<AnalyticsEvent {self.id}>'

# ---------------------------------------------------------------------
# HELPER FUNCTIONS
# ---------------------------------------------------------------------

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('You need admin privileges to access this page', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'flv', 'mkv', 'mp3', 'wav', 'ogg', 'aac', 'm4a'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_file_type(filename):
    VIDEO_EXTENSIONS = {'mp4', 'avi', 'mov', 'flv', 'mkv'}
    AUDIO_EXTENSIONS = {'mp3', 'wav', 'ogg', 'aac', 'm4a'}
    
    ext = filename.rsplit('.', 1)[1].lower()
    if ext in VIDEO_EXTENSIONS:
        return 'video'
    elif ext in AUDIO_EXTENSIONS:
        return 'audio'
    else:
        return 'unknown'

def record_analytics_event(event_type, value=None, media_id=None, stream_id=None):
    if not current_user.is_authenticated:
        return
        
    # Generate or retrieve session ID from cookie
    session_id = request.cookies.get('session_id')
    if not session_id:
        session_id = str(uuid.uuid4())
        
    # Get device information from user agent
    user_agent = request.user_agent
    device_type = 'mobile' if user_agent.platform in ['android', 'iphone', 'ipad'] else 'desktop'
    browser = user_agent.browser
    os = user_agent.platform
    
    # Create analytics event
    event = AnalyticsEvent(
        user_id=current_user.id,
        media_id=media_id,
        stream_id=stream_id,
        event_type=event_type,
        value=value,
        session_id=session_id,
        device_type=device_type,
        browser=browser,
        os=os,
        referrer=request.referrer
    )
    
    db.session.add(event)
    db.session.commit()
    
    # Update daily analytics
    today = datetime.date.today()
    
    # Get existing analytics or create new
    analytics = None
    if media_id:
        analytics = Analytics.query.filter_by(
            date=today, 
            user_id=current_user.id,
            media_id=media_id
        ).first()
    elif stream_id:
        analytics = Analytics.query.filter_by(
            date=today, 
            user_id=current_user.id,
            stream_id=stream_id
        ).first()
        
    if not analytics:
        analytics = Analytics(
            date=today,
            user_id=current_user.id,
            media_id=media_id,
            stream_id=stream_id
        )
        db.session.add(analytics)
        
    # Update analytics based on event type
    if event_type == 'view':
        analytics.views += 1
    elif event_type == 'play':
        pass
    elif event_type == 'end':
        if value:  # value is watch duration
            analytics.watch_time += int(value)
            
    db.session.commit()
    
    return session_id

# ---------------------------------------------------------------------
# ROUTES: AUTH
# ---------------------------------------------------------------------

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if not username or not password:
            flash('Please enter both username and password', 'danger')
            return render_template('login.html')
            
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            login_user(user)
            flash('Logged in successfully!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
        
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Check if username or email already exists
        if User.query.filter_by(username=username).first():
            flash('Username already exists', 'danger')
            return render_template('register.html')
            
        if User.query.filter_by(email=email).first():
            flash('Email already exists', 'danger')
            return render_template('register.html')
        
        # Create new user
        user = User(
            username=username,
            email=email,
            created_at=datetime.datetime.utcnow()
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('login'))

# ---------------------------------------------------------------------
# ROUTES: MAIN
# ---------------------------------------------------------------------

@app.route('/')
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

# ---------------------------------------------------------------------
# ROUTES: MEDIA
# ---------------------------------------------------------------------

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        file = request.files.get('media_file')
        
        if not title or not file:
            flash('Title and file are required', 'danger')
            return render_template('upload.html')
            
        if not allowed_file(file.filename):
            flash('File type not allowed', 'danger')
            return render_template('upload.html')
            
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], str(uuid.uuid4()) + '_' + filename)
        
        # Determine media type from file extension
        media_type = get_file_type(filename)
        
        # Save the file
        file.save(file_path)
        
        # Create media record
        media = Media(
            title=title,
            description=description,
            file_path=file_path,
            media_type=media_type,
            user_id=current_user.id
        )
        
        db.session.add(media)
        db.session.commit()
        
        flash('Media uploaded successfully!', 'success')
        return redirect(url_for('dashboard'))
        
    return render_template('upload.html')

@app.route('/media/<int:media_id>')
def view_media(media_id):
    media = Media.query.get_or_404(media_id)
    
    # Record analytics event
    if current_user.is_authenticated:
        record_analytics_event('view', media_id=media_id)
        
    # Increment view count
    media.views += 1
    db.session.commit()
    
    return render_template('view_media.html', media=media)

@app.route('/media/<int:media_id>/file')
def get_media_file(media_id):
    media = Media.query.get_or_404(media_id)
    return send_from_directory(os.path.dirname(media.file_path), os.path.basename(media.file_path))

# ---------------------------------------------------------------------
# ROUTES: STREAMING
# ---------------------------------------------------------------------

@app.route('/streams')
def list_streams():
    streams = Stream.query.filter_by(is_live=True).all()
    return render_template('streams.html', streams=streams)

@app.route('/stream/create', methods=['GET', 'POST'])
@login_required
def create_stream():
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        
        if not title:
            flash('Title is required', 'danger')
            return render_template('create_stream.html')
            
        # Generate a unique stream key
        stream_key = str(uuid.uuid4())
        
        # Create stream record
        stream = Stream(
            title=title,
            description=description,
            stream_key=stream_key,
            user_id=current_user.id
        )
        
        db.session.add(stream)
        db.session.commit()
        
        flash('Stream created successfully!', 'success')
        return redirect(url_for('view_stream', stream_id=stream.id))
        
    return render_template('create_stream.html')

@app.route('/stream/<int:stream_id>')
def view_stream(stream_id):
    stream = Stream.query.get_or_404(stream_id)
    
    # Record analytics event
    if current_user.is_authenticated:
        record_analytics_event('view', stream_id=stream_id)
        
    # Increment view count if stream is live
    if stream.is_live:
        stream.viewers += 1
        db.session.commit()
    
    return render_template('view_stream.html', stream=stream)

@app.route('/stream/auth')
def auth_stream():
    # RTMP authentication endpoint
    stream_key = request.args.get('name')
    if not stream_key:
        return '', 403
        
    stream = Stream.query.filter_by(stream_key=stream_key).first()
    if not stream:
        return '', 403
        
    # Mark stream as live
    stream.is_live = True
    stream.started_at = datetime.datetime.utcnow()
    db.session.commit()
    
    return '', 200

@app.route('/stream/done')
def done_stream():
    # RTMP done callback
    stream_key = request.args.get('name')
    if not stream_key:
        return '', 200
        
    stream = Stream.query.filter_by(stream_key=stream_key).first()
    if stream:
        stream.is_live = False
        stream.ended_at = datetime.datetime.utcnow()
        db.session.commit()
    
    return '', 200

# ---------------------------------------------------------------------
# ROUTES: ADMIN
# ---------------------------------------------------------------------

@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    users = User.query.all()
    return render_template('admin_users.html', users=users)

@app.route('/admin/media')
@login_required
@admin_required
def admin_media():
    media = Media.query.all()
    return render_template('admin_media.html', media=media)

@app.route('/admin/streams')
@login_required
@admin_required
def admin_streams():
    streams = Stream.query.all()
    return render_template('admin_streams.html', streams=streams)

# ---------------------------------------------------------------------
# ROUTES: ANALYTICS
# ---------------------------------------------------------------------

@app.route('/analytics')
@login_required
def user_analytics():
    media_analytics = Analytics.query.filter_by(user_id=current_user.id).\
                     filter(Analytics.media_id.isnot(None)).all()
    stream_analytics = Analytics.query.filter_by(user_id=current_user.id).\
                      filter(Analytics.stream_id.isnot(None)).all()
    
    return render_template('analytics.html', 
                         media_analytics=media_analytics, 
                         stream_analytics=stream_analytics)

@app.route('/api/analytics/record', methods=['POST'])
def record_analytics_api():
    if not current_user.is_authenticated:
        return jsonify({'error': 'Not authenticated'}), 403
        
    data = request.json
    event_type = data.get('event_type')
    value = data.get('value')
    media_id = data.get('media_id')
    stream_id = data.get('stream_id')
    
    if not event_type:
        return jsonify({'error': 'Missing event_type parameter'}), 400
        
    session_id = record_analytics_event(event_type, value, media_id, stream_id)
    
    response = jsonify({'success': True, 'session_id': session_id})
    if session_id and not request.cookies.get('session_id'):
        response.set_cookie('session_id', session_id, max_age=60*60*24*30)  # 30 days
        
    return response

# ---------------------------------------------------------------------
# STATIC FILES
# ---------------------------------------------------------------------

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory('uploads', filename)

# ---------------------------------------------------------------------
# ERROR HANDLERS
# ---------------------------------------------------------------------

@app.errorhandler(404)
def page_not_found(e):
    return render_template('error.html', error_code=404, error_message='Page not found'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('error.html', error_code=500, error_message='Internal server error'), 500

# ---------------------------------------------------------------------
# DATABASE INITIALIZATION
# ---------------------------------------------------------------------

@app.before_first_request
def initialize_database():
    db.create_all()
    
    # Check if admin exists
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        admin = User(username='admin', email='admin@streamvibe.biz', is_admin=True)
        admin.set_password('admin123')
        db.session.add(admin)
        db.session.commit()
        logger.info("Created admin user")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
EOF

# Create main.py
print_status "Creating main.py..."
cat > $OUTPUT_DIR/main.py << 'EOF'
from app import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
EOF

# Create base HTML template
print_status "Creating base HTML template..."
cat > $OUTPUT_DIR/base.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}StreamVibe{% endblock %}</title>
    <link rel="stylesheet" href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css">
    <style>
        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .main-content {
            flex: 1;
        }
        .navbar-brand {
            font-weight: bold;
            background: linear-gradient(45deg, #9370DB, #4169E1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .footer {
            padding: 1rem 0;
            margin-top: auto;
        }
    </style>
    {% block styles %}{% endblock %}
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">StreamVibe</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    {% if current_user.is_authenticated %}
                    <li class="nav-item">
                        <a class="nav-link" href="/dashboard">Dashboard</a>
                    </li>
                    {% if current_user.is_admin %}
                    <li class="nav-item">
                        <a class="nav-link" href="/admin">Admin</a>
                    </li>
                    {% endif %}
                    {% endif %}
                </ul>
                <ul class="navbar-nav">
                    {% if current_user.is_authenticated %}
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown">
                            {{ current_user.username }}
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="/profile">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/logout">Logout</a></li>
                        </ul>
                    </li>
                    {% else %}
                    <li class="nav-item">
                        <a class="nav-link" href="/login">Login</a>
                    </li>
                    {% endif %}
                </ul>
            </div>
        </div>
    </nav>

    <div class="container main-content py-4">
        {% with messages = get_flashed_messages(with_categories=true) %}
        {% if messages %}
            {% for category, message in messages %}
            <div class="alert alert-{{ category }} alert-dismissible fade show" role="alert">
                {{ message }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            {% endfor %}
        {% endif %}
        {% endwith %}
        
        {% block content %}{% endblock %}
    </div>

    <footer class="footer bg-dark text-light">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; 2025 StreamVibe. All rights reserved.</p>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    {% block scripts %}{% endblock %}
</body>
</html>
EOF

# Create login HTML template
print_status "Creating login HTML template..."
cat > $OUTPUT_DIR/login.html << 'EOF'
{% extends "base.html" %}

{% block title %}Login - StreamVibe{% endblock %}

{% block content %}
<div class="row">
    <div class="col-md-6 mx-auto">
        <div class="card">
            <div class="card-header">
                <h4 class="mb-0">Login</h4>
            </div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember">Remember me</label>
                    </div>
                    <button type="submit" class="btn btn-primary">Login</button>
                </form>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOF

# Create dashboard HTML template
print_status "Creating dashboard HTML template..."
cat > $OUTPUT_DIR/dashboard.html << 'EOF'
{% extends "base.html" %}

{% block title %}Dashboard - StreamVibe{% endblock %}

{% block content %}
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Dashboard</h1>
            <div>
                <a href="/stream/create" class="btn btn-primary me-2">Go Live</a>
                <a href="/upload" class="btn btn-success">Upload Media</a>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Your Streams</h5>
                        <p class="card-text">Manage your live streams</p>
                        <a href="/streams" class="btn btn-primary">View Streams</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Your Videos</h5>
                        <p class="card-text">Manage your uploaded videos</p>
                        <a href="/videos" class="btn btn-primary">View Videos</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Analytics</h5>
                        <p class="card-text">View your stream and video analytics</p>
                        <a href="/analytics" class="btn btn-primary">View Analytics</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOF

# Create admin dashboard HTML template
print_status "Creating admin dashboard HTML template..."
cat > $OUTPUT_DIR/admin_dashboard.html << 'EOF'
{% extends "base.html" %}

{% block title %}Admin Dashboard - StreamVibe{% endblock %}

{% block content %}
<div class="row">
    <div class="col-12">
        <h1>Admin Dashboard</h1>
        
        <div class="row mt-4">
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Users</h5>
                        <p class="card-text">Manage user accounts</p>
                        <a href="/admin/users" class="btn btn-primary">Manage Users</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Streams</h5>
                        <p class="card-text">Manage live streams</p>
                        <a href="/admin/streams" class="btn btn-primary">Manage Streams</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Videos</h5>
                        <p class="card-text">Manage uploaded videos</p>
                        <a href="/admin/media" class="btn btn-primary">Manage Videos</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-3">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">System</h5>
                        <p class="card-text">System configuration</p>
                        <a href="/admin/system" class="btn btn-primary">System Settings</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
EOF

# Create installation script
print_status "Creating installation script..."
cat > $OUTPUT_DIR/install.sh << 'EOF'
#!/bin/bash
# Ultra-Simple StreamVibe Installation Script

DOMAIN_NAME="streamvibe.biz"
DB_NAME="streamvibe"
DB_USER="streamvibe_user"
DB_PASS=$(openssl rand -base64 12 | tr -d "=+/" | cut -c1-16)

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root"
    exit 1
fi

# Install dependencies
apt update
apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib \
    ffmpeg libnginx-mod-rtmp

# Setup database
systemctl start postgresql
systemctl enable postgresql

# Create database and user
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" || echo "User may already exist"
sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;" || echo "Database may already exist"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

# Setup virtual environment
python3 -m venv venv
source venv/bin/activate
pip install Flask==2.3.3 flask-login==0.6.2 flask-sqlalchemy==3.1.1 flask-wtf==1.2.1
pip install werkzeug==2.3.7 gunicorn==23.0.0 psycopg2-binary==2.9.9 email-validator==2.1.0

# Create environment file
cat > .env << ENVEOF
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
SESSION_SECRET=$(openssl rand -base64 32)
STREAM_SERVER=$DOMAIN_NAME
DOMAIN_NAME=$DOMAIN_NAME
RTMP_SERVER=rtmp://$DOMAIN_NAME/live
ENVEOF

# Create system service
cat > /etc/systemd/system/streamvibe.service << SVCEOF
[Unit]
Description=StreamVibe Gunicorn Service
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=$(pwd)
Environment="PATH=$(pwd)/venv/bin"
EnvironmentFile=$(pwd)/.env
ExecStart=$(pwd)/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
Restart=always

[Install]
WantedBy=multi-user.target
SVCEOF

# Set permissions
chown -R www-data:www-data .
mkdir -p uploads hls dash
chmod -R 755 .

# Configure nginx
cat > /etc/nginx/nginx.conf << NGINXEOF
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

# RTMP Configuration
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path $(pwd)/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path $(pwd)/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;
    
    # Virtual Host Configs
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
NGINXEOF

# Create site config
cat > /etc/nginx/sites-available/streamvibe << SITEEOF
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /static {
        alias $(pwd)/static;
        expires 30d;
    }

    location /uploads {
        alias $(pwd)/uploads;
        expires 30d;
    }
    
    location /hls {
        alias $(pwd)/hls;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
    }
    
    location /dash {
        alias $(pwd)/dash;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/dash+xml mpd;
        }
    }
}
SITEEOF

# Enable site configuration
ln -sf /etc/nginx/sites-available/streamvibe /etc/nginx/sites-enabled/
if [ -f /etc/nginx/sites-enabled/default ]; then
    rm /etc/nginx/sites-enabled/default
fi

# Create templates directory and copy HTML files
mkdir -p templates
mv *.html templates/

# Start services
systemctl daemon-reload
systemctl restart nginx
systemctl enable streamvibe
systemctl start streamvibe

echo "StreamVibe installation complete!"
echo "Visit http://$DOMAIN_NAME"
echo "Login with admin/admin123"
EOF

# Create README.md
print_status "Creating README.md..."
cat > $OUTPUT_DIR/README.md << 'EOF'
# StreamVibe

Ultra-simple single-folder deployment of the StreamVibe streaming platform.

## Installation

1. Copy all files to your server
2. Make the installer executable: `chmod +x install.sh`
3. Run the installer: `sudo ./install.sh`
4. Access at http://your-domain (Login with admin/admin123)

## Features

- Video uploads and playback
- Live streaming with RTMP
- User management
- Admin dashboard
- Analytics tracking

## RTMP Streaming

Use OBS Studio with:
- URL: rtmp://your-domain/live
- Stream Key: (Get from dashboard)
EOF

# Make the install script executable
chmod +x $OUTPUT_DIR/install.sh

# Create a zip file
print_status "Creating zip file..."
zip -r $OUTPUT_FILE $OUTPUT_DIR

print_success "StreamVibe ultra-flat package created successfully!"
print_success "Directory: $OUTPUT_DIR"
print_success "Zip file: $OUTPUT_FILE"
print_status "To install, extract the zip file and run: sudo ./install.sh"