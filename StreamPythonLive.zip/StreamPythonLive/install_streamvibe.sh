#!/bin/bash
# StreamVibe Automated Installation Script
# This script installs StreamVibe and all its dependencies on a VPS

# Set default configuration (change these as needed)
DOMAIN_NAME="streamvibe.biz"
INSTALL_DIR="/var/www/streamvibe"
DB_NAME="streamvibe"
DB_USER="streamvibe_user"
DB_PASS=$(openssl rand -base64 12 | tr -d "=+/" | cut -c1-16)
SESSION_SECRET=$(openssl rand -base64 32 | tr -d "=+/" | cut -c1-32)
ADMIN_USER="admin"
ADMIN_PASS=$(openssl rand -base64 12 | tr -d "=+/" | cut -c1-12)
ADMIN_EMAIL="admin@streamvibe.biz"

# Colors for better output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# Function to print status
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

# Function to print success
print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

# Function to print warning
print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Function to print error
print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check for root
check_root() {
    if [ "$EUID" -ne 0 ]; then
        print_error "This script must be run as root"
        exit 1
    fi
}

# Step 1: Update the system
update_system() {
    print_status "Updating system packages..."
    apt update && apt upgrade -y
    print_success "System updated successfully"
}

# Step 2: Install dependencies
install_dependencies() {
    print_status "Installing required dependencies..."
    apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib \
        ffmpeg build-essential libssl-dev libffi-dev python3-dev \
        curl wget git unzip certbot python3-certbot-nginx
        
    # Install NGINX RTMP module
    print_status "Installing NGINX RTMP module..."
    apt install -y libnginx-mod-rtmp || {
        print_warning "RTMP module not available in package manager. Compiling from source..."
        
        # Build NGINX with RTMP from source if package is not available
        cd /tmp
        apt install -y build-essential libpcre3-dev libssl-dev zlib1g-dev
        wget -q https://nginx.org/download/nginx-1.20.1.tar.gz
        wget -q https://github.com/arut/nginx-rtmp-module/archive/master.zip
        unzip -q master.zip
        tar -zxf nginx-1.20.1.tar.gz
        cd nginx-1.20.1
        ./configure --with-http_ssl_module --add-module=../nginx-rtmp-module-master
        make -j$(nproc)
        make install
        
        # Create systemd service for NGINX
        cat > /etc/systemd/system/nginx.service << EOL
[Unit]
Description=nginx - high performance web server
Documentation=https://nginx.org/en/docs/
After=network-online.target remote-fs.target nss-lookup.target
Wants=network-online.target

[Service]
Type=forking
PIDFile=/var/run/nginx.pid
ExecStartPre=/usr/local/nginx/sbin/nginx -t -c /usr/local/nginx/conf/nginx.conf
ExecStart=/usr/local/nginx/sbin/nginx -c /usr/local/nginx/conf/nginx.conf
ExecReload=/bin/kill -s HUP \$MAINPID
ExecStop=/bin/kill -s TERM \$MAINPID

[Install]
WantedBy=multi-user.target
EOL
        systemctl daemon-reload
        systemctl enable nginx
    }
    
    print_success "All dependencies installed successfully"
}

# Step 3: Configure firewall
configure_firewall() {
    print_status "Configuring firewall..."
    
    # Check if UFW is installed
    if command -v ufw >/dev/null 2>&1; then
        ufw allow 22/tcp
        ufw allow 80/tcp
        ufw allow 443/tcp
        ufw allow 1935/tcp  # RTMP port
        
        # Enable UFW if not already enabled
        if ! ufw status | grep -q "Status: active"; then
            print_warning "UFW is not enabled. Enable it after installation to avoid losing SSH connectivity."
            print_warning "Run: ufw enable"
        fi
        
        print_success "Firewall configured"
    else
        print_warning "UFW not found. Please install and configure a firewall manually after installation."
    fi
}

# Step 4: Set up PostgreSQL
setup_database() {
    print_status "Setting up PostgreSQL database..."
    
    systemctl start postgresql
    systemctl enable postgresql
    
    # Create database and user
    sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASS';" || print_warning "User creation failed, may already exist"
    sudo -u postgres psql -c "CREATE DATABASE $DB_NAME;" || print_warning "Database creation failed, may already exist"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"
    
    print_success "PostgreSQL database set up successfully"
    print_status "Database credentials:"
    print_status "  Database: $DB_NAME"
    print_status "  User: $DB_USER"
    print_status "  Password: $DB_PASS"
}

# Step 5: Create directory structure
create_directories() {
    print_status "Creating directory structure..."
    
    mkdir -p $INSTALL_DIR
    mkdir -p $INSTALL_DIR/hls
    mkdir -p $INSTALL_DIR/dash
    mkdir -p $INSTALL_DIR/uploads
    mkdir -p $INSTALL_DIR/logs
    mkdir -p $INSTALL_DIR/static
    
    # Set proper permissions
    if getent passwd www-data >/dev/null; then
        chown -R www-data:www-data $INSTALL_DIR
    else
        chown -R nginx:nginx $INSTALL_DIR
    fi
    
    chmod -R 755 $INSTALL_DIR
    
    print_success "Directory structure created successfully"
}

# Step 6: Configure NGINX
configure_nginx() {
    print_status "Configuring NGINX..."
    
    # Backup existing NGINX configuration
    if [ -f /etc/nginx/nginx.conf ]; then
        cp /etc/nginx/nginx.conf /etc/nginx/nginx.conf.backup
    fi
    
    # Create NGINX configuration with RTMP module
    cat > /etc/nginx/nginx.conf << EOL
user www-data;
worker_processes auto;
pid /run/nginx.pid;
include /etc/nginx/modules-enabled/*.conf;

events {
    worker_connections 1024;
}

# RTMP Configuration
rtmp {
    server {
        listen 1935;
        chunk_size 4096;
        
        application live {
            live on;
            record off;
            
            # HLS
            hls on;
            hls_path $INSTALL_DIR/hls;
            hls_fragment 4;
            hls_playlist_length 60;
            
            # DASH
            dash on;
            dash_path $INSTALL_DIR/dash;
            dash_fragment 4;
            dash_playlist_length 60;
            
            # Authentication
            on_publish http://127.0.0.1:5000/stream/auth;
            on_publish_done http://127.0.0.1:5000/stream/done;
        }
    }
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    server_tokens off;
    
    include /etc/nginx/conf.d/*.conf;
    include /etc/nginx/sites-enabled/*;
}
EOL
    
    # Create site configuration
    mkdir -p /etc/nginx/sites-available /etc/nginx/sites-enabled
    
    cat > /etc/nginx/sites-available/streamvibe << EOL
server {
    listen 80;
    server_name $DOMAIN_NAME www.$DOMAIN_NAME;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }

    location /static {
        alias $INSTALL_DIR/static;
        expires 30d;
    }

    location /uploads {
        alias $INSTALL_DIR/uploads;
        expires 30d;
    }
    
    location /hls {
        alias $INSTALL_DIR/hls;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/vnd.apple.mpegurl m3u8;
            video/mp2t ts;
        }
    }
    
    location /dash {
        alias $INSTALL_DIR/dash;
        add_header Cache-Control no-cache;
        add_header 'Access-Control-Allow-Origin' '*' always;
        
        types {
            application/dash+xml mpd;
        }
    }
}
EOL
    
    # Enable the site and disable default
    ln -sf /etc/nginx/sites-available/streamvibe /etc/nginx/sites-enabled/
    if [ -f /etc/nginx/sites-enabled/default ]; then
        rm /etc/nginx/sites-enabled/default
    fi
    
    # Test NGINX configuration
    nginx -t
    
    # Restart NGINX
    systemctl restart nginx
    systemctl enable nginx
    
    print_success "NGINX configured successfully"
}

# Step 7: Install StreamVibe application
install_streamvibe() {
    print_status "Installing StreamVibe application..."
    
    # Check if git repository argument was provided
    if [ -n "$1" ]; then
        git clone $1 $INSTALL_DIR || {
            print_error "Failed to clone repository: $1"
            print_status "Continuing with manual file transfer..."
        }
    else
        print_warning "No repository URL provided. Please transfer StreamVibe files to $INSTALL_DIR manually after installation."
        print_status "Example: git clone https://github.com/yourusername/streamvibe.git $INSTALL_DIR"
    fi
    
    # Create virtual environment
    cd $INSTALL_DIR
    python3 -m venv venv
    source venv/bin/activate
    
    # Install Python dependencies
    pip install --upgrade pip
    pip install flask flask-login flask-migrate flask-sqlalchemy flask-wtf gunicorn
    pip install psycopg2-binary python-dotenv requests sqlalchemy werkzeug email-validator
    
    # Create .env file
    cat > $INSTALL_DIR/.env << EOL
DATABASE_URL=postgresql://$DB_USER:$DB_PASS@localhost:5432/$DB_NAME
SESSION_SECRET=$SESSION_SECRET
STREAM_SERVER=$DOMAIN_NAME
DOMAIN_NAME=$DOMAIN_NAME
RTMP_SERVER=rtmp://$DOMAIN_NAME/live
HLS_SERVER=https://$DOMAIN_NAME/hls
DASH_SERVER=https://$DOMAIN_NAME/dash
EOL
    
    # Create a simple default main.py if it doesn't exist
    if [ ! -f $INSTALL_DIR/main.py ]; then
        print_warning "main.py not found. Creating a basic placeholder file."
        cat > $INSTALL_DIR/main.py << EOL
from app import app

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
EOL
    fi
    
    # Create a simple app.py if it doesn't exist
    if [ ! -f $INSTALL_DIR/app.py ]; then
        print_warning "app.py not found. Creating a basic placeholder file."
        cat > $INSTALL_DIR/app.py << EOL
import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from flask_login import LoginManager
import datetime

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Base class for SQLAlchemy models
class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy
db = SQLAlchemy(model_class=Base)

# Initialize Flask application
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///streamvibe.db")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Explicitly enable debug mode for development
app.config["DEBUG"] = True

# Configure upload path
app.config["UPLOAD_FOLDER"] = os.path.join(os.getcwd(), "uploads")
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

# Initialize the database
db.init_app(app)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'

# Create a simple route
@app.route('/')
def home():
    return 'StreamVibe is running! Set up your application files to continue.'

# Load user from session
@login_manager.user_loader
def load_user(user_id):
    try:
        from models import User
        return User.query.get(int(user_id))
    except:
        return None

with app.app_context():
    try:
        db.create_all()
    except Exception as e:
        app.logger.error(f"Database setup error: {e}")
EOL
    fi
    
    # Create a basic models.py file if it doesn't exist
    if [ ! -f $INSTALL_DIR/models.py ]; then
        print_warning "models.py not found. Creating a basic placeholder file."
        cat > $INSTALL_DIR/models.py << EOL
import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    profile_description = db.Column(db.Text, nullable=True)
    avatar_path = db.Column(db.String(255), nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'
EOL
    fi
    
    # Create a basic create_admin.py script if it doesn't exist
    if [ ! -f $INSTALL_DIR/create_admin.py ]; then
        print_warning "create_admin.py not found. Creating a basic admin creation script."
        cat > $INSTALL_DIR/create_admin.py << EOL
import os
import sys
import datetime
from werkzeug.security import generate_password_hash
from sqlalchemy import create_engine, Column, Integer, String, Text, Boolean, DateTime, ForeignKey, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

# Define database URL
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///instance/streamvibe.db")

# Create engine and session
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
session = Session()
Base = declarative_base()

# Define User model
class User(Base):
    __tablename__ = 'users'
    
    id = Column(Integer, primary_key=True)
    username = Column(String(64), unique=True, nullable=False)
    email = Column(String(120), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    profile_description = Column(Text, nullable=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

# Create admin function
def create_admin_account(username="admin", email="admin@streamvibe.com", password="admin123"):
    # Check if is_admin column exists and add it if necessary
    try:
        # Try to access is_admin column
        session.query(User.is_admin).first()
        print("is_admin column exists")
    except Exception as e:
        print(f"Adding is_admin column to users table: {e}")
        try:
            connection = engine.connect()
            connection.execute(text("ALTER TABLE users ADD COLUMN is_admin BOOLEAN DEFAULT 0"))
            connection.close()
            print("Added is_admin column successfully")
        except Exception as e:
            print(f"Error adding is_admin column: {e}")
            # Try to create tables if they don't exist
            Base.metadata.create_all(engine)
            print("Created/updated database tables")

    # Check if admin exists
    existing_admin = session.query(User).filter_by(is_admin=True).first()
    if existing_admin:
        print(f"Admin already exists: {existing_admin.username}")
        return
        
    # Check if username exists
    existing_user = session.query(User).filter_by(username=username).first()
    if existing_user:
        print(f"Username '{username}' already exists. Choose another username.")
        return
        
    # Create admin user
    admin = User(
        username=username,
        email=email,
        password_hash=generate_password_hash(password),
        is_admin=True
    )
    
    try:
        session.add(admin)
        session.commit()
        print(f"Admin account created successfully!")
        print(f"Username: {username}")
        print(f"Password: {password}")
    except Exception as e:
        session.rollback()
        print(f"Error creating admin account: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 3:
        create_admin_account(sys.argv[1], sys.argv[2], sys.argv[3])
    else:
        create_admin_account()
EOL
    fi
    
    # Create systemd service
    cat > /etc/systemd/system/streamvibe.service << EOL
[Unit]
Description=StreamVibe Gunicorn Service
After=network.target postgresql.service

[Service]
User=www-data
Group=www-data
WorkingDirectory=$INSTALL_DIR
Environment="PATH=$INSTALL_DIR/venv/bin"
EnvironmentFile=$INSTALL_DIR/.env
ExecStart=$INSTALL_DIR/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 4 main:app
Restart=always

[Install]
WantedBy=multi-user.target
EOL
    
    # Adjust user if www-data does not exist
    if ! getent passwd www-data >/dev/null; then
        user=$(getent passwd | grep nginx | cut -d: -f1)
        if [ -n "$user" ]; then
            sed -i "s/User=www-data/User=$user/g" /etc/systemd/system/streamvibe.service
            sed -i "s/Group=www-data/Group=$user/g" /etc/systemd/system/streamvibe.service
        else
            print_warning "Neither www-data nor nginx user found. Using root for service."
            sed -i "s/User=www-data/User=root/g" /etc/systemd/system/streamvibe.service
            sed -i "s/Group=www-data/Group=root/g" /etc/systemd/system/streamvibe.service
        fi
    fi
    
    # Reload systemd and enable service
    systemctl daemon-reload
    systemctl enable streamvibe
    
    print_success "StreamVibe application installed successfully"
}

# Step 8: Initialize database and create admin user
initialize_database() {
    print_status "Initializing database and creating admin user..."
    
    cd $INSTALL_DIR
    source venv/bin/activate
    
    # Create database tables
    python -c "from app import db; db.create_all()" || {
        print_error "Failed to create database tables"
        print_warning "You may need to create database tables manually"
    }
    
    # Run database migrations if available
    if [ -f $INSTALL_DIR/run_analytics_migration.py ]; then
        python run_analytics_migration.py || {
            print_warning "Failed to run analytics migration"
        }
    fi
    
    # Create admin user
    python create_admin.py "$ADMIN_USER" "$ADMIN_EMAIL" "$ADMIN_PASS" || {
        print_error "Failed to create admin user"
        print_warning "You may need to create admin user manually"
    }
    
    print_success "Database initialized with admin user"
    print_status "Admin credentials:"
    print_status "  Username: $ADMIN_USER"
    print_status "  Email: $ADMIN_EMAIL"
    print_status "  Password: $ADMIN_PASS"
}

# Step 9: Set up SSL (optional)
setup_ssl() {
    print_status "Setting up SSL with Let's Encrypt..."
    
    # Check if domain resolves to this server
    ip=$(curl -s https://ipinfo.io/ip)
    domain_ip=$(dig +short $DOMAIN_NAME)
    
    if [ "$ip" != "$domain_ip" ]; then
        print_warning "The domain $DOMAIN_NAME does not point to this server's IP ($ip)."
        print_warning "SSL setup skipped. You need to update your DNS records and then run:"
        print_status "certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME"
        return 1
    fi
    
    # Install SSL certificate
    certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME --non-interactive --agree-tos --email $ADMIN_EMAIL --redirect || {
        print_error "Failed to set up SSL"
        print_warning "You can set up SSL manually after DNS is properly configured:"
        print_status "certbot --nginx -d $DOMAIN_NAME -d www.$DOMAIN_NAME"
        return 1
    }
    
    print_success "SSL certificates installed successfully"
    return 0
}

# Step 10: Create completion report
create_report() {
    print_status "Creating installation report..."
    
    # Create report
    mkdir -p $INSTALL_DIR/install-report
    
    cat > $INSTALL_DIR/install-report/summary.txt << EOL
StreamVibe Installation Summary
==============================
Date: $(date)
Server IP: $(curl -s https://ipinfo.io/ip)
Domain: $DOMAIN_NAME

Installation Details:
-------------------
Installation Directory: $INSTALL_DIR
Database Name: $DB_NAME
Database User: $DB_USER
Database Password: $DB_PASS

Admin Account:
------------
Username: $ADMIN_USER
Email: $ADMIN_EMAIL
Password: $ADMIN_PASS

Access URLs:
----------
Website: http://$DOMAIN_NAME (or https://$DOMAIN_NAME if SSL is set up)
Admin Login: http://$DOMAIN_NAME/login

RTMP Streaming:
-------------
RTMP URL: rtmp://$DOMAIN_NAME/live
Stream Key: (Create in the admin dashboard)

Next Steps:
---------
1. Complete your StreamVibe setup by visiting: http://$DOMAIN_NAME
2. Log in with the admin credentials above
3. Create content and configure your streaming settings
4. Consider setting up regular backups of your application and database

Need help?
---------
- Check the documentation: docs/installation_guide.md
- Visit the support website: https://example.com/support
EOL
    
    print_success "Installation report created: $INSTALL_DIR/install-report/summary.txt"
}

# Step 11: Start services
start_services() {
    print_status "Starting services..."
    
    systemctl restart postgresql
    systemctl restart nginx
    systemctl restart streamvibe
    
    print_success "All services started successfully"
}

# Final check
check_services() {
    print_status "Checking services status..."
    
    postgresql_status=$(systemctl is-active postgresql)
    nginx_status=$(systemctl is-active nginx)
    streamvibe_status=$(systemctl is-active streamvibe)
    
    print_status "PostgreSQL: $postgresql_status"
    print_status "NGINX: $nginx_status"
    print_status "StreamVibe: $streamvibe_status"
    
    if [ "$postgresql_status" = "active" ] && [ "$nginx_status" = "active" ] && [ "$streamvibe_status" = "active" ]; then
        print_success "All services are running correctly"
        return 0
    else
        print_warning "Some services are not running correctly. Please check the logs for more information."
        return 1
    fi
}

# Main installation function
install_streamvibe_full() {
    # Welcome message
    clear
    echo "=================================================="
    echo "       StreamVibe Automated Installation          "
    echo "=================================================="
    echo
    echo "This script will install StreamVibe on your server."
    echo "Domain: $DOMAIN_NAME"
    echo "Install Directory: $INSTALL_DIR"
    echo
    read -p "Continue with installation? (y/n): " confirm
    
    if [ "$confirm" != "y" ] && [ "$confirm" != "Y" ]; then
        print_status "Installation cancelled."
        exit 0
    fi
    
    # Begin installation
    check_root
    update_system
    install_dependencies
    configure_firewall
    setup_database
    create_directories
    configure_nginx
    install_streamvibe "$1"  # Pass optional git URL
    initialize_database
    create_report
    setup_ssl || print_warning "SSL setup incomplete. Continue with manual SSL setup later."
    start_services
    check_services
    
    # Final message
    echo
    echo "=================================================="
    echo "       StreamVibe Installation Complete!          "
    echo "=================================================="
    echo
    print_success "StreamVibe has been successfully installed!"
    echo
    print_status "Website URL: http://$DOMAIN_NAME"
    print_status "Admin Login: http://$DOMAIN_NAME/login"
    print_status "Admin Credentials: $ADMIN_USER / $ADMIN_PASS"
    echo
    print_status "Full installation details are available in:"
    print_status "$INSTALL_DIR/install-report/summary.txt"
    echo
    print_warning "Remember to secure your server and change default passwords!"
    echo
}

# Parse command-line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --domain=*)
            DOMAIN_NAME="${1#*=}"
            shift
            ;;
        --admin-user=*)
            ADMIN_USER="${1#*=}"
            shift
            ;;
        --admin-pass=*)
            ADMIN_PASS="${1#*=}"
            shift
            ;;
        --admin-email=*)
            ADMIN_EMAIL="${1#*=}"
            shift
            ;;
        --db-name=*)
            DB_NAME="${1#*=}"
            shift
            ;;
        --db-user=*)
            DB_USER="${1#*=}"
            shift
            ;;
        --db-pass=*)
            DB_PASS="${1#*=}"
            shift
            ;;
        --install-dir=*)
            INSTALL_DIR="${1#*=}"
            shift
            ;;
        --git-repo=*)
            GIT_REPO="${1#*=}"
            shift
            ;;
        --help)
            echo "Usage: sudo ./install_streamvibe.sh [OPTIONS]"
            echo
            echo "Options:"
            echo "  --domain=DOMAIN       Domain name (default: streamvibe.biz)"
            echo "  --admin-user=USER     Admin username (default: admin)"
            echo "  --admin-pass=PASS     Admin password (default: auto-generated)"
            echo "  --admin-email=EMAIL   Admin email (default: admin@streamvibe.biz)"
            echo "  --db-name=NAME        Database name (default: streamvibe)"
            echo "  --db-user=USER        Database user (default: streamvibe_user)"
            echo "  --db-pass=PASS        Database password (default: auto-generated)"
            echo "  --install-dir=DIR     Installation directory (default: /var/www/streamvibe)"
            echo "  --git-repo=URL        Git repository URL for StreamVibe code"
            echo "  --help                Show this help message"
            echo
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            echo "Use --help for usage information."
            exit 1
            ;;
    esac
done

# Run the full installation
install_streamvibe_full "$GIT_REPO"