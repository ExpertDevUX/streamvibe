import datetime
from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    profile_description = db.Column(db.Text, nullable=True)
    avatar_path = db.Column(db.String(255), nullable=True)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    
    # Relationships
    media_items = db.relationship('Media', backref='owner', lazy='dynamic')
    streams = db.relationship('Stream', backref='owner', lazy='dynamic')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def __repr__(self):
        return f'<User {self.username}>'

class Media(db.Model):
    __tablename__ = 'media'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=False)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    media_type = db.Column(db.String(20), nullable=False)  # video, audio
    duration = db.Column(db.Integer, nullable=True)  # Duration in seconds
    views = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Additional metadata
    quality_options = db.Column(db.String(255), nullable=True)  # JSON string of available quality options
    tags = db.Column(db.String(255), nullable=True)  # Comma-separated tags
    
    def __repr__(self):
        return f'<Media {self.title}>'

class Stream(db.Model):
    __tablename__ = 'streams'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(128), nullable=False)
    description = db.Column(db.Text, nullable=True)
    stream_key = db.Column(db.String(64), unique=True, nullable=False)
    is_live = db.Column(db.Boolean, default=False)
    viewers = db.Column(db.Integer, default=0)
    started_at = db.Column(db.DateTime, nullable=True)
    ended_at = db.Column(db.DateTime, nullable=True)
    thumbnail_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    
    # Additional settings
    is_public = db.Column(db.Boolean, default=True)
    tags = db.Column(db.String(255), nullable=True)  # Comma-separated tags
    
    def __repr__(self):
        return f'<Stream {self.title}>'

class Comment(db.Model):
    __tablename__ = 'comments'
    
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    
    # Relationships
    user = db.relationship('User', backref='comments')
    
    def __repr__(self):
        return f'<Comment by {self.user_id}>'

class Analytics(db.Model):
    __tablename__ = 'analytics'
    
    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    views = db.Column(db.Integer, default=0)
    unique_viewers = db.Column(db.Integer, default=0)
    watch_time = db.Column(db.Integer, default=0)  # In seconds
    peak_viewers = db.Column(db.Integer, default=0)
    device_mobile = db.Column(db.Integer, default=0)  # Mobile viewers count
    device_desktop = db.Column(db.Integer, default=0)  # Desktop viewers count
    device_tablet = db.Column(db.Integer, default=0)  # Tablet viewers count
    device_other = db.Column(db.Integer, default=0)  # Other device viewers count
    avg_watch_duration = db.Column(db.Float, default=0.0)  # Average watch duration in seconds
    engagement_rate = db.Column(db.Float, default=0.0)  # Percentage of engagement (interactions/views)
    bounce_rate = db.Column(db.Float, default=0.0)  # Percentage of viewers who leave quickly
    country_data = db.Column(db.Text, nullable=True)  # JSON string of country distribution
    referrer_data = db.Column(db.Text, nullable=True)  # JSON string of traffic sources
    
    # Relationships
    user = db.relationship('User', backref='analytics')
    media = db.relationship('Media', backref='analytics_data')
    stream = db.relationship('Stream', backref='analytics_data')
    
    def __repr__(self):
        return f'<Analytics {self.date}>'
        
class AnalyticsEvent(db.Model):
    """Detailed analytics events for user interactions"""
    __tablename__ = 'analytics_events'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    media_id = db.Column(db.Integer, db.ForeignKey('media.id'), nullable=True)
    stream_id = db.Column(db.Integer, db.ForeignKey('streams.id'), nullable=True)
    event_type = db.Column(db.String(50), nullable=False)  # view, play, pause, seek, end, etc.
    value = db.Column(db.Float, nullable=True)  # Custom value for event (e.g. seek position)
    session_id = db.Column(db.String(64), nullable=False)  # Unique viewer session
    device_type = db.Column(db.String(20), nullable=True)  # mobile, desktop, tablet, etc.
    browser = db.Column(db.String(50), nullable=True)  # Browser information
    os = db.Column(db.String(50), nullable=True)  # Operating system
    country_code = db.Column(db.String(2), nullable=True)  # ISO country code
    referrer = db.Column(db.String(255), nullable=True)  # Where the viewer came from
    
    # Relationships
    user = db.relationship('User', backref='analytics_events')
    
    def __repr__(self):
        return f'<AnalyticsEvent {self.event_type} {self.timestamp}>'
